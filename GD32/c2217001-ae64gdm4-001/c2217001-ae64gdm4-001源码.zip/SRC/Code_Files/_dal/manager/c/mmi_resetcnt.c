/********************************************************************************
**
** �ļ���:     mmi_resetcnt.c
** ��Ȩ����:   (c) 2014-2020 ������Ѹ����ɷ����޹�˾
** �ļ�����:   ��λͳ��ģ��,Ŀǰ��ͳ��������Ϣ
**
*********************************************************************************
**             �޸���ʷ��¼
**===============================================================================
**| ����       | ����   |  �޸ļ�¼
**===============================================================================
**| 2016/1/4   | JUMP   | ������ģ��
**
*********************************************************************************/
#include  "dal_include.h"
#include  "mmi_resetcnt.h"
#include  "systime.h"
#include  "public.h"
#include  "database.h"
#include  "tools.h"
#include  "debug_print.h"

/*
*****************************************************************
*   �궨��
*****************************************************************
*/


/*
*****************************************************************
*   ��̬��������
*****************************************************************
*/
static RESETREC_T s_resetcnt;


/*******************************************************************
** ������:     fill_reset_extraarea
** ��������:   �洢��Ϣ
** ����:       [in] err_id��   ����ID
**             [in] filename�� �ļ���
**             [in] line��     �����к�
** ����:       ��
********************************************************************/
static void fill_reset_extraarea(INT32U err_id, INT8U *filename, INT32U line)
{
    INT8U len;

    memmove(&s_resetcnt.rst_rec_ext[1], &s_resetcnt.rst_rec_ext[0], sizeof(REC_EXT_T) * (MAX_REC_EXT - 1));
    GetSysTime(&s_resetcnt.rst_rec_ext[0].start_time);
    len = CutRedundantLen(sizeof(s_resetcnt.rst_rec_ext[0].filename), strlen((char*)filename));
    MMI_MEMCPY(s_resetcnt.rst_rec_ext[0].filename, sizeof(s_resetcnt.rst_rec_ext[0].filename), filename, len);

    s_resetcnt.rst_rec_ext[0].err_id   = err_id;
    s_resetcnt.rst_rec_ext[0].line     = line;
}

/*******************************************************************
** ������:     mmi_resetinform
** ��������:   ��λ�ص��ӿ�
** ����:       [in] resettype����λ����
**             [in] filename�� �ļ���
**             [in] line��     �����к�
**             [in] errid��    ����ID
** ����:       ��
********************************************************************/
void mmi_resetinform(INT8U resettype, INT8U *filename, INT32U line, INT32U errid)
{
    if (resettype == RESET_INITIATIVE) {
      #if DEBUG_RESET > 0
        Debug_SysPrint("�ڲ���λ\r\n");
      #endif
        if (ReadPubPara(RESETREC_, &s_resetcnt)) {
            s_resetcnt.rst_int++;
            s_resetcnt.rst_total = s_resetcnt.rst_int + s_resetcnt.rst_ext + s_resetcnt.rst_err + s_resetcnt.rst_link - 1;
        } else {
          #if DEBUG_RESET > 0
            Debug_SysPrint("ReadPubPara wrong\r\n");
          #endif
            memset(&s_resetcnt, 0, sizeof(s_resetcnt));
            s_resetcnt.rst_int  = 1;
            s_resetcnt.rst_ext  = 0;
            s_resetcnt.rst_err  = 0;
            s_resetcnt.rst_link = 0;
            s_resetcnt.rst_total= 0;                                            /* ���ܺͲ�1�������´�����ʱ�жϳ������ⲿ��λ */
        }
        fill_reset_extraarea(errid, filename, line);
    } else if (resettype == RESET_ABNORMAL) {
      #if DEBUG_RESET > 0
        Debug_SysPrint("�쳣��λ\r\n");
      #endif
        if (ReadPubPara(RESETREC_, &s_resetcnt)) {
            s_resetcnt.rst_err++;
            s_resetcnt.rst_total = s_resetcnt.rst_int + s_resetcnt.rst_ext + s_resetcnt.rst_err + s_resetcnt.rst_link - 1;
        } else {
          #if DEBUG_RESET > 0
            Debug_SysPrint("ReadPubPara wrong\r\n");
          #endif
            memset(&s_resetcnt, 0, sizeof(s_resetcnt));
            s_resetcnt.rst_int  = 0;
            s_resetcnt.rst_ext  = 0;
            s_resetcnt.rst_err  = 1;
            s_resetcnt.rst_link = 0;
            s_resetcnt.rst_total= 0;                                            /* ���ܺͲ�1�������´�����ʱ�жϳ������ⲿ��λ */
        }
        fill_reset_extraarea(errid, filename, line);
    } else if (resettype == RESET_LINK) {
      #if DEBUG_RESET > 0
        Debug_SysPrint("��·��λ\r\n");
      #endif
        if (ReadPubPara(RESETREC_, &s_resetcnt)) {
            s_resetcnt.rst_link++;
            s_resetcnt.rst_total = s_resetcnt.rst_int + s_resetcnt.rst_ext + s_resetcnt.rst_err + s_resetcnt.rst_link - 1;
        } else {
          #if DEBUG_RESET > 0
            Debug_SysPrint("ReadPubPara wrong\r\n");
          #endif
            memset(&s_resetcnt, 0, sizeof(s_resetcnt));
            s_resetcnt.rst_int  = 0;
            s_resetcnt.rst_ext  = 0;
            s_resetcnt.rst_err  = 0;
            s_resetcnt.rst_link = 1;
            s_resetcnt.rst_total= 0;                                            /* ���ܺͲ�1�������´�����ʱ�жϳ������ⲿ��λ */
        }
        fill_reset_extraarea(errid, filename, line);
    } else {
        return;
    }
  #if EN_CHECKFLASH
  setflashflag();
  #endif
  StorePubPara(RESETREC_, &s_resetcnt);
  #if 0 /* RESETREC_������ */
  BakParaReqSingle(RESETREC_); /* ���ݲ�������̨ */
  #endif
  #if EN_CHECKFLASH
  clearflashflag();
  #endif
}

/*******************************************************************
** ������:     mmi_resetcnt_init
** ��������:   ��ʼ������ͳ��ģ��
** ����:       ��
** ����:       ��
********************************************************************/
void mmi_resetcnt_init(void)
{
    INT32U tmpCnt;
    BOOLEAN store;
  #if DEBUG_RESET > 0
    INT8U i;
    INT8U temp[FILENAMELEN + 1];

    Debug_SysPrint("mmi_resetcnt_init\r\n");
  #endif

    store = false;
    if (ReadPubPara(RESETREC_, &s_resetcnt) == 0) {
        memset(&s_resetcnt, 0, sizeof(s_resetcnt));
        store = true;
    } else {
        tmpCnt = s_resetcnt.rst_int + s_resetcnt.rst_ext + s_resetcnt.rst_err + s_resetcnt.rst_link;
        if (tmpCnt == s_resetcnt.rst_total + 1) {                              /* ˵������֪�ĸ�λ, �������ⲿ�ĸ�λ */
            s_resetcnt.rst_total++;
            store = true;
        } else if (tmpCnt == s_resetcnt.rst_total) {                           /* ˵�����ⲿ��λ. */
            /* �ܵ�дflash�������ƣ���ʱ��ͳ���ⲿ��λ */
            //s_resetcnt.rst_total++;
            //s_resetcnt.rst_ext++;
            //fill_reset_extraarea(ERR_ID_EXT, (INT8U *)__FILE__ + strlen(__FILE__) - FILENAMELEN, __LINE__);
            //store = true;
          #if DEBUG_RESET > 0
            Debug_SysPrint("�ⲿ��λ����\r\n");
          #endif
        } else {                                                               /* ˵��ͳ�ƺ��쳣,���¼�֮ */
            s_resetcnt.rst_total = tmpCnt;
            store = true;
        }
    }
    if (store) {
      #if EN_CHECKFLASH
      setflashflag();
      #endif
      StorePubPara(RESETREC_, &s_resetcnt);
      #if 0 /* RESETREC_������ */
      BakParaReqSingle(RESETREC_); /* ���ݲ�������̨ */
      #endif
      #if EN_CHECKFLASH
      clearflashflag();
      #endif
    }

  #if DEBUG_RESET > 0
    Debug_SysPrint("\r\n�ܸ�λ����(%d) = �ⲿ(%d) + �ڲ�(%d) + ����(%d) + ��·��ʱ(%d)\r\n",
                 s_resetcnt.rst_total, s_resetcnt.rst_ext, s_resetcnt.rst_int, s_resetcnt.rst_err, s_resetcnt.rst_link);
    for (i = 0; i < MAX_REC_EXT; i++) {
        Debug_SysPrint("%d. ", i);
        Debug_SysPrint("Time[20%.2d-%.2d-%.2d %.2d:%.2d:%.2d]", s_resetcnt.rst_rec_ext[i].start_time.date.year,
                                                                s_resetcnt.rst_rec_ext[i].start_time.date.month,
                                                                s_resetcnt.rst_rec_ext[i].start_time.date.day,
                                                                s_resetcnt.rst_rec_ext[i].start_time.time.hour,
                                                                s_resetcnt.rst_rec_ext[i].start_time.time.minute,
                                                                s_resetcnt.rst_rec_ext[i].start_time.time.second);
        temp[FILENAMELEN] = '\0';
        MMI_MEMCPY(temp, sizeof(temp), s_resetcnt.rst_rec_ext[i].filename, FILENAMELEN);
        Debug_SysPrint(", File[%-15s]",                         temp);
        Debug_SysPrint(", Line[%.4d]",                          s_resetcnt.rst_rec_ext[i].line);
        Debug_SysPrint(", ErrID[%.8X]",                         s_resetcnt.rst_rec_ext[i].err_id);
        Debug_SysPrint("\r\n");
    }
  #endif
}

/*******************************************************************
** ������:     mmi_resetcnt_getptr
** ��������:   ��ȡ��λ��Ϣ
** ����:       ��
** ����:       ��
********************************************************************/
RESETREC_T *mmi_resetcnt_getptr(void)
{
    if (ReadPubPara(RESETREC_, &s_resetcnt) == 0) {
        memset((INT8U*)&s_resetcnt, 0, sizeof(s_resetcnt));
    }
    return &s_resetcnt;
}


