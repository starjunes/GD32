/********************************************************************************
**
** �ļ���:     debug_print.c
** ��Ȩ����:   (c) 2014-2020 ������Ѹ����ɷ����޹�˾
** �ļ�����:   ϵͳ���Դ�ӡ�����ӿ�
**
*********************************************************************************
**             �޸���ʷ��¼
**===============================================================================
**| ����       | ����   |  �޸ļ�¼
**===============================================================================
**| 2010/12/30 | LEON   | ������ģ��
**
*********************************************************************************/
#include "dal_include.h"
#include "tools.h"
#include "dal_usart.h"
#include "debug_print.h"

#define DBG_BUF_SIZE    1024
#define STAT_INIT_      0x01

typedef struct {
    INT8U stat;
    INT8U *dbg_buf;
} DBG_CB_T;

static INT8U s_printf_buf[DBG_BUF_SIZE];
static BOOLEAN debug_sw = TRUE;

static DBG_CB_T s_dbg_cb = {STAT_INIT_, s_printf_buf};

/*************************************************************************************************/
/*                                     �ض���ϵͳ��ӡ����                                        */
/*************************************************************************************************/
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE  int  __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE  int  fputc(int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
    Debug_PrintByte((INT8U)ch);                                      /* Write a character to USART */

    return ch;
}

/*******************************************************************
** ������:     Debug_PrintByte
** ��������:   ��ӡ��������ֽ�
** ����:       [in] byte   ����
** ����:       ��
********************************************************************/
void Debug_PrintByte(INT8U byte)
{
    #if 1
    USARTX_SendData(USART_DEBUG, &byte, 1);
    #if 0
    switch (USART_DEBUG)
    {
        case USART_NO1:
            //USART_SendData(USART1, (INT16U)byte);
            //while ((USART1->SR & USART_SR_TXE) == 0) {};
            USARTX_SendData(USART_DEBUG, &byte, 1);
            break;

        case USART_NO2:
            USART_SendData(USART2, (INT16U)byte);
            while ((USART2->SR & USART_SR_TXE) == 0) {};
            break;

        case USART_NO3:
            USART_SendData(USART3, (INT16U)byte);
            while ((USART3->SR & USART_SR_TXE) == 0) {};
            break;

        case USART_NO4:
            USART_SendData(UART4, (INT16U)byte);
            while ((UART4->SR & USART_SR_TXE) == 0) {};
            break;

        case USART_NO5:
            USART_SendData(UART5, (INT16U)byte);
            while ((UART5->SR & USART_SR_TXE) == 0) {};
            break;

        default:
            DAL_ASSERT(0);                                           /* �˴��������ָʾ */
            break;
    }
    #endif
  #endif
}

/*******************************************************************
** ������:     Debug_PrintCRLF
** ��������:   �ڴ�ӡ��Ϣ�󲹼ӻس����з�
** ����:       ��
** ����:       ��
********************************************************************/
void Debug_PrintCRLF(void)
{
    Debug_PrintByte('\r');
    Debug_PrintByte('\n');
}

/**************************************************************************************************
**  ��������:  Debug_PrintHex
**  ��������:  ��16���Ƹ�ʽ��ӡ��������
**  �������:
**  �������:
**************************************************************************************************/
void Debug_PrintHex(BOOLEAN end, INT8U *ptr, INT16U size)
{
    INT8U  ch;
    INT16U i;

    for (i = 0; i < size; i++) {
        ch = *ptr++;
        Debug_PrintByte(HexToChar(ch >> 4));
        Debug_PrintByte(HexToChar(ch));
        Debug_PrintByte(' ');
    }

    if (end == TRUE) Debug_PrintCRLF();                              /* �ڽ�β������һ���س����з� */
}

/*******************************************************************
** ������:     Debug_PrintStr
** ��������:   ���ַ�����ʽ��ӡ��������
** ����:       [in] ptr   ����
** ����:       ��
********************************************************************/
void Debug_PrintStr(char *ptr)
{
    INT32U i, tlen;

    tlen = strlen(ptr);

    for (i = 0; i < tlen; i++) {
        Debug_PrintByte(*ptr++);
    }
}

/*******************************************************************
** ������:     Debug_Initiate
** ��������:   ��ʼ����ӡ����
** ����:       ��
** ����:       ��
********************************************************************/
void Debug_Initiate(void)
{
#if EN_DEBUG > 0
		USART_PARA_T usart;
	
		usart.baud		= BAUD_DEBUG;
		usart.databits	= DATABITS_8;
		usart.parity	= PARITY_NONE;
		usart.stopbits	= STOPBITS_1;
	
		s_dbg_cb.dbg_buf = s_printf_buf;
		s_dbg_cb.stat |= STAT_INIT_;
	
		USARTX_IOConfig(USART_DEBUG); 
	
		switch (USART_DEBUG)											 /* �������жϣ���ʹ�ܴ��ڹ��� */
		{
			case USART_NO1:
				//RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
				//USART_Init(USART0, &ICB);
				//USART_ClockInit(USART0, &ICL);
				//USART_Cmd(USART0, ENABLE);
				usart_deinit(USART0);
				rcu_periph_clock_enable(RCU_USART0);
				usart_baudrate_set(USART0, BAUD_DEBUG);
				usart_receive_config(USART0,USART_RECEIVE_ENABLE);
				usart_transmit_config(USART0,USART_TRANSMIT_ENABLE);
				usart_dma_receive_config(USART0,USART_DENR_ENABLE);
				usart_dma_transmit_config(USART0,USART_DENT_ENABLE);
				usart_interrupt_disable(USART0,USART_INT_RBNE);
				usart_enable(USART0);
				break;
	
			case USART_NO2:
				//RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
				usart_deinit(USART1);
				rcu_periph_clock_enable(RCU_USART1);
				usart_baudrate_set(USART1, BAUD_DEBUG);
				usart_receive_config(USART1,USART_RECEIVE_ENABLE);
				usart_transmit_config(USART1,USART_TRANSMIT_ENABLE);
				usart_dma_receive_config(USART1,USART_DENR_ENABLE);
				usart_dma_transmit_config(USART1,USART_DENT_ENABLE);
				usart_interrupt_disable(USART1,USART_INT_RBNE);
				usart_enable(USART1);
				break;
	
			case USART_NO3:
				usart_deinit(USART2);
				rcu_periph_clock_enable(RCU_USART2);
				usart_baudrate_set(USART2, BAUD_DEBUG);
				usart_receive_config(USART2,USART_RECEIVE_ENABLE);
				usart_transmit_config(USART2,USART_TRANSMIT_ENABLE);
				//usart_dma_receive_config(USART2,USART_DENR_ENABLE);
				//usart_dma_transmit_config(USART2,USART_DENT_ENABLE);
				usart_interrupt_disable(USART2,USART_INT_RBNE);
				usart_enable(USART2);
				break;


        case USART_NO4:
            usart_deinit(UART3);
				rcu_periph_clock_enable(UART3);
				usart_baudrate_set(UART3, BAUD_DEBUG);
				usart_receive_config(UART3,USART_RECEIVE_ENABLE);
				usart_transmit_config(UART3,USART_TRANSMIT_ENABLE);
				//usart_dma_receive_config(USART2,USART_DENR_ENABLE);
				//usart_dma_transmit_config(USART2,USART_DENT_ENABLE);
				usart_interrupt_disable(UART3,USART_INT_RBNE);
				usart_enable(UART3);
            break;

        case USART_NO5:
            rcu_periph_clock_enable(UART4);
				usart_baudrate_set(UART4, BAUD_DEBUG);
				usart_receive_config(UART4,USART_RECEIVE_ENABLE);
				usart_transmit_config(UART4,USART_TRANSMIT_ENABLE);
				//usart_dma_receive_config(USART2,USART_DENR_ENABLE);
				//usart_dma_transmit_config(USART2,USART_DENT_ENABLE);
				usart_interrupt_disable(UART4,USART_INT_RBNE);
				usart_enable(UART4);
				break;

        default:
            DAL_ASSERT(0);                                           /* �˴��������ָʾ */
            break;
    }
#endif
}

/*******************************************************************
** ������:     Debug_Print_Sw
** ��������:   ��ӡ����(��Ҫ���ڼ���оƬ����debug_printf��ӡ�ӿ��������)
** ����:       [in] db_sw : TRUE:�򿪣�FALSE:�ر�
** ����:       ��
********************************************************************/
void Debug_Print_Sw(BOOLEAN db_sw) 
{
    if (db_sw == TRUE) {
        debug_sw = TRUE;
    } else {
        debug_sw = FALSE;
    }
}

/*******************************************************************
** ������:     debug_printf
** ��������:   ��ӡ�ӿ�
** ����:       ��
** ����:       ��
********************************************************************/
BOOLEAN debug_printf(const char * fmt, ...)
{
    #if 1
    if (debug_sw == FALSE) {
        return TRUE;
    } else {
        va_list ap;
        INT16U len;
        
        if ((s_dbg_cb.stat & STAT_INIT_) == 0) return FALSE;
        va_start(ap, fmt);
        len = vsnprintf((char *)s_dbg_cb.dbg_buf, DBG_BUF_SIZE, fmt, ap);
        va_end(ap);
        
        return USARTX_SendData(USART_DEBUG, s_dbg_cb.dbg_buf, len);
    }
    #else 
    return TRUE;
    #endif
} 


