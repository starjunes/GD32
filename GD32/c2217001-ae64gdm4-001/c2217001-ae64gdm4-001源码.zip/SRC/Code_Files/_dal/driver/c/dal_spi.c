/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  dal_spi.c                                                                         **
**  ��Ȩ����:  CopyRight @ Xiamen Yaxon NetWork CO.LTD. 2012                                     **
**  ������Ϣ:                                                                                    **
**  �ļ�����:  SPI�����ӿں���                                                                   **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/
#include "dal_include.h"
#include "tools.h"
#include "roundbuf.h"
#include "dmemory.h"
#include "man_timer.h"
#include "man_irq.h"
#include "man_error.h"
#include "dal_spi.h"
#include "dal_pinlist.h"
#include "dal_hard.h"
#include "dal_gpio.h"
#include "debug_print.h"

#if EN_DEBUG > 1
#define DEBGU_SPI                   1
#else
#define DEBGU_SPI                   0
#endif

#define DATASIZE_8b                 0x01                                       /* ���ݿ���8λ */
#define DATASIZE_16b                0x02                                       /* ���ݿ���16λ */
#define SPI_DATASIZE                DATASIZE_8b                                /* ������ѡ��SPI���ݿ��� */

#define DMA_RCVBUF                  255                                        /* DMA���ջ��� */
#define DMA_SENDBUF                 255                                        /* DMA���ͻ��� */

#define SPI_ROUNDBUF_TX_LEN         512                                       /*  ���ͻ���  */
#define SPI_ROUNDBUF_RX_LEN         512                                       /*  ���ջ���  */

/* SPI_IND_1 */
#define SPI_IDX1_PORT               SPI0
#define SPI_IDX1_DMAx				DMA0
#define SPI_IDX1_RX_DMA_STREAM      DMA_CH1
#define SPI_IDX1_TX_DMA_STREAM      DMA_CH2

/* SPI_IND_2 */
#define SPI_IDX2_PORT               SPI2
#define SPI_IDX2_DMAx				DMA1
#define SPI_IDX2_RX_DMA_STREAM      DMA_CH0
#define SPI_IDX2_TX_DMA_STREAM      DMA_CH1
//#define SPI_IDX2_TX_CH            DMA_Channel_4
//#define SPI_IDX2_RX_CH            DMA_Channel_4

/*************************************************************************************************/
/*                           SPI����״̬ö��                                                    */
/*************************************************************************************************/
typedef enum {
    SPI_STATUS_CLOSED = 0x00,                                                  /* ���ڱ��ر� */
    SPI_STATUS_DISABLE,                                                        /* ���ڱ����� */
    SPI_STATUS_INITING,                                                        /* ���ڳ�ʼ�� */
    SPI_STATUS_SENDING,                                                        /* ������æ */
    SPI_STATUS_IDLENOW                                                         /* ���ڿ��� */
} SPI_SS_E;

/*************************************************************************************************/
/*                           ģ��ṹ�嶨��                                                      */
/*************************************************************************************************/
typedef struct {
    volatile SPI_SS_E   status;                                                 /* ��ǰ����״̬ */
    
    INT8U               *p_rx;                                                  /* ���ջ��λ������ڴ�ָ�� */
    INT8U               *p_tx;                                                  /* ���ͻ��λ������ڴ�ָ�� */
    INT32U              tx_len;                                                 /* ���ջ��λ�������С */
    INT32U              rx_len;                                                 /* ���ͻ��λ�������С */
    ROUNDBUF_T          recvrb;                                                 /* ���ջ��λ����� */
    ROUNDBUF_T          sendrb;                                                 /* ���ͻ��λ����� */
    
    SPI_DMA_MODE_E      dma_en;                                                 /* ��ǰ����״̬ */
    
    BOOLEAN             dmairq;                                                 /* �Ƿ�����DMA�ж� */
    BOOLEAN             timerread;                                              /* ��ʱ�����ڿ������ݣ�����ʱ��DMA�ж���ֱ���˳� */
    INT16U              oldlocat;                                               /* �ϻ�DMAдλ�� */
    INT8U               readlocat;                                              /* ��λ�� */
    INT8U               *rcvdmabuf;                                             /* DMA���ջ��� */   //ry
    INT16U              *senddmabuf;                                            /* DMA���ͻ��� */
    INT16U              spifirstbit;                                            /* MSB or LSB bit */
} SPI_CTRL_T;

/*************************************************************************************************/
/*                           ģ�龲̬��������                                                    */
/*************************************************************************************************/
static INT8U       s_spi_dmarecvbuf[MAX_SPI_IND][DMA_RCVBUF];                               /* ���ջ����� */  // ry
static INT16U      s_spi_dmasendbuf[MAX_SPI_IND][DMA_SENDBUF];                              /* ���ͻ����� */
static SPI_CTRL_T  s_scbt[MAX_SPI_IND];                                                     /* SPI���ƿ� */
static SPI_CALLBACK_T  s_spi_callback[MAX_SPI_IND];
static INT32U      s_spi_tmr_id;          /* ��ʱ�ж϶�ʱ���� */
static BOOLEAN     s_is_creat = false;    /* ��ʱ���Ƿ��Ѿ����� */
//static BOOLEAN     s_spi_idle;            /* �ж��Ƿ���Լ�����߿��� */

static INT32U s_spi_port[MAX_SPI_IND] 			= {SPI_IDX1_PORT, SPI_IDX2_PORT};
static INT32U s_spi_dma_periph[MAX_SPI_IND]		= {SPI_IDX1_DMAx,SPI_IDX2_DMAx};
static INT8U  s_spi_dma_rx_stream[MAX_SPI_IND] 	= {SPI_IDX1_RX_DMA_STREAM, SPI_IDX2_RX_DMA_STREAM};
static INT8U  s_spi_dma_tx_stream[MAX_SPI_IND]  = {SPI_IDX1_TX_DMA_STREAM, SPI_IDX2_TX_DMA_STREAM};

/**************************************************************************************************
**  ��������:  WriteSPI
**  ��������:  ��SPI2дһ���ֽ�����
**  �������:  �������
**  ���ز���:  ��
**************************************************************************************************/
static INT32S WriteSPI(SPI_IND_E idx, INT8U DataOut)
{
    
	INT8U retry = 0;
	
	while (spi_i2s_flag_get(s_spi_port[idx], SPI_FLAG_TBE) == RESET) { //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
		retry++;
		if (retry > 200) {
			return -1;
		}
	}
	spi_i2s_data_transmit(s_spi_port[idx], (INT8U)DataOut); //ͨ������SPIx����һ������

	retry = 0;
	while (spi_i2s_flag_get(s_spi_port[idx], SPI_FLAG_RBNE) == RESET) { //���ָ����SPI��־λ�������:���ܻ���ǿձ�־λ
		retry++;
		if (retry > 200) {
			return -1;
		}
	}
	return spi_i2s_data_receive(s_spi_port[idx]); //����ͨ��SPIx������յ�����
}

/**************************************************************************************************
**  ��������:  ReadSPI
**  ��������:  ��SPI��ȡһ���ֽ�����
**  �������:  ��
**  ���ز���:  ��������
**************************************************************************************************/
static INT32S ReadSPI(SPI_IND_E idx)
{
    return WriteSPI(idx, 0x00); //����ͨ��SPIx������յ�����
}

INT32U read_roundbuf(SPI_IND_E idx)
{
	return UsedOfRoundBuf(&s_scbt[idx].sendrb);
}

/*******************************************************************
** ������:     start_send
** ��������:   ����SPIX��������
** ����:       ��
** ����:       ��
********************************************************************/
static BOOLEAN start_send(SPI_IND_E idx)
{
    INT32S  temp = 0;
    INT32U  tlen, i, blen, k;
    INT16U  *tptr;
#if SPI_DATASIZE == DATASIZE_16b
    INT8U   j = 0;
    INT8U   wrbuff[2] = {0xFF, 0xFF};
    INT16U  sword = 0;
#endif

    tlen = UsedOfRoundBuf(&s_scbt[idx].sendrb);
    if (tlen <= 0)  {
        return FALSE;
    }

    s_scbt[idx].status = SPI_STATUS_SENDING;                                      /* ���ڷ���״̬ */

    if (s_scbt[idx].dma_en == SPI_DMA_MODE_DISABLE) {
        #if EN_DEBUG > 1
        Debug_SysPrint("start_send �жϷ���\r\n");
        #endif

		#if SPI_DATASIZE == DATASIZE_16b
        sword = 0;
		if (s_scbt[idx].spifirstbit == SPI_ENDIAN_MSB) {
			for (j = 0; j < 2; j++) {
				wrbuff[j] = ReadRoundBuf(&s_scbt[idx].sendrb);
				sword = (sword << 8) + wrbuff[j];
			}
		} else {
			for (j = 0; j < 2; j++) {
				wrbuff[j] = ReadRoundBuf(&s_scbt[idx].sendrb);
				sword = sword + ((INT16U)wrbuff[j] << ((INT16U)8U*j));
			}
		}
        spi_i2s_data_transmit(s_spi_port[idx], sword);
        spi_i2s_interrupt_enable(s_spi_port[idx], SPI_I2S_INT_TBE);
        #else
		#if 0
        for (i = 0; i <  tlen; i++) {
			temp = ReadRoundBuf(&s_scbt[idx].sendrb);
			SPI_SendData(s_spi_port[idx], (INT16U)temp);
			k = 0;
			while (!SPI_I2S_GetFlagStatus(s_spi_port[idx], SPI_I2S_FLAG_TXE)) {
                if (k++ >= 4000) {
                    break;
				}
			}
		}
		
		s_scbt[idx].status = SPI_STATUS_IDLENOW;  
		#else
        temp = ReadRoundBuf(&s_scbt[idx].sendrb);
        spi_i2s_data_transmit(s_spi_port[idx], (INT16U)temp);
        spi_i2s_interrupt_enable(s_spi_port[idx],SPI_I2S_INT_TBE);
		#endif
        #endif
    } else {
        #if EN_DEBUG > 1
        Debug_SysPrint("start_send DMA����\r\n");
        //Debug_PrintHex(TRUE, (INT8U *)s_scbt[idx].senddmabuf, tlen);
        #endif
        tptr = s_scbt[idx].senddmabuf;
		#if 0
        blen = DMA_SENDBUF < (tlen + 4) ? DMA_SENDBUF : (tlen + 4);
        *tptr++ = 0xFF;
        *tptr++ = 0x5A;
        *tptr++ = 0xA5;
        *tptr++ = blen-4;
        DMA_ClearFlag(s_spi_dma_tx_stream[idx], DMA_FLAG_TCIF4);
        DMA_Cmd(s_spi_dma_tx_stream[idx], DISABLE);
		
        for (i = 0; i < blen - 4; i++) {                                        /* ���θ���ÿһ������ */
            temp = ReadRoundBuf(&s_scbt[idx].sendrb);
            *tptr++ = temp;
        }		
	    #else
        blen = DMA_SENDBUF < (tlen) ? DMA_SENDBUF : (tlen);
        dma_flag_clear(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx], DMA_INT_FTF);
        dma_channel_disable(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx]);
		
        for (i = 0; i < blen; i++) {                                        /* ���θ���ÿһ������ */
            temp = ReadRoundBuf(&s_scbt[idx].sendrb);
            *tptr++ = temp;
        }		
		#endif
        dma_transfer_number_config(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx],blen);
		dma_interrupt_enable(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx],DMA_INT_FTF);
		dma_channel_enable(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx]);
    }

    return TRUE;
}

/**************************************************************************************************
**  ��������:  USER_SPI0_IRQHandler
**  ��������:  SPI0���жϴ������� - �����Ӻͷ����ж�
**  �������:
**  �������:
**************************************************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_SPI0_IRQHandler(void) __irq
{
    INT32U tlen;
    INT16U rword;
	
    #if SPI_DATASIZE == DATASIZE_16b
    INT16S j;
    INT8U  rcbuff[2] = {0xFF, 0xFF};
    #endif

    //ENTER_CRITICAL();

    /* ���������ж� */
    if (spi_i2s_interrupt_flag_get(SPI_IDX1_PORT, SPI_I2S_INT_FLAG_RBNE) != RESET) {
		
	    #if SPI_DATASIZE == DATASIZE_16b	/* 16λ���ݿ��� */
        rword = spi_i2s_data_receive(SPI_IDX1_PORT);
        if (s_scbt[SPI_IND_1].spifirstbit == SPI_ENDIAN_MSB) { // Msb first, rxBuffʼ��ӦΪ���ģʽ������λ�ֽ���ǰ��λ�ֽ��ں�
            for (j= 1; j >= 0; j--) {
            	rcbuff[j] = (INT8U)(rword >> ((INT8U)j*(INT8U)8));
                WriteRoundBuf(&s_scbt[SPI_IND_1].recvrb, rcbuff[j]);
                if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_1].callback_spiintrxmsg(rcbuff[j]);
                }
            }
        } else {
            for (j = 0; j < 2; j++) {
            	rcbuff[j] = (INT8U)(rword >> ((INT8U)j*(INT8U)8));
                WriteRoundBuf(&s_scbt[SPI_IND_1].recvrb, rcbuff[j]);
                if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_1].callback_spiintrxmsg(rcbuff[j]);
                }
            }
        }
	    #else	 /* 8λ���ݿ��� */
        rword = spi_i2s_data_receive(SPI_IDX1_PORT);
        WriteRoundBuf(&s_scbt[SPI_IND_1].recvrb, (INT8U)rword);
        if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
            s_spi_callback[SPI_IND_1].callback_spiintrxmsg((INT8U)rword);
        }
	    #endif
        //SPI_ClearITPendingBit(SPI_IDX1_PORT, SPI_IT_RXNE);                         /* �����־λ */
        
    }

	/* ���������ж� */
    if (spi_i2s_interrupt_flag_get(SPI_IDX1_PORT, SPI_I2S_INT_FLAG_TBE) != RESET) {                     /* ��������ж� */
        //SPI_ITConfig(SPI_IDX2_PORT, SPI_IT_TXE, DISABLE);
        tlen = UsedOfRoundBuf(&s_scbt[SPI_IND_1].sendrb);                      /* �ж�roundbuf���Ƿ�������Ҫ���� */
        if (tlen <= 0) {
            spi_i2s_data_transmit(SPI_IDX1_PORT, 0xFFFF); /* ��Ч��������Ϊ0xFFFF�������õ������MISO �����ߵ�����Ϊ����͵�2�ֽ����ݣ�����7E�����������ݽ�������Ӱ�� */
            s_scbt[SPI_IND_1].status = SPI_STATUS_IDLENOW;                         /* ���ڷ��ͽ���״̬ */
        } else {
            start_send(SPI_IND_1);
        }

        //SPI_ClearITPendingBit(SPI_IDX1_PORT, SPI_IT_TXE);                         /* �����־λ */
    }

    if (spi_i2s_interrupt_flag_get(s_spi_port[SPI_IND_1], SPI_I2S_INT_FLAG_FERR) != RESET) {                     /* */
        //SPI_ClearITPendingBit(s_spi_port[SPI_IND_1], SPI_IT_ERR);                         /* �����־λ */
    }

    if (spi_i2s_interrupt_flag_get(s_spi_port[SPI_IND_1], SPI_I2S_INT_FLAG_RXORERR) != RESET) {                     /* */
        //SPI_ClearITPendingBit(s_spi_port[SPI_IND_1], SPI_IT_OVR);                         /* �����־λ */
    }
    

    //EXIT_CRITICAL();
}

/*******************************************************************
** ������:     USER_DMA1_Stream0_IRQHandler
** ��������:   SPI0��DMA�жϴ��� - �����������ж�
** ����:       ��
** ����:       ��
********************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_DMA1_Stream0_IRQHandler(void) __irq
{
    INT16S readlen = 0;
    INT16S j;
    INT32U ndtr;


    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1],DMA_INT_FLAG_HTF)) {                          /* �뷢���ж� */
        #if DEBGU_SPI > 0
        //Debug_SysPrint("HNDTR:0x%x\r\n", SPI_IDX2_RX_DMA_STREAM->NDTR);
        #endif

        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1],DMA_INT_FLAG_HTF);

        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        if (s_scbt[SPI_IND_1].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_HTIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = (DMA_RCVBUF - s_scbt[SPI_IND_1].readlocat - dma_transfer_number_get(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1]));
        if (readlen < 0) {                                                      /* ����β��������δ���� */
            readlen = DMA_RCVBUF - s_scbt[SPI_IND_1].readlocat;
			if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_1].recvrb, (INT8U *)&(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat]), readlen)){
			}
            for (j = 0; j < readlen; j++) {
                if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_1].callback_spiintrxmsg(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat + j]);
                }
            }
            s_scbt[SPI_IND_1].readlocat = 0;
            readlen = (DMA_RCVBUF - dma_transfer_number_get(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1]) - s_scbt[SPI_IND_1].readlocat);
        }
		if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_1].recvrb, (INT8U *)&(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat]), readlen)){

		}
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
                s_spi_callback[SPI_IND_1].callback_spiintrxmsg(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat + j]);
            }
        }
        s_scbt[SPI_IND_1].readlocat += readlen;
        s_scbt[SPI_IND_1].dmairq = TRUE;
        //DMA_ClearITPendingBit(s_spi_dma_rx_stream[SPI_IND_2], DMA_IT_HTIF3);
    }
	
    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1],DMA_INT_FLAG_FTF)) {                          /* ��ȫ�����ж�*/
        /*
        DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
        DMA_ITConfig(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TC, DISABLE);
        WriteBlockRoundBuf(&s_scbt[idx].recvrb, s_scbt[idx].rcvdmabuf, DMA_RCVBUF);
        DMA_ITConfig(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TC, ENABLE);
        DMA_Cmd(SPI_IDX2_RX_DMA_STREAM, DISABLE);
        DMA_Cmd(SPI_IDX2_RX_DMA_STREAM, ENABLE);
        return;*/

        
        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1], DMA_INT_FLAG_FTF);
        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        //alt_int_count++;
        if (s_scbt[SPI_IND_1].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = (DMA_RCVBUF - s_scbt[SPI_IND_1].readlocat);
		if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_1].recvrb, (INT8U *)&(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat]), readlen)){

		}
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback[SPI_IND_1].callback_spiintrxmsg != NULL) {
                s_spi_callback[SPI_IND_1].callback_spiintrxmsg(s_scbt[SPI_IND_1].rcvdmabuf[s_scbt[SPI_IND_1].readlocat + j]);
            }
        }
        s_scbt[SPI_IND_1].readlocat = 0;
        s_scbt[SPI_IND_1].dmairq = TRUE;
        //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
    }
}


/*******************************************************************
** ������:     USER_DMA1_Stream1_IRQHandler
** ��������:   SPI0��DMA�жϴ��� - �����������ж�
** ����:       ��
** ����:       ��
********************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_DMA1_Stream1_IRQHandler(void) __irq
{
    INT32U tlen;

    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_1],s_spi_dma_tx_stream[SPI_IND_1], DMA_INT_FLAG_FTF)) {                          /* ���ͽ��� */
        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_1],s_spi_dma_tx_stream[SPI_IND_1], DMA_INT_FLAG_FTF);
        //DMA_Cmd(s_spi_dma_tx_stream[SPI_IND_1], DISABLE);                                         /* ����DMA���� */
        //DMA_ITConfig(s_spi_dma_tx_stream[SPI_IND_1], DMA_IT_TC, DISABLE);
		dma_interrupt_disable(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1],DMA_INT_FTF);
		dma_channel_disable(s_spi_dma_periph[SPI_IND_1],s_spi_dma_rx_stream[SPI_IND_1]);
        tlen = UsedOfRoundBuf(&s_scbt[SPI_IND_1].sendrb);                       /* �ж�roundbuf���Ƿ�������Ҫ���� */
        if (tlen <= 0) {
            s_scbt[SPI_IND_1].status = SPI_STATUS_IDLENOW;
        } else {                                                                /* ����������Ҫ���� */
            start_send(SPI_IND_1);
        }
    }
}

/**************************************************************************************************
**  ��������:  USER_SPI2_IRQHandler
**  ��������:  SPI2���жϴ������� - �����Ӻͷ����ж�
**  �������:
**  �������:
**************************************************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_SPI2_IRQHandler(void) __irq
{
    INT32U tlen;
    INT16U rword;
	
    #if SPI_DATASIZE == DATASIZE_16b
    INT16S j;
    INT8U  rcbuff[2] = {0xFF, 0xFF};
    #endif


    //ENTER_CRITICAL();
    
    /* ���������ж� */
    if (spi_i2s_interrupt_flag_get(SPI_IDX2_PORT, SPI_I2S_INT_FLAG_RBNE) != RESET) {
		
        #if SPI_DATASIZE == DATASIZE_16b    /* 16λ���ݿ��� */
        rword = spi_i2s_data_receive(SPI_IDX2_PORT);
        if (s_scbt[SPI_IND_2].spifirstbit == SPI_ENDIAN_MSB) { // Msb first, rxBuffʼ��ӦΪ���ģʽ������λ�ֽ���ǰ��λ�ֽ��ں�
            for (j= 1; j >= 0; j--) {
            	rcbuff[j] = (INT8U)(rword >> ((INT8U)j*(INT8U)8));
                WriteRoundBuf(&s_scbt[SPI_IND_2].recvrb, rcbuff[j]);
                if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_2].callback_spiintrxmsg(rcbuff[j]);
                }
            }
        } else {
            for (j = 0; j < 2; j++) {
            	rcbuff[j] = (INT8U)(rword >> ((INT8U)j*(INT8U)8));
                WriteRoundBuf(&s_scbt[SPI_IND_2].recvrb, rcbuff[j]);
                if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_2].callback_spiintrxmsg(rcbuff[j]);
                }
            }
        }
        #else    /* 8λ���ݿ��� */
        rword = spi_i2s_data_receive(SPI_IDX2_PORT);
        WriteRoundBuf(&s_scbt[SPI_IND_2].recvrb, (INT8U)rword);
        if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
            s_spi_callback[SPI_IND_2].callback_spiintrxmsg((INT8U)rword);
        }
        #endif
        //SPI_ClearITPendingBit(SPI_IDX2_PORT, SPI_IT_RXNE);                         /* �����־λ */ 
    }
	
	/* ���������ж� */
    if (spi_i2s_interrupt_flag_get(SPI_IDX2_PORT, SPI_I2S_INT_FLAG_TBE) != RESET) {                     /* ��������ж� */
        spi_i2s_interrupt_disable(SPI_IDX2_PORT, SPI_I2S_INT_TBE);
		#if 1
        tlen = UsedOfRoundBuf(&s_scbt[SPI_IND_2].sendrb);                      /* �ж�roundbuf���Ƿ�������Ҫ���� */
        if (tlen <= 0) {
            //SPI_SendData(SPI_IDX2_PORT, 0xFFFF); /* ��Ч��������Ϊ0xFFFF�������õ������MISO �����ߵ�����Ϊ����͵�2�ֽ����ݣ�����7E�����������ݽ�������Ӱ�� */
            s_scbt[SPI_IND_2].status = SPI_STATUS_IDLENOW;                         /* ���ڷ��ͽ���״̬ */
        } else {
            start_send(SPI_IND_2);
        }
        #endif
        //SPI_ClearITPendingBit(SPI_IDX2_PORT, SPI_IT_TXE);                         /* �����־λ */
    }

    if (spi_i2s_interrupt_flag_get(s_spi_port[SPI_IND_2], SPI_I2S_INT_FLAG_FERR) != RESET) {                     /* */
       // SPI_ClearITPendingBit(s_spi_port[SPI_IND_2], SPI_IT_ERR);                         /* �����־λ */
    }

    if (spi_i2s_interrupt_flag_get(s_spi_port[SPI_IND_2], SPI_I2S_INT_FLAG_RXORERR) != RESET) {                     /* */
       // SPI_ClearITPendingBit(s_spi_port[SPI_IND_2], SPI_IT_OVR);                         /* �����־λ */
    }
    
    //EXIT_CRITICAL();
}

/*******************************************************************
** ������:     USER_DMA0_Stream1_IRQHandler
** ��������:   SPI2��DMA�жϴ��� - �����������ж�
** ����:       ��
** ����:       ��
********************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_DMA0_Stream1_IRQHandler(void) __irq
{
    INT16S readlen = 0;
    INT16S j;
    INT32U ndtr;

	#if  1

    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2], DMA_INT_FLAG_HTF)) {                          /* �뷢���ж� */
        #if DEBGU_SPI > 0
        //Debug_SysPrint("HNDTR:0x%x\r\n", SPI_IDX2_RX_DMA_STREAM->NDTR);
        #endif
        #if 1
        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2], DMA_INT_FLAG_HTF);

        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        if (s_scbt[SPI_IND_2].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_HTIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = (DMA_RCVBUF - s_scbt[SPI_IND_2].readlocat - dma_transfer_number_get(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2]));
        if (readlen < 0) {                                                      /* ����β��������δ���� */
            readlen = DMA_RCVBUF - s_scbt[SPI_IND_2].readlocat;
			if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_2].recvrb, (INT8U *)&(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat]), readlen)){
			}
            for (j = 0; j < readlen; j++) {
                if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
                    s_spi_callback[SPI_IND_2].callback_spiintrxmsg(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat + j]);
                }
            }
            s_scbt[SPI_IND_2].readlocat = 0;
            readlen = (DMA_RCVBUF - dma_transfer_number_get(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2]) - s_scbt[SPI_IND_2].readlocat);
        }
		if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_2].recvrb, (INT8U *)&(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat]), readlen)){

		}
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
                s_spi_callback[SPI_IND_2].callback_spiintrxmsg(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat + j]);
            }
        }
        s_scbt[SPI_IND_2].readlocat += readlen;
        s_scbt[SPI_IND_2].dmairq = TRUE;
        //DMA_ClearITPendingBit(s_spi_dma_rx_stream[SPI_IND_2], DMA_IT_HTIF3);
        #else
        ndtr = SPI_IDX2_RX_DMA_STREAM->NDTR;
        DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_HTIF3);
        if (ndtr == 0x40) {
            s_ndtr0x40++;
        } else if (ndtr < 0x40){
            s_ndtr0x41++;
        }
        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        half_int_count++;
        if (s_scbt[idx].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_HTIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = DMA_RCVBUF/2;//(DMA_RCVBUF - s_scbt[idx].readlocat - ndtr);
        if (readlen < 0) {                                                      /* ����β��������δ���� */
            readlen = DMA_RCVBUF - s_scbt[idx].readlocat;
			if(WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){

			}
            for (j = 0; j < readlen; j++) {
                if (s_spi_callback.callback_spiintrxmsg != NULL) {
                    s_spi_callback.callback_spiintrxmsg(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat + j]);
                }
            }
            s_scbt[idx].readlocat = 0;
            readlen = (DMA_RCVBUF - ndtr - s_scbt[idx].readlocat);
        }
		if(WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){
			
		}
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback.callback_spiintrxmsg != NULL) {
                s_spi_callback.callback_spiintrxmsg(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat + j]);
            }
        }
        s_scbt[idx].readlocat += readlen;
        s_scbt[idx].dmairq = TRUE;
        //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_HTIF3);
        #endif
    }
	#endif
	
    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2], DMA_INT_FLAG_FTF)) {                          /* ��ȫ�����ж�*/
        #if 1
        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2], DMA_INT_FLAG_FTF);
        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        //alt_int_count++;
        if (s_scbt[SPI_IND_2].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = (DMA_RCVBUF - s_scbt[SPI_IND_2].readlocat);
		if(!WriteBlockRoundBuf(&s_scbt[SPI_IND_2].recvrb, (INT8U *)&(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat]), readlen)){

		}
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback[SPI_IND_2].callback_spiintrxmsg != NULL) {
                s_spi_callback[SPI_IND_2].callback_spiintrxmsg(s_scbt[SPI_IND_2].rcvdmabuf[s_scbt[SPI_IND_2].readlocat + j]);
            }
        }
        s_scbt[SPI_IND_2].readlocat = 0;
        s_scbt[SPI_IND_2].dmairq = TRUE;
        //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
        #else
        ndtr = SPI_IDX2_RX_DMA_STREAM->NDTR;
        DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
        if (ndtr == 0x00) {
            s_ndtr0x80++;
        } else {
            s_ndtr0xet++;
        }
        alt_int_count++;
        /*
        DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
        DMA_ITConfig(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TC, DISABLE);
        WriteBlockRoundBuf(&s_scbt[idx].recvrb, s_scbt[idx].rcvdmabuf, DMA_RCVBUF);
        DMA_ITConfig(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TC, ENABLE);
        DMA_Cmd(SPI_IDX2_RX_DMA_STREAM, DISABLE);
        DMA_Cmd(SPI_IDX2_RX_DMA_STREAM, ENABLE);
        return;*/
        
        //while(SPI_I2S_GetFlagStatus(SPI_IDX2_PORT,SPI_I2S_FLAG_BSY) != RESET){}
        if (s_scbt[idx].timerread == TRUE) {
            //DMA_ClearITPendingBit(SPI_IDX2_RX_DMA_STREAM, DMA_IT_TCIF3);
            return;                        /* ��ʱ�����ڿ������� */
        }

        readlen = DMA_RCVBUF/2;//(DMA_RCVBUF - s_scbt[idx].readlocat - ndtr);
        if (readlen < 0) {                                                      /* ����β��������δ���� */
            readlen = DMA_RCVBUF - s_scbt[idx].readlocat;
			if(WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){

			}
            for (j = 0; j < readlen; j++) {
                if (s_spi_callback.callback_spiintrxmsg != NULL) {
                    s_spi_callback.callback_spiintrxmsg(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat + j]);
                }
            }
            s_scbt[idx].readlocat = 0;
            readlen = (DMA_RCVBUF - ndtr - s_scbt[idx].readlocat);
        }
		if(WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){
			
		}
		
        for (j = 0; j < readlen; j++) {
            if (s_spi_callback.callback_spiintrxmsg != NULL) {
                s_spi_callback.callback_spiintrxmsg(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat + j]);
            }
        }
        s_scbt[idx].readlocat =0;//+= readlen;
        s_scbt[idx].dmairq = TRUE;
        #endif
    }
}


/*******************************************************************
** ������:     USER_DMA0_Stream2_IRQHandler
** ��������:   SPI2��DMA�жϴ��� - �����������ж�
** ����:       ��
** ����:       ��
********************************************************************/
static __attribute__ ((section ("IRQ_HANDLE"))) void USER_DMA0_Stream2_IRQHandler(void) __irq
{
    INT32U tlen;

    if (dma_interrupt_flag_get(s_spi_dma_periph[SPI_IND_2],s_spi_dma_tx_stream[SPI_IND_2], DMA_INT_FLAG_FTF)) {                          /* ���ͽ��� */
        dma_interrupt_flag_clear(s_spi_dma_periph[SPI_IND_2],s_spi_dma_tx_stream[SPI_IND_2], DMA_INT_FLAG_FTF);
		dma_interrupt_disable(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2],DMA_INT_FTF);
		dma_channel_disable(s_spi_dma_periph[SPI_IND_2],s_spi_dma_rx_stream[SPI_IND_2]);
        tlen = UsedOfRoundBuf(&s_scbt[SPI_IND_2].sendrb);                       /* �ж�roundbuf���Ƿ�������Ҫ���� */
        if (tlen <= 0) {
            s_scbt[SPI_IND_2].status = SPI_STATUS_IDLENOW;
        } else {                                                                /* ����������Ҫ���� */
            start_send(SPI_IND_2);
        }
    }
}


/*******************************************************************
** ������:     send_dma_config
** ��������:   SPIX_DMA���Ͳ������� - ������Ĭ���ǽ��õ�
** ����:       [in] index: SPI��
** ����:       ��
********************************************************************/
static void send_dma_config(SPI_IND_E idx)
{
   dma_parameter_struct ICB;

	ICB.memory_addr			= (INT32U)s_scbt[idx].rcvdmabuf;
	ICB.memory_inc			= DMA_MEMORY_INCREASE_ENABLE;
	ICB.memory_width		= DMA_MEMORY_WIDTH_8BIT;
	ICB.number				= sizeof(s_scbt);
	ICB.periph_addr			= SPI_DATA(s_spi_port[idx]);
	ICB.periph_inc			= DMA_PERIPH_INCREASE_DISABLE;
	ICB.periph_width		= DMA_PERIPHERAL_WIDTH_8BIT;
	ICB.priority			= DMA_PRIORITY_ULTRA_HIGH;
	ICB.direction			= DMA_PERIPHERAL_TO_MEMORY;
	
    dma_deinit(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]);
    dma_init(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx], &ICB);
    //s_spi_dma_rx_stream[idx]->NDTR = (INT32U)DMA_RCVBUF;
    dma_circulation_disable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]);
	dma_memory_to_memory_disable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]);
	
	dma_interrupt_enable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx],DMA_INT_HTF);
	dma_interrupt_enable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx],DMA_INT_FTF);
	dma_channel_enable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]);                                     /* ���Ƚ��ã�Ҫ��������ʱ������ */
}

/*******************************************************************
** ������:     rcv_dma_config
** ��������:   SPIX_DMA���ղ������� - ������Ĭ���ǽ��õ�
** ����:       [in] index: SPI��
** ����:       ��
********************************************************************/
static void rcv_dma_config(SPI_IND_E idx)
{
     dma_parameter_struct ICB;

	ICB.periph_addr			   = (INT32U)&SPI_DATA(s_spi_port[idx]);
    ICB.memory_addr			   = (INT32U)s_scbt[idx].senddmabuf;              /* ָ��DMA��������ַ */
    ICB.direction			   = DMA_MEMORY_TO_PERIPHERAL;
    ICB.number				   = sizeof(s_scbt);
    ICB.periph_inc			   = DMA_PERIPH_INCREASE_DISABLE;
    ICB.memory_inc			   = DMA_MEMORY_INCREASE_ENABLE;
    ICB.periph_width		   = DMA_PERIPHERAL_WIDTH_16BIT;
    ICB.memory_width		   = DMA_MEMORY_WIDTH_16BIT;
	ICB.priority			   = DMA_PRIORITY_ULTRA_HIGH;

    dma_deinit(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx]);
    dma_init(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx], &ICB);
	dma_circulation_disable(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx]);
	dma_memory_to_memory_disable(s_spi_dma_periph[idx],s_spi_dma_tx_stream[idx]);
	//DMA_ITConfig(s_spi_dma_tx_stream[idx], DMA_IT_TC, DISABLE);
    //DMA_Cmd(s_spi_dma_tx_stream[idx], DISABLE);                                     /* ���Ƚ��ã�Ҫ��������ʱ������ */
	dma_interrupt_disable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx],DMA_INT_FTF);
	dma_channel_disable(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]); 
}

/*******************************************************************
** ������:     work_mode_config
** ��������:   SPIX�Ĺ���ģʽ���� - ������Ĭ���ǽ��õ�
** ����:       [in] idx        : spi���
               [in] mode       : SPI_Mode_Master or SPI_Mode_Slave
               [in] baud_pres  : SCKʱ�ӵĲ�����Ԥ��Ƶ��ֵ
               [in] clock_mode : ʱ��ģʽ(0~3:mode0 ~ mode3)
** ����:       ��
**  ע������:  RCC_APB2PeriphClockCmd���һ��Ҫ����������ʼ��ָ��֮ǰ
********************************************************************/
static void work_mode_config(SPI_IND_E idx, INT16U mode, INT16U baud_pres , INT8U clock_mode)
{
    spi_parameter_struct ICB;

    #if DEBGU_SPI > 0
    Debug_SysPrint("spi work_mode_config ����ģʽ:0x%x ʱ��ѡ��:%d\r\n", mode, baud_pres);
    #endif

    memset(&ICB, 0, sizeof(ICB));

    //ICB.= SPI_Direction_2Lines_FullDuplex;
#if SPI_DATASIZE == DATASIZE_16b
    ICB.frame_size   = SPI_FRAMESIZE_16BIT;
#else
    ICB.frame_size	 = SPI_FRAMESIZE_8BIT;
#endif
    if (clock_mode == 0) {
        ICB.clock_polarity_phase 	= SPI_CK_PL_LOW_PH_1EDGE;
    } else if (clock_mode == 1) {
        ICB.clock_polarity_phase 	= SPI_CK_PL_LOW_PH_2EDGE;
    } else if (clock_mode == 2) {
        ICB.clock_polarity_phase 	= SPI_CK_PL_HIGH_PH_1EDGE;
    } else {
        ICB.clock_polarity_phase 	= SPI_CK_PL_HIGH_PH_2EDGE;
    }
	ICB.trans_mode           	= SPI_TRANSMODE_FULLDUPLEX;
    ICB.device_mode          	= mode;
    ICB.frame_size           	= SPI_FRAMESIZE_8BIT;
    ICB.nss                  	= SPI_NSS_SOFT;
    ICB.prescale             	= baud_pres;
    ICB.endian              	= SPI_ENDIAN_MSB;
    s_scbt[idx].spifirstbit = ICB.endian;                              /* ����MSB/LSB״̬ */

    #if DEBGU_SPI > 0
    Debug_SysPrint("spi work_mode_config ���ݿ���:0x%x\r\n", ICB.SPI_DataSize);
    #endif

    if (s_scbt[idx].dma_en == SPI_LOOP_MODE_ENABLE) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("spi work_mode_config ����ΪLOOPģʽ\r\n");
        #endif
        spi_i2s_deinit(s_spi_port[idx]);
        spi_init(s_spi_port[idx], &ICB);
		spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_RBNE);
        spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_TBE);

		spi_i2s_interrupt_enable(s_spi_port[idx],SPI_I2S_INT_ERR);
        
        spi_enable(s_spi_port[idx]);

	} else if (s_scbt[idx].dma_en == SPI_DMA_MODE_DISABLE) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("spi work_mode_config ����Ϊ�ж�ģʽ\r\n");
        #endif
        spi_i2s_deinit(s_spi_port[idx]);
        spi_init(s_spi_port[idx], &ICB);
		spi_i2s_interrupt_enable(s_spi_port[idx],SPI_I2S_INT_RBNE);
        spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_TBE);

        spi_i2s_interrupt_enable(s_spi_port[idx],SPI_I2S_INT_ERR);
        
        spi_disable(s_spi_port[idx]);
    } else {
        spi_i2s_deinit(s_spi_port[idx]);
        spi_init(s_spi_port[idx], &ICB);
        //SPI_NSSInternalSoftwareConfig(SPI_IDX2_PORT, SPI_NSSInternalSoft_Reset);
        spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_RBNE);
        spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_TBE);

        spi_i2s_interrupt_enable(s_spi_port[idx],SPI_I2S_INT_ERR);
        spi_enable(s_spi_port[idx]);
    }

    s_scbt[idx].status = SPI_STATUS_DISABLE;                                     /* ��ʼ����ɺ�Ĭ�����ڽ���״̬ */
}

/*******************************************************************
** ������:     spix_delaytmrproc
** ��������:   ��ʱɨ��DMA���ջ����������
** ����:       ��
** ����:       ��
********************************************************************/
static void spix_delaytmrproc(void)
{
    INT16S readlen = 0;
    INT8U NDTR  = 0;
    INT8U idx;
	
	for (idx = 0; idx < MAX_SPI_IND; idx++) {
		if (s_scbt[idx].dma_en == SPI_DMA_MODE_DISABLE) {
			return;
		}
		
		if ((s_scbt[idx].status == SPI_STATUS_DISABLE) || (s_scbt[idx].status == SPI_STATUS_INITING)) {
			return;
		}
		
		NDTR = dma_transfer_number_get(s_spi_dma_periph[idx],s_spi_dma_rx_stream[idx]);
		
		ENTER_CRITICAL();
		if (s_scbt[idx].dmairq == TRUE) {
			s_scbt[idx].dmairq	 = FALSE;
			s_scbt[idx].oldlocat = NDTR;
			EXIT_CRITICAL() ;
			return; 														  /* ����ǰ��ɨ����н����жϣ����˳� */
		}
		if (s_scbt[idx].oldlocat == NDTR) { 									  /* һ����ʱʱ����û�յ������� */
			s_scbt[idx].timerread = TRUE;
		} else {
			s_scbt[idx].timerread = FALSE;
		}
		EXIT_CRITICAL();
		
		if (s_scbt[idx].timerread == TRUE) {									  /* һ����ʱʱ����û�յ������� */
			readlen = (DMA_RCVBUF - NDTR - s_scbt[idx].readlocat);
			if (readlen == 0) { 												/* û�յ������ݣ������Ѷ��� */
				s_scbt[idx].timerread = FALSE;
				s_scbt[idx].oldlocat = NDTR;
				return;
			} else if (readlen < 0) {											/* ����β��������δ���� */
				readlen = DMA_RCVBUF - s_scbt[idx].readlocat;
				if(!WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){
		
				}
				s_scbt[idx].readlocat = 0;
				readlen = (DMA_RCVBUF - NDTR - s_scbt[idx].readlocat);
			}
			if(!WriteBlockRoundBuf(&s_scbt[idx].recvrb, (INT8U *)&(s_scbt[idx].rcvdmabuf[s_scbt[idx].readlocat]), readlen)){
			}
			s_scbt[idx].readlocat +=  (INT8U )readlen;
		}
		s_scbt[idx].timerread = FALSE;
		s_scbt[idx].oldlocat  = NDTR;

	}


}

/*******************************************************************
** ������:     Spix_Initiate
** ��������:   ��ʼ��SPIX(�˴�Ҳ������DMA) - ��ʼ�����Ĭ���ǽ��õ�
** ����:       [in] spi_mode :����/�ӻ�ģʽ
               [in] dma_mode : dma/�ж�ģʽ
               [in] baud_pres : Ԥ��Ƶ
               [in] clock_mode : ʱ��ģʽ(0~3:mode0 ~ mode3)
** ����:       ��
********************************************************************/
static BOOLEAN Spix_Initiate(SPI_IND_E idx, INT16U spi_mode, INT8U dma_mode, INT16U baud_pres, INT8U clock_mode)
{
    s_scbt[idx].status = SPI_STATUS_INITING;

    /* ���ջ��λ����� */
    if (s_scbt[idx].p_rx != NULL) {
        MemFree(s_scbt[idx].p_rx);
    }
    s_scbt[idx].p_rx = MemAlloc(SPI_ROUNDBUF_RX_LEN);
    if (s_scbt[idx].p_rx == NULL) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("<**** Spix_Initiate(),����RX��̬�ڴ�ʧ��****>\r\n");
        #endif		
        return FALSE;
    }
    s_scbt[idx].rx_len = SPI_ROUNDBUF_RX_LEN;
	/* ��ʼ�����ջ��� */
	InitRoundBuf(&s_scbt[idx].recvrb, s_scbt[idx].p_rx, s_scbt[idx].rx_len, 0);

    /* ���ͻ��λ����� */
    if (s_scbt[idx].p_tx != NULL) {
        MemFree(s_scbt[idx].p_tx);
    }
    s_scbt[idx].p_tx = MemAlloc(SPI_ROUNDBUF_TX_LEN);
    if (s_scbt[idx].p_tx == NULL) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("<**** Spix_Initiate(),����TX��̬�ڴ�ʧ��****>\r\n");
        #endif			
        return FALSE;
    }
    s_scbt[idx].tx_len = SPI_ROUNDBUF_TX_LEN;
	/* ��ʼ�����ͻ��� */
    InitRoundBuf(&s_scbt[idx].sendrb, s_scbt[idx].p_tx, s_scbt[idx].tx_len, 0);

    if (dma_mode == SPI_LOOP_MODE_ENABLE) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("spi Spix_Initiate LOOPģʽ\r\n");
         #endif
		
        s_scbt[idx].dma_en = SPI_LOOP_MODE_ENABLE;
        work_mode_config(idx, spi_mode, baud_pres, clock_mode); /* ����SPI����ģʽ */
		if (idx == SPI_IND_1) {
            NVIC_IrqHandleInstall(SPI0_IRQ, USER_SPI0_IRQHandler, UART_RX_PRIOTITY, TRUE);
		} else if (idx == SPI_IND_2) {
            NVIC_IrqHandleInstall(SPI2_IRQ, USER_SPI2_IRQHandler, UART_RX_PRIOTITY, TRUE);
		} 

	} else if (SPI_DMA_MODE_DISABLE == dma_mode) {
        #if DEBGU_SPI > 0
        Debug_SysPrint("spi Spix_Initiate �ж�ģʽ\r\n");
        #endif
		
        s_scbt[idx].dma_en = SPI_DMA_MODE_DISABLE;
        work_mode_config(idx, spi_mode, baud_pres, clock_mode); /* ����SPI����ģʽ */
		if (idx == SPI_IND_1) {
            NVIC_IrqHandleInstall(SPI0_IRQ, USER_SPI0_IRQHandler, UART_RX_PRIOTITY, TRUE);
		} else if (idx == SPI_IND_2) {
            NVIC_IrqHandleInstall(SPI2_IRQ, USER_SPI2_IRQHandler, UART_RX_PRIOTITY, TRUE);
		} 
        
    } else {
        rcu_periph_clock_enable(RCU_DMA1);
		rcu_periph_clock_enable(RCU_DMA0);
        #if DEBGU_SPI > 1
        Debug_SysPrint("spi Spix_Initiate DMAģʽ\r\n");
        #endif
        s_scbt[idx].dma_en    = SPI_DMA_MODE_ENABLE;
        s_scbt[idx].timerread = FALSE;
        s_scbt[idx].dmairq    = TRUE;
        s_scbt[idx].oldlocat  = DMA_RCVBUF;
        s_scbt[idx].readlocat = 0;
        s_scbt[idx].rcvdmabuf = s_spi_dmarecvbuf[idx];
        s_scbt[idx].senddmabuf= s_spi_dmasendbuf[idx];

        work_mode_config(idx, spi_mode, baud_pres, clock_mode); /* ����SPI����ģʽ */
        rcv_dma_config(idx);
        send_dma_config(idx);
		if (idx == SPI_IND_1) {
			NVIC_IrqHandleInstall(SPI0_IRQ, USER_SPI0_IRQHandler, UART_RX_PRIOTITY, TRUE);
			NVIC_IrqHandleInstall(DMA0_C1_IRQ, USER_DMA0_Stream1_IRQHandler, UART_RX_PRIOTITY, TRUE);	//		UART_TXDMA_PRIOTITY
			NVIC_IrqHandleInstall(DMA0_C2_IRQ, USER_DMA0_Stream2_IRQHandler, UART_TXDMA_PRIOTITY, TRUE);
		} else if (idx == SPI_IND_2) {
			NVIC_IrqHandleInstall(SPI2_IRQ, USER_SPI2_IRQHandler, UART_RX_PRIOTITY, TRUE);
			NVIC_IrqHandleInstall(DMA1_C0_IRQ, USER_DMA1_Stream0_IRQHandler, UART_RX_PRIOTITY, TRUE);	//		UART_TXDMA_PRIOTITY
			NVIC_IrqHandleInstall(DMA1_C1_IRQ, USER_DMA1_Stream1_IRQHandler, UART_TXDMA_PRIOTITY, TRUE);
		} 
		if (s_is_creat == FALSE) {
			s_spi_tmr_id = CreateTimer(spix_delaytmrproc);
			s_is_creat = TRUE;
		}
		StartTimer(s_spi_tmr_id, _TICK, 1, TRUE);

    }
    return TRUE;
}
 
/*******************************************************************
** ������:     Spix_IOConfig
** ��������:   SPIX��IO������
** ����:       ��
** ����:       ��
********************************************************************/
static void Spix_IOConfig(SPI_IND_E idx)
{
    #if DEBGU_SPI > 0
    Debug_SysPrint("<**** ��ʼ��spi_idx %d��spiͨѶ�� ****>\r\n",idx);
    #endif

    if (idx == SPI_IND_1) {
        rcu_periph_clock_enable(RCU_AF);
		rcu_periph_clock_enable(RCU_SPI0);
		rcu_periph_clock_enable(SPI1_PIN_IO);
		/* ���ô��ڹܽŲ��������� */
		gpio_init(SPI1_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,SPI1_PIN_SCK);
		gpio_init(SPI1_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,SPI1_PIN_MOSI);
		gpio_init(SPI1_PIN_IO,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,SPI1_PIN_MISO);
		gpio_init(SPI1_PIN_IO,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,SPI1_PIN_CS);
    } else if (idx == SPI_IND_2) {
        rcu_periph_clock_enable(RCU_AF);
        rcu_periph_clock_enable(RCU_SPI2);
		rcu_periph_clock_enable(SPI4_PIN_IO);
		
        /* ���ô��ڹܽŲ��������� */
		gpio_init(SPI4_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,SPI4_PIN_SCK);
		gpio_init(SPI4_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,SPI4_PIN_MOSI);
		gpio_init(SPI4_PIN_IO,GPIO_MODE_IN_FLOATING,GPIO_OSPEED_50MHZ,SPI4_PIN_MISO);
		gpio_init(SPI4_PIN_IO,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,SPI4_PIN_CS);
    } 
}

/*******************************************************************
** ������:     Spix_Enable
** ��������:   ����SPIX
** ����:       ��
** ����:       ��
********************************************************************/
static void Spix_Enable(SPI_IND_E idx)
{
	spi_enable(s_spi_port[idx]);
    s_scbt[idx].status = SPI_STATUS_IDLENOW;
}

/*******************************************************************
** ������:     Spix_Disable
** ��������:   ͣ��SPIX
** ����:       ��
** ����:       ��
********************************************************************/
static void Spix_Disable(SPI_IND_E idx)
{
    s_scbt[idx].status = SPI_STATUS_DISABLE;

    spi_disable(s_spi_port[idx]);
}

/*******************************************************************
** ������:     Spix_GetDmaMode
** ��������:   ��ȡ�վ��շ�ģʽ
** ����:       ��
** ����:       0x00: �ж�ģʽ
               0x01: DMAģʽ
********************************************************************/
INT8U Spix_GetDmaMode(SPI_IND_E idx)
{
    return s_scbt[idx].dma_en;
}

/*******************************************************************
** ������:     Spix_LeftofBuf
** ��������:   ��ȡָ�����ڵķ��ͻ�����ʣ��ռ�
** ����:       ��
** ����:       ʣ��ռ䳤��
********************************************************************/
INT32S Spix_LeftofBuf(SPI_IND_E idx)
{
    if ((s_scbt[idx].status != SPI_STATUS_IDLENOW) && (s_scbt[idx].status != SPI_STATUS_SENDING)) {
        return -1;
    } else {
        return LeftOfRoundBuf(&s_scbt[idx].sendrb);
    }
}

/*******************************************************************
** ������:     Spix_ReadByte
** ��������:   SPIX��ȡ�����ֽ�
** ����:       [in] idx : spi���
** ����:       ʣ��ռ䳤��
********************************************************************/
INT32S Spix_ReadByte(SPI_IND_E idx)
{
    if (s_scbt[idx].dma_en == SPI_LOOP_MODE_ENABLE) {
        return ReadSPI(idx);
    } else {
        return ReadRoundBuf(&s_scbt[idx].recvrb);
    }
}

/*******************************************************************
** ������:     Spix_RecvBufUsed
** ��������:   SPIX���յĴ�С
** ����:       [in] idx : spi���
** ����:       ���մ�С
********************************************************************/
INT32U Spix_RecvBufUsed(SPI_IND_E idx)
{
    return  UsedOfRoundBuf(&s_scbt[idx].recvrb);
}

/*******************************************************************
** ������:     Spix_RecvBufReset
** ��������:   ��λ���ջ���
** ����:       [in] idx : spi���
** ����:       ��
********************************************************************/
void Spix_RecvBufReset(SPI_IND_E idx)
{
    ResetRoundBuf(&s_scbt[idx].recvrb);
}

/*******************************************************************
** ������:     Spix_SendByte
** ��������:   SPIX���͵����ֽ�
** ����:       [in] byte: �ֽ�����
** ����:       ��
********************************************************************/
BOOLEAN Spix_SendByte(SPI_IND_E idx, INT8U byte)
{
    if (s_scbt[idx].dma_en == SPI_LOOP_MODE_ENABLE) {
        if (WriteSPI(idx, byte) == (-1)) {
            return FALSE;
		}
	} else {
		if (WriteRoundBuf(&s_scbt[idx].sendrb, byte)) {
			if (s_scbt[idx].status == SPI_STATUS_IDLENOW) { 						  /* ���ڿ���״̬�����ÿ�ʼ���� */
				return start_send(idx);
			} else if (s_scbt[idx].status == SPI_STATUS_SENDING) {					  /* ���ڷ���״̬ */
				return TRUE;
			} else {
				return FALSE;
			}
		} else {
			return FALSE;
		}
	}
	return TRUE;
}

/*******************************************************************
** ������:     Spix_SendData
** ��������:   SPIX������������
** ����:       [in] ptr:   ����ָ��
**             [in] tlen:  ���ݳ���
** ����:       ���ͽ��
********************************************************************/
BOOLEAN Spix_SendData(SPI_IND_E idx, INT8U *ptr, INT32U tlen)
{
    INT32U i;
    if ((ptr == 0) || (tlen == 0)) {
        return FALSE;
    }
    if (s_scbt[idx].dma_en == SPI_LOOP_MODE_ENABLE) {
		for (i = 0; i < tlen; i++) {
			if (WriteSPI(idx, ptr[i]) == (-1)) {
				return FALSE;
			}
		}
	} else {
        #if EN_DEBUG > 1
    		Debug_SysPrint("< Spix_SendData:%d wait to send:%d>\r\n",s_scbt[idx].status,UsedOfRoundBuf(&s_scbt[idx].sendrb));
        #endif
        if (WriteBlockRoundBuf(&s_scbt[idx].sendrb, ptr, tlen)) {
            if (s_scbt[idx].status == SPI_STATUS_IDLENOW) {                           /* ���ڿ���״̬�����ÿ�ʼ���� */
                return start_send(idx);
            } else if (s_scbt[idx].status == SPI_STATUS_SENDING) {                    /* ���ڷ���״̬ */
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            return FALSE;
        }
  	}
	return TRUE;
}

/*******************************************************************
** ������:     Spix_Open_Port
** ��������:   ��SPI�˿�
** ����:       [in] spi_mode : 0Ϊ����ģʽ; 1Ϊ�ӻ�ģʽ
               [in] dma_mode : dma/�ж�ģʽ/loop
               [in] bps      : ������
               [in] clock_mode : ʱ��ģʽ(0~3:mode0 ~ mode3)
** ����:       TRUE ���ɹ�   FALSE ��ʧ��
********************************************************************/
BOOLEAN Spix_Open_Port(SPI_IND_E idx, INT8U spi_mode, INT8U dma_mode, INT16U bps, INT8U clock_mode)
{
    INT16U SpiMode, SpiPrescal;

    #if DEBGU_SPI > 0
	   Debug_SysPrint("<**** Spix_Open_Port(),idx:%d,mode:%d, dma_mode:%d,bps:%d,clk_mode:%d ****>\r\n",idx, spi_mode, dma_mode, bps, clock_mode);
    #endif
    
    #if 1
    if (spi_mode == 0x00) {                             /* ����ģʽ */
        SpiMode = SPI_MASTER;
    } else if (spi_mode == 0x01) {                      /* �ӻ�ģʽ */
        SpiMode = SPI_SLAVE;
    } else {
        return FALSE;
    }

    if (bps > 4000) { /* 4M */
        SpiPrescal = SPI_PSC_8;
    } else if (bps > 2000) { /* 2M */
        SpiPrescal = SPI_PSC_16;
    } else if (bps > 1000) { /* 1M */
        SpiPrescal = SPI_PSC_32;
    } else if (bps > 500) { /* 500K */
        SpiPrescal = SPI_PSC_64;
    } else if (bps > 250) { /* 250K */
        SpiPrescal = SPI_PSC_128;
    } else if (bps > 125) { /* 125K */
        SpiPrescal = SPI_PSC_256;
    } else {
        SpiPrescal = SPI_PSC_32;
    }

    #else
    SpiMode = SPI_Mode_Slave;
    SpiPrescal = SPI_BaudRatePrescaler_32;
    #endif
	
    #if DEBGU_SPI > 0
    Debug_SysPrint("<**** Spix_Open_Port(),prescale:0x%x ****>\r\n",SpiPrescal);
    #endif

    if (s_scbt[idx].status == SPI_STATUS_CLOSED) {
        Spix_IOConfig(idx);
        if (Spix_Initiate(idx, SpiMode, dma_mode, SpiPrescal, clock_mode) == FALSE) {
            #if DEBGU_SPI > 0
            Debug_SysPrint("<**** Spix_Open_Port(),��ʼ��ʧ�� ****>\r\n");
            #endif
            return FALSE;
        }
        Spix_Enable(idx);
    }
    #if DEBGU_SPI > 0
    Debug_SysPrint("<**** Spix_Open_Port(),��ʼ���ɹ� ****>\r\n");
    #endif
    return TRUE;
}

/*******************************************************************
** ������:     Spix_Close_Port
** ��������:   �ر�SPI�˿�
** ����:       ��
** ����:       TRUE ���ɹ�   FALSE ��ʧ��
********************************************************************/
BOOLEAN Spix_Close_Port(SPI_IND_E idx)
{
    if (s_scbt[idx].status != SPI_STATUS_CLOSED) {
		spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_RBNE);
		spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_TBE);
		spi_i2s_interrupt_disable(s_spi_port[idx],SPI_I2S_INT_ERR);
		Spix_Disable(idx);
		spi_i2s_deinit(s_spi_port[idx]);
        /* �ͷ��ڴ� */
        if (s_scbt[idx].p_rx != NULL) {
            MemFree(s_scbt[idx].p_rx);
            s_scbt[idx].p_rx = NULL;
            s_scbt[idx].rx_len = 0;
        }

        if (s_scbt[idx].p_tx != NULL) {
            MemFree(s_scbt[idx].p_tx);
            s_scbt[idx].p_tx = NULL;
            s_scbt[idx].tx_len = 0;
        }

        /* ����״̬ */
        s_scbt[idx].status = SPI_STATUS_CLOSED;
    }

    return TRUE;
}

/*******************************************************************
** ������:     Spix_RegistHandler  ���²�
** ��������:   ע��SPIģ���жϽ��ջص�����
** ����:       [in] ReceivedDat��Ҫ���յ�������
** ����:       ��
********************************************************************/
void Spix_RegistHandler(SPI_IND_E idx, INT8U (* handle) (INT8U ReceivedDat))
{
    s_spi_callback[idx].callback_spiintrxmsg = handle;
}

/*******************************************************************
** ������:     Spix_IsSendIle
** ��������:   �����Ƿ��ڿ���״̬
** ����:       [in] idx : spi���
** ����:       TRUE : ���� FALSE: �ǿ���״̬
********************************************************************/
BOOLEAN Spix_IsSendIle(SPI_IND_E idx)
{
    if (s_scbt[idx].status == SPI_STATUS_IDLENOW) {
        return TRUE;
	}
    return FALSE;
}

