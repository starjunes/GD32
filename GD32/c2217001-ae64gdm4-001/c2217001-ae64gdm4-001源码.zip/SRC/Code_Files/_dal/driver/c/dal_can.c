/********************************************************************************
**
** �ļ���:     dal_can.c
** ��Ȩ����:   (c) 2014-2020 ������Ѹ����ɷ����޹�˾
** �ļ�����:   CAN����ͨ������ģ��
**
*********************************************************************************
**             �޸���ʷ��¼
**===============================================================================
**| ����       | ����   |  �޸ļ�¼
**===============================================================================
**| 2015/12/29 | JUMP   | ������ģ��
**
*********************************************************************************/
#include  "dal_include.h"
#include  "dal_can.h"
#include  "man_irq.h"
#include  "tools.h"
#include  "roundbuf.h"
#include  "man_timer.h"
#include  "dmemory.h"
#include  "dal_pinlist.h"
#include  "dal_gpio.h"
#include  "scanner.h"
#include  "yx_debugcfg.h"
#include  "yx_can_man.h"

#define     CAN_SEND_PKG_LEN        13

#define     CAN_SEND_IDLENOW        0
#define     CAN_SEND_BUSY           1

/*************************************************************************************************/
/*                           ���λ��������ƿ�                                                    */
/*************************************************************************************************/
typedef struct {
    INT8U          bk_bufsize;                                       /* ���λ������ */
    INT8U          bk_used;                                          /* ��ʹ�õĻ��λ���� */
    INT8U          **bk_bptr;                                        /* ��ʼ�Ļ��λ���� */
    INT8U          **bk_eptr;                                        /* �����Ļ��λ���� */
    INT8U          **bk_wptr;                                        /* ��ʼд��Ļ��λ���� */
    INT8U          **bk_rptr;                                        /* ��ʼ��ȡ�Ļ��λ���� */
} ROUNDBLOCK_T;

/*************************************************************************************************/
/*                           ģ��ṹ�嶨��                                                      */
/*************************************************************************************************/
typedef struct {
    FILTER_T      idcbt[MAX_RXIDOBJ + 1];                            /* ID�������� */
    INT32U        screenid_last;                                     /* ��ΪԤ����һ·�˲�������id�����ڳ���13���˲����ĳ��� */
} CAN_FILTER_T;
#if 0
typedef struct {
    INT8U         rxobjused;                                         /* �洢ʹ���˶��ٸ����ն������ */
    INT8U         recvcnt;                                           /* ���յ����ݰ�������ˮ�� */
    IDPARA_T      idcbt[MAX_CANIDS];                                 /* ID�������� */
} CAN_MSG_T;
#endif
typedef struct {
    INT8U         sdobjused;                                         /* �洢ʹ���˶��ٸ����Ͷ������ */
    ID_SEND_T     idcbt[MAX_RXIDOBJ];                                /* ID�������� */
} CAN_SEND_T;

/*************************************************************************************************/
/*                           CAN�ص�APP��ṹ��                                                  */
/*************************************************************************************************/
typedef struct {
    CAN_LBINDEX_E index;                                             /* �ص������� */
    void volatile (*lbhandle) (CAN_DATA_HANDLE_T *CAN_msg);                 /* �ص�����ָ�� */
} CAN_LBAPP_E;

/*************************************************************************************************/
/*                           ģ�龲̬��������                                                    */
/*************************************************************************************************/
static CAN_ATTR_T     s_ccbt[MAX_CANCHAN];                           /* CAN���ƿ� */
static CAN_FILTER_T   s_can_filter[MAX_CANCHAN];                     /* CAN�������� */
//static CAN_MSG_T      s_msgbt[MAX_CANCHAN];                          /* ���յ�CAN��Ϣ�� */
static CAN_SEND_T     s_msg_period[MAX_CANCHAN];                     /* ���ڷ��͵�CAN��Ϣ�� */

static CAN_LBAPP_E    s_lbfunctionentry[LB_MAX];
static INT8U          s_can_buf[sizeof(CAN_DATA_HANDLE_T) * 40];
static INT8U          s_can_send_buf[MAX_CANCHAN][CAN_SEND_PKG_LEN * 60];
static ROUNDBUF_T     s_can_send_round[MAX_CANCHAN];
static ROUNDBUF_T     s_can_round;
static BOOLEAN        s_sendstat[MAX_CANCHAN] = {0};

static INT32U pried,sendcnttest1 = 0,sendcnttest2=0,recvcnt1,recvcnt2;
/*******************************************************************
** ������:     can_msg_handler
** ��������:   ���Ĵ�������
** ����:       [in] CAN_msg            ������Ϣ
** ����:       ��
********************************************************************/
static void can_msg_handler(CAN_DATA_HANDLE_T CAN_msg)
{
	#if 0
    INT8U        tempbuf[220];
    INT8U        rxobj;
    INT8U        i, j;
    INT16U       len;
  #endif  
	INT32U       id;
	if (s_lbfunctionentry[LB_ANALYZE].lbhandle != NULL) {
        s_lbfunctionentry[LB_ANALYZE].lbhandle(&CAN_msg);
    }

    Chartolong(&id, CAN_msg.id);
    recvcnt1++;

    #if 0
    Chartolong(&id, CAN_msg.id);
    /* UDS��J1939��֡ID�ظ��ϱ������޸� */
    if (((id == 0x18DAEEFA) || (id == 0x18DA33FA) || (id == 0x18DAFA33) || (id == 0x18DAF100) || (id == 0x18DAF110)) && ((CAN_msg.databuf[0] & 0xF0) != 0x00)){ /* ��֡���� */
         return;
    }
    if (((id & 0x00FF0000) == 0x00EC0000) || ((id & 0x00FF0000) == 0x00EB0000)) {  /* �Ѿ���Ϊ����֡��������ֱ�ӷ��� */
        if (((id & 0x0000FF00) == 0x0000FF00) || ((id & 0x0000FF00) == 0x00008100) || ((id & 0x0000FF00) == 0x0000FD00)){
            return;
        }
    }

    if (s_ccbt[CAN_msg.channel].filteronoff == CAN_FILTER_OFF) {                /* û�˲�͸��ģʽ */
        s_msgbt[CAN_msg.channel].recvcnt++;
        tempbuf[0] = CAN_msg.channel + 1;                                       /* CANͨ����,Ŀǰ��ʱ�̶�Ϊͨ��1 */
        MMI_MEMCPY(&tempbuf[1], sizeof(tempbuf) - 1, CAN_msg.id, 4);            /* ID */
        tempbuf[5] = CAN_msg.type;
        tempbuf[6] = 0;
        tempbuf[7] = 0;
        tempbuf[8] = s_msgbt[CAN_msg.channel].recvcnt;                          /* ��ˮ�� */
        tempbuf[9] = CAN_msg.len;                                               /* ���ݰ����� */
        MMI_MEMCPY(&tempbuf[10], sizeof(tempbuf) - 10, CAN_msg.databuf, CAN_msg.len);/* �������ݰ� */
        if (s_lbfunctionentry[LUCIDLY_REPORT].lbhandle != PNULL) {
            s_lbfunctionentry[LUCIDLY_REPORT].lbhandle(tempbuf, CAN_msg.len + 10);/* 1��CANͨ��)+���ݳ���Ϊ 4(ID)+4(��ˮ��)+1(������ݳ���)+���ݳ��� */
        }
        return;
    }

    for (i = 0; i < MAX_CANIDS; i++) {
        if ((id == s_msgbt[CAN_msg.channel].idcbt[i].id
            || ((id & s_msgbt[CAN_msg.channel].idcbt[i].screeid) == (s_msgbt[CAN_msg.channel].idcbt[i].id & s_msgbt[CAN_msg.channel].idcbt[i].screeid)) )
              && (true == s_msgbt[CAN_msg.channel].idcbt[i].isused)) {
            break;
        }
    }
    if (s_msgbt[CAN_msg.channel].idcbt[i].mode == CAN_COVER_OLD) {
        rxobj = i + s_msgbt[CAN_msg.channel].idcbt[i].storeadd;
        if (id != s_msgbt[CAN_msg.channel].idcbt[rxobj].id) {
            return;
        }
    } else {
        rxobj = i;
    }
    if (rxobj >= MAX_CANIDS) {
        return;
    }
    s_msgbt[CAN_msg.channel].idcbt[rxobj].len = CAN_msg.len;                    /* �洢�������� */
    MMI_MEMCPY(s_msgbt[CAN_msg.channel].idcbt[rxobj].storebuf, 8, CAN_msg.databuf, CAN_msg.len);
    s_msgbt[CAN_msg.channel].recvcnt++;                                         /* ��ˮ������ */
    s_msgbt[CAN_msg.channel].idcbt[rxobj].type = CAN_msg.type;
    switch (s_ccbt[CAN_msg.channel].mode) {
        case CAN_MODE_LUCIDLY:                                                  /* ͸��ģʽ */
            tempbuf[0] = CAN_msg.channel + 1;
            Longtochar(&tempbuf[1], id);                                    /* ID */
            tempbuf[5] = s_msgbt[CAN_msg.channel].idcbt[rxobj].type;
            tempbuf[6] = 0;
            tempbuf[7] = 0;
            tempbuf[8] = s_msgbt[CAN_msg.channel].recvcnt;                      /* ��ˮ�� */
            tempbuf[9] = CAN_msg.len;                                           /* ���ݰ����� */
            MMI_MEMCPY(&tempbuf[10], sizeof(tempbuf) - 10, CAN_msg.databuf, CAN_msg.len);/* �������ݰ� */
            if (s_lbfunctionentry[LUCIDLY_REPORT].lbhandle != PNULL) {
                s_lbfunctionentry[LUCIDLY_REPORT].lbhandle(tempbuf, CAN_msg.len + 10);
            }
            break;
        case CAN_MODE_REPORT:                                                   /* �����ϱ� */
            if (s_msgbt[CAN_msg.channel].idcbt[i].mode == CAN_COVER_REGULAR) {
                s_msgbt[CAN_msg.channel].idcbt[rxobj].id_rec = id;
                s_msgbt[CAN_msg.channel].idcbt[rxobj].storecnt = 1;
                break;
            }
            s_msgbt[CAN_msg.channel].idcbt[i].storeadd++;
            if ((++s_msgbt[CAN_msg.channel].idcbt[i].storecnt >= s_msgbt[CAN_msg.channel].idcbt[i].stores)
              && (s_msgbt[CAN_msg.channel].idcbt[i].stores != 0xff)) {
                tempbuf[0] = CAN_msg.channel + 1;
                MMI_MEMCPY(&tempbuf[1], sizeof(tempbuf) - 1, CAN_msg.id, 4);
                if (s_msgbt[CAN_msg.channel].idcbt[i].mode == CAN_COVER_OLD) {
                    tempbuf[5] = s_msgbt[CAN_msg.channel].idcbt[i].stores;
                    len = 6;
                    for (j = 0; j < s_msgbt[CAN_msg.channel].idcbt[i].stores; j++) {
                        tempbuf[len++] = s_msgbt[CAN_msg.channel].idcbt[i + j].type;
                        tempbuf[len++] = 0;
                        tempbuf[len++] = s_msgbt[CAN_msg.channel].recvcnt;      /* ��ˮ�� */
                        tempbuf[len++] = 0;
                        tempbuf[len++] = s_msgbt[CAN_msg.channel].idcbt[i + j].len;/* �������� */
                        MMI_MEMCPY(&tempbuf[len], sizeof(tempbuf) - len,
                          s_msgbt[CAN_msg.channel].idcbt[i + j].storebuf, s_msgbt[CAN_msg.channel].idcbt[i + j].len);
                        len += s_msgbt[CAN_msg.channel].idcbt[i + j].len;
                    }
                } else {
                    tempbuf[5] = 1;
                    tempbuf[6] = s_msgbt[CAN_msg.channel].idcbt[rxobj].type;
                    tempbuf[7] = 0;
                    tempbuf[8] = s_msgbt[CAN_msg.channel].recvcnt;              /* ���һ����ˮ�� */
                    tempbuf[9] = 0;
                    tempbuf[10] = CAN_msg.len;                                  /* ���һ���ĵ������� */
                    MMI_MEMCPY(&tempbuf[11], sizeof(tempbuf) - 11, CAN_msg.databuf, CAN_msg.len);
                    len = CAN_msg.len + 11;
                }
                if (s_lbfunctionentry[LB_REPORT].lbhandle != PNULL) {
                    s_lbfunctionentry[LB_REPORT].lbhandle(tempbuf, len);
                }
                s_msgbt[CAN_msg.channel].idcbt[rxobj].storecnt = 0;
                s_msgbt[CAN_msg.channel].idcbt[rxobj].storeadd = 0;
            }
            break;
        case CAN_MODE_QUERY:                                                    /* ������ѯ */
            if (s_msgbt[CAN_msg.channel].idcbt[i].mode == CAN_COVER_OLD) {
                if (++s_msgbt[CAN_msg.channel].idcbt[i].storeadd >= s_msgbt[CAN_msg.channel].idcbt[i].stores) {
                    s_msgbt[CAN_msg.channel].idcbt[i].storeadd = 0;
                }
                if (++s_msgbt[CAN_msg.channel].idcbt[i].storecnt > s_msgbt[CAN_msg.channel].idcbt[i].stores) {
                    s_msgbt[CAN_msg.channel].idcbt[i].storecnt = s_msgbt[CAN_msg.channel].idcbt[i].stores;
                }
            } else {
                s_msgbt[CAN_msg.channel].idcbt[i].storecnt = 1;
            }
            break;
        default :
            break;
    }
    #endif
}



/*******************************************************************
** ������:     can_rx_scan
** ��������:   ɨ��CAN�������Ƿ������ݣ������ô�������
** ����:       ��
** ����:       ��
********************************************************************/
static void can_rx_scan(void)
{
    INT8U i;
    CAN_DATA_HANDLE_T CAN_msg;
    INT8U buf[sizeof(CAN_DATA_HANDLE_T)];
    //Can2515RxHdl();
    for (; UsedOfRoundBuf(&s_can_round) >= sizeof(CAN_DATA_HANDLE_T); ) {
        for (i = 0; i < sizeof(CAN_DATA_HANDLE_T); i++) {
            buf[i] = ReadRoundBuf(&s_can_round);
        }
        MMI_MEMCPY((INT8U*)&CAN_msg, sizeof(CAN_msg), buf, sizeof(CAN_DATA_HANDLE_T));
        can_msg_handler(CAN_msg);
    }
}

/*******************************************************************
** ������:     SendCANMsg_Period
** ��������:   �����Է���CAN����
** ����:       ��
** ����:       ��
********************************************************************/
void SendCANMsg_Period(void)
{
    INT8U i, j, k;
    INT8U temp[13];

    if (++pried >= 200) {
        pried = 0;
        #if DEBUG_CAN > 0
        Debug_SysPrint("<**** [can����], (�����ж�):%d, (���ͽӿ�):%d, (����ɨ�����):%d, (�����ж�):%d ****>\r\n",sendcnttest1,sendcnttest2,recvcnt1,recvcnt2);
        #endif
    }
    for (i = 0; i < MAX_CANCHAN; i++) {
        k = 0;
		DAL_ASSERT((i == 0x00) || (i == 0x01));
        for (j = 0; j < MAX_RXIDOBJ; j++) {
            if (k >= s_msg_period[i].sdobjused) {
                break;
            }
            if (s_msg_period[i].idcbt[j].isused) {
                if (++s_msg_period[i].idcbt[j].timecnt >= s_msg_period[i].idcbt[j].period) {
                    s_msg_period[i].idcbt[j].timecnt = 0;
                    Longtochar(temp, s_msg_period[i].idcbt[j].id);
                    temp[4] = s_msg_period[i].idcbt[j].len;
                    MMI_MEMCPY(&temp[5], sizeof(temp) - 5, s_msg_period[i].idcbt[j].storebuf, s_msg_period[i].idcbt[j].len);
                    
                    DAL_CAN_TxData(temp, FALSE, i);
                }
                k++;
            }
        }
    }
}

/*******************************************************************
** ������:     USER_CAN0_TX0_IRQHandler
** ��������:   CAN0�жϴ�������
** ����:       ��
** ����:       ��
********************************************************************/
__attribute__ ((section ("IRQ_HANDLE"))) static void USER_CAN0_TX0_IRQHandler(void)
{
    INT8U cdata[13],i;
    //sendcnttest1++;
	//debug_printf("can0�����ж�\r\n");
	can_interrupt_flag_clear(CAN0, CAN_INT_FLAG_MTF0);
	can_interrupt_flag_clear(CAN0, CAN_INT_FLAG_MTF1);
	can_interrupt_flag_clear(CAN0, CAN_INT_FLAG_MTF2);
    if (UsedOfRoundBuf(&s_can_send_round[0]) >= CAN_SEND_PKG_LEN) {
        for (i = 0; i < CAN_SEND_PKG_LEN; i++) {
            cdata[i] = ReadRoundBuf(&s_can_send_round[0]);
        }
        DAL_CAN_TxData_Dir(cdata, 0);
    } else {
        s_sendstat[0] = CAN_SEND_IDLENOW;
    }
	Can_TxMsg(0);
}

/*******************************************************************
** ������:     USER_CAN1_TX0_IRQHandler
** ��������:   CAN1�жϴ�������
** ����:       ��
** ����:       ��
********************************************************************/
__attribute__ ((section ("IRQ_HANDLE"))) static void USER_CAN1_TX0_IRQHandler(void)
{
    INT8U cdata[13],i;
	sendcnttest1++;
	//debug_printf("can1�����ж�\\r\n");
	//debug_printf("USER_CAN1_TX0_IRQHandler addr:%x  handle_addr:%x\r\n",s_lbfunctionentry[LB_ANALYZE].lbhandle,handle_addr);
	can_interrupt_flag_clear(CAN1, CAN_INT_FLAG_MTF0);
	can_interrupt_flag_clear(CAN1, CAN_INT_FLAG_MTF1);
	can_interrupt_flag_clear(CAN1, CAN_INT_FLAG_MTF2);
    if (UsedOfRoundBuf(&s_can_send_round[1]) >= CAN_SEND_PKG_LEN) {
        for (i = 0; i < CAN_SEND_PKG_LEN; i++) {
            cdata[i] = ReadRoundBuf(&s_can_send_round[1]);
        }
        DAL_CAN_TxData_Dir(cdata, 1);
    } else {
        s_sendstat[1] = CAN_SEND_IDLENOW;
    }
	Can_TxMsg(1);
}

/*******************************************************************
** ������:     USER_CAN0_RX0_IRQHandler
** ��������:   CAN0�жϴ�������
** ����:       ��
** ����:       ��
********************************************************************/
__attribute__ ((section ("IRQ_HANDLE"))) static void USER_CAN0_RX0_IRQHandler(void)
{
    can_receive_message_struct RxMessage;
    INT32U       id;
    CAN_DATA_HANDLE_T CAN_msg;
	//debug_printf("USER_CAN0_RX0_IRQHandler\r\n");
  #if DEBUG_CAN > 1
    Debug_SysPrint("1");
  #endif
    can_message_receive(CAN0, CAN_FIFO0, &RxMessage);                                   /* ���Ƚ���CAN���� */
	CAN_msg.channel = 0;
	
    if (RxMessage.rx_ff == CAN_FF_STANDARD) {                                                   /* ������׼֡��IDֵ */
        id = (INT32U)(RxMessage.rx_sfid);
        CAN_msg.format= 0x01;
    } else {                                                                    /* ������չ֡��IDֵ */
        id = (INT32U)(RxMessage.rx_efid);
        CAN_msg.format= 0x02;
    }
    Longtochar(CAN_msg.id, id);
    CAN_msg.len = RxMessage.rx_dlen;
    if (CAN_msg.len == 0) {
        CAN_msg.type = 1; // Զ��֡
    } else {
        CAN_msg.type = 0; // ����֡
    }
    MMI_MEMCPY(CAN_msg.databuf, 8, RxMessage.rx_data, RxMessage.rx_dlen);
    WriteBlockRoundBuf(&s_can_round, (INT8U*)&CAN_msg, sizeof(CAN_msg));
}

/*******************************************************************
** ������:     USER_CAN1_RX1_IRQHandler
** ��������:   CAN1�жϴ�������
** ����:       ��
** ����:       ��
********************************************************************/
__attribute__ ((section ("IRQ_HANDLE"))) static void USER_CAN1_RX1_IRQHandler(void)
{
    can_receive_message_struct     RxMessage;
    INT32U       id;
    CAN_DATA_HANDLE_T CAN_msg;
	recvcnt2++;
	//debug_printf("CAN1�����ж�\r\n");
  #if DEBUG_CAN > 1
    Debug_SysPrint("CAN2�����ж�\r\n");
  #endif
    can_message_receive(CAN1, CAN_FIFO1, &RxMessage);                                   /* ���Ƚ���CAN���� */
    CAN_msg.channel = 1;
    if (RxMessage.rx_ff == CAN_FF_STANDARD) {                                                   /* ������׼֡��IDֵ */
        id = (INT32U)(RxMessage.rx_sfid);
        CAN_msg.format = 0x01;
    } else {                                                                    /* ������չ֡��IDֵ */
        id = (INT32U)(RxMessage.rx_efid);
        CAN_msg.format = 0x02;
    }
    Longtochar(CAN_msg.id, id);
    CAN_msg.len = RxMessage.rx_dlen;
    if (CAN_msg.len == 0) {
        CAN_msg.type = 1; // Զ��֡
    } else {
        CAN_msg.type = 0; // ����֡
    }
    MMI_MEMCPY(CAN_msg.databuf, 8, RxMessage.rx_data, RxMessage.rx_dlen);

    WriteBlockRoundBuf(&s_can_round, (INT8U*)&CAN_msg, sizeof(CAN_msg));

#if EN_LOCK > 0

    #if EN_CAN_EXCHG > 0
    if (s_lbfunctionentry[LB_HANDSHAKE].lbhandle != NULL) {
        s_lbfunctionentry[LB_HANDSHAKE].lbhandle((INT8U*)&CAN_msg, sizeof(CAN_DATA_HANDLE_T));
    }
    #endif

#endif
}

/*******************************************************************
** ������:     Dal_CAN_Init
** ��������:   CAN�ײ��ʼ��
** ����:       ��
** ����:       ��
********************************************************************/
void Dal_CAN_Init(void)
{
    memset(s_msg_period, 0, sizeof(s_msg_period));
    InitRoundBuf(&s_can_round, s_can_buf, sizeof(s_can_buf), NULL);
	InitRoundBuf(&s_can_send_round[0], (INT8U *)&s_can_send_buf[0], sizeof(s_can_send_buf[0]), NULL);
    InitRoundBuf(&s_can_send_round[1], (INT8U *)&s_can_send_buf[1], sizeof(s_can_send_buf[1]), NULL);
    DAL_ASSERT(InstallScanner(can_rx_scan, 0));
}

/*******************************************************************
** ������:     Dal_CANLBRepReg
** ��������:   CAN�ص��ϱ�����
** ����:       [in] handle             ָ��APP��ĺ���ָ��
** ����:       ��
********************************************************************/
void Dal_CANLBRepReg(CAN_LBINDEX_E index, void (* handle) (CAN_DATA_HANDLE_T *CAN_msg))
{
    s_lbfunctionentry[index].lbhandle = handle;
}
#if 0
/*******************************************************************
** ������:     CANRegularReport
** ��������:   CAN��ʱ�ɼ�����
** ����:       ��
** ����:       ��
********************************************************************/
void CANRegularReport(void)
{
    INT8U i;
    INT8U channel;
    INT8U tempbuf[100];
    INT8U len;

    for (channel = 0; channel < MAX_CANCHAN; channel++) {
        for (i = 0; i < MAX_CANIDS; i++) {
            if (s_msgbt[channel].idcbt[i].mode == CAN_COVER_REGULAR) {
                if ((++s_msgbt[channel].idcbt[i].storeadd >= s_msgbt[channel].idcbt[i].stores) && (s_msgbt[channel].idcbt[i].storecnt)) {/* ��storeadd���ۼӼ�ʱ */
                    tempbuf[0] = channel + 1;
                    Longtochar(&tempbuf[1], s_msgbt[channel].idcbt[i].id_rec);
                    tempbuf[5] = 1;
                    tempbuf[6] = s_msgbt[channel].idcbt[i].type;
                    tempbuf[7] = 0;
                    tempbuf[8] = s_msgbt[channel].recvcnt;                      /* ���һ����ˮ�� */
                    tempbuf[9] = 0;
                    tempbuf[10] = s_msgbt[channel].idcbt[i].len;                /* ���һ���ĵ������� */
                    MMI_MEMCPY(&tempbuf[11], sizeof(tempbuf) - 11, s_msgbt[channel].idcbt[i].storebuf, s_msgbt[channel].idcbt[i].len);
                    len = s_msgbt[channel].idcbt[i].len + 11;

                    if (s_lbfunctionentry[LB_REPORT].lbhandle != PNULL) {
                        s_lbfunctionentry[LB_REPORT].lbhandle(tempbuf, len);
                    }
                    s_msgbt[channel].idcbt[i].storecnt = 0;
                    s_msgbt[channel].idcbt[i].storeadd = 0;
                }
            }
        }
    }
}
/*******************************************************************
** ������:     GetStoreNum
** ��������:   ��ȡָ��IDĿǰ���������
** ����:       [in] serial             ID���
**             [in] channel            ͨ����
** ����:       �Ѿ��յ������������
********************************************************************/
INT8U GetStoreNum(INT8U serial, INT8U channel)
{
    return (s_msgbt[channel].idcbt[serial].storecnt);
}

/*******************************************************************
** ������:     GetStoreData
** ��������:   app���ȡ�����CAN���ݣ����ڱ�����ѯģʽ
** ����:       [in] idcnts             ID���
**             [in] channel            ͨ����
**             [out] buf               �洢�������ݵ���ʼ��ַ
** ����:       �����ܳ���
********************************************************************/
INT16U GetStoreData(INT8U idcnts, INT8U *buf, INT8U channel)
{
    INT16U storeaddr;
    INT8U  len;
    INT8U  *ptr;
    INT8U  i;
    INT8U  idadd;
    INT8U  storecnt;

    ptr = buf;

    storeaddr = 0;
    Longtochar(ptr, s_msgbt[channel].idcbt[idcnts].id);              /* ID */
    storeaddr = 4;
    if (s_msgbt[channel].idcbt[idcnts].mode == CAN_COVER_OLD) {
        storecnt = s_msgbt[channel].idcbt[idcnts].storecnt;      /* ����֡�� */
        if (s_msgbt[channel].idcbt[idcnts].storecnt >= s_msgbt[channel].idcbt[idcnts].stores) {
            idadd = idcnts + s_msgbt[channel].idcbt[idcnts].storeadd;
        } else {
            idadd = idcnts;
        }
    } else {
        if (s_msgbt[channel].idcbt[idcnts].storecnt) {
            storecnt = 1;
        } else {
            storecnt = 0;
        }
        idadd = idcnts;
    }
    ptr[storeaddr++] = storecnt;
    for (i = 0; i < storecnt; i++) {
        ptr[storeaddr++] = s_msgbt[channel].idcbt[idadd].type;
        ptr[storeaddr++] = 0;
        ptr[storeaddr++] = s_msgbt[channel].recvcnt;          /* ��ˮ�� */
        ptr[storeaddr++] = 0;
        len = s_msgbt[channel].idcbt[idadd].len;                     /* ��ȡ���ݰ����� */
        ptr[storeaddr++] = len;
        MMI_MEMCPY(&ptr[storeaddr], sizeof(ptr) - storeaddr, (s_msgbt[channel].idcbt[idadd].storebuf), len);
        storeaddr += len;
        if (++idadd >= idcnts + s_msgbt[channel].idcbt[idcnts].stores) {
            idadd = idcnts;
        }
    }
    s_msgbt[channel].idcbt[idcnts].storecnt = 0;                     /* �Ѿ��յ�������֡������ */
    s_msgbt[channel].idcbt[idcnts].storeadd = 0;
    return storeaddr;                                                /* ɾ�����һ�μ��ϵĳ��� */
}

/*******************************************************************
** ������:     GetIDCnts
** ��������:   ��ȡ��ǰͨ���Ѿ����õĹ���ID����
** ����:       [in] channel            CAN ͨ��
** ����:       �����õĹ���ID����
********************************************************************/
INT8U GetIDCnts(INT8U channel)
{
    return s_msgbt[channel].rxobjused;
}

/*******************************************************************
** ������:     GetIDIsUsed
** ��������:   ��ȡID�Ƿ�ʹ��
** ����:       [in] idcnts             ���
**             [in] channel            CAN ͨ��
** ����:       true  or false
********************************************************************/
BOOLEAN GetIDIsUsed(INT8U idcnts, INT8U channel)
{
    return s_msgbt[channel].idcbt[idcnts].isused;
}

/*******************************************************************
** ������:     GetID
** ��������:   ��ȡIDֵ
** ����:       [in] idcnts             ���
**             [in] channel            CAN ͨ��
** ����:       IDֵ
********************************************************************/
INT32U GetID(INT8U idcnts, INT8U channel)
{
    return s_msgbt[channel].idcbt[idcnts].id;
}

/*******************************************************************
** ������:     GetIDPara
** ��������:   ��ȡ�˲�ID���Բ���
** ����:       [in] idcnts             ���
**             [in] channel            CAN ͨ��
** ����:       ָ��ID���Խṹ��ĵ�ַ
********************************************************************/
IDPARA_T* GetIDPara(INT8U idcnts, INT8U channel)
{
    return &s_msgbt[channel].idcbt[idcnts];
}

/*******************************************************************
** ������:     SetIDPara
** ��������:   �����˲�ID���Բ���
** ����:       [in] idcnts             ���
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
void SetIDPara(IDPARA_T *idset, INT8U idcnts, INT8U channel)
{
    if (idset->isused) {
        s_msgbt[channel].recvcnt = 0;                                           /* ��ˮ������ */
        s_msgbt[channel].idcbt[idcnts].isused = idset->isused;                  /* ʹ����� */
        s_msgbt[channel].idcbt[idcnts].storecnt = 0;                            /* �Ѿ����մ洢��֡������ */
        s_msgbt[channel].idcbt[idcnts].storeadd = 0;
        s_msgbt[channel].idcbt[idcnts].stores = idset->stores;
        s_msgbt[channel].idcbt[idcnts].id = idset->id;                          /* ID */
        s_msgbt[channel].idcbt[idcnts].screeid = idset->screeid & 0x00ffffff;   /* ǰ�����ֽڲ����� */
        s_msgbt[channel].idcbt[idcnts].mode = idset->mode;

        s_msgbt[channel].rxobjused++;
    } else {
        if (s_msgbt[channel].idcbt[idcnts].isused) {
            s_msgbt[channel].idcbt[idcnts].isused = false;
            s_msgbt[channel].recvcnt= 0;
            if (s_msgbt[channel].rxobjused) {
                s_msgbt[channel].rxobjused--;
            }
        }
    }
}
#endif

/*******************************************************************
** ������:     DAL_CAN_TxData
** ��������:   CAN�������ݽӿں���
** ����:       [in] data               ָ����������ָ��(����:ID len ����)
**             [in] wait               �Ƿ�ȴ����ͳɹ�Ӧ��
**             [in] channel            CAN ͨ��
** ����:       ���ͽ��
********************************************************************/
BOOLEAN DAL_CAN_TxData_Dir(INT8U *data, INT8U channel)
{
    INT8U        txmailbox;
    can_trasnmit_message_struct     cdata;
    INT32U       tempid;
    //INT32S       i;
    INT32U CANx;
    Chartolong(&tempid, data);                                              /* ID */
    memset(&cdata, 0, sizeof(cdata));

    #if DEBUG_CAN > 0
    //Debug_SysPrint("DAL_CAN_TxData_Dir, %d\r\n",UsedOfRoundBuf(&s_can_send_round[0]));
    #endif

    if (tempid > 0x000007FF) {            /* 
    ����֡����ָ��IDֵ����ͬ���� */
        cdata.tx_efid = tempid;
        cdata.tx_ff = _FRAME_EXT;
    } else {
        cdata.tx_sfid= tempid;
        cdata.tx_ff = _FRAME_STD;
    }

    if (_FRAME_DATA == s_ccbt[channel].fmat) {                                  /* ����֡��ʽָ��֡���ݵĳ��ȼ������� */
        cdata.tx_dlen = data[4];
        MMI_MEMCPY(cdata.tx_data, 8, &data[5], data[4]);
    } else {
        cdata.tx_dlen = 0;
        memset(cdata.tx_data, 0, sizeof(cdata.tx_data));
    }
    cdata.tx_ft = s_ccbt[channel].fmat;

    if (channel == 0) {
        CANx = CAN0;
    } else if (channel == 1) {
        CANx = CAN1;
    } else {
        return false;
    }
	

    txmailbox = can_message_transmit(CANx, &cdata);
    //txmailbox = CAN_Transmit(CANx, &cdata);
    
    if (txmailbox == CAN_NOMAILBOX) {
        #if EN_DEBUG > 0
        Debug_SysPrint("����ʧ��\r\n");
        #endif        
        return false;
    }

    
    return true;
}

/*******************************************************************
** ������:     DAL_CAN_TxData
** ��������:   CAN�������ݽӿں���
** ����:       [in] data               ָ����������ָ��(����:ID len ����)
**             [in] wait               �Ƿ�ȴ����ͳɹ�Ӧ��
**             [in] channel            CAN ͨ��
** ����:       ���ͽ��
********************************************************************/
BOOLEAN DAL_CAN_TxData(INT8U *data, BOOLEAN wait, INT8U channel)
{
    INT8U cdata[13],i;
    BOOLEAN res;
    INT32U CANx;
    
    if (channel >= MAX_CANCHAN) return false;
    if (s_ccbt[channel].onoff == false) return false;
    
    memset(cdata, 0,sizeof(cdata));
    if (channel == 0) {
        CANx = CAN0;
        sendcnttest2++;
    } else {
        CANx = CAN1;
    }
    //CAN_ITConfig(CANx, CAN_IT_TME, DISABLE);
	can_interrupt_disable(CANx,CAN_INT_TME);
    res = WriteBlockRoundBuf(&s_can_send_round[channel], data, CAN_SEND_PKG_LEN);
    if (!res) {
        #if DEBUG_CAN > 0
        Debug_SysPrint("DAL_CAN_TxData %d, %d\r\n",channel,UsedOfRoundBuf(&s_can_send_round[channel]));
        #endif
        //s_sendstat[channel] = CAN_SEND_IDLENOW;
    }
    if (s_sendstat[channel] == CAN_SEND_IDLENOW) {
        can_interrupt_enable(CANx,CAN_INT_TME);
        for (i = 0; i < CAN_SEND_PKG_LEN; i++) {
            cdata[i] = ReadRoundBuf(&s_can_send_round[channel]);
        }
        s_sendstat[channel] = CAN_SEND_BUSY;
        DAL_CAN_TxData_Dir(cdata, channel);
    } else {
        can_interrupt_enable(CANx,CAN_INT_TME);
    }
    return res;
}

/*******************************************************************
** ������:     CAN_RxFilterConfig
** ��������:   CAN�����˲�
** ����:       [in] filter_id          ��ʾ��
**             [in] screen_id          ����λ���൱�����룬Ϊ0��λ�����ģ�Ϊ1��λ����ƥ��
**             [in] onoff              �Ƿ����˲���CAN_FILTER_ON ����idset���˲�ID��CAN_FILTER_OFF �������˲���������ID
**             [in] channel            CAN ͨ��
** ����:       ���ý��
********************************************************************/
BOOLEAN CAN_RxFilterConfig(INT32U filter_id, INT32U screen_id, CAN_FILTERCTRL_E onoff, INT8U channel)
{
    can_filter_parameter_struct CAN_FilterInitStructure;
    INT8U i;
    #if DEBUG_CAN > 0
        //Debug_SysPrint("CAN_RxFilterConfig filter_id%x, screen_id%x, channel%x\r\n",filter_id,screen_id,channel);
    #endif

    if (channel > 1) return false;

    if (CAN_FILTER_ON == onoff) {                                               /* �����˲� */
        for (i = 0; i < MAX_RXIDOBJ; i++) {
            if (s_can_filter[channel].idcbt[i].isused == false) {
                break;
            }
        }
        if (i != MAX_RXIDOBJ) {
            s_can_filter[channel].idcbt[i].id = filter_id;                      /* ID */
        } else {
            if (s_can_filter[channel].idcbt[i].isused == false) {
                s_can_filter[channel].idcbt[i].id = filter_id;                  /* ID */
                s_can_filter[channel].screenid_last = screen_id;
            } else {
                s_can_filter[channel].screenid_last &= screen_id;
                s_can_filter[channel].screenid_last &= (~(s_can_filter[channel].idcbt[i].id ^ filter_id));
                screen_id = s_can_filter[channel].screenid_last;
            }
        }

        CAN_FilterInitStructure.filter_enable = ENABLE;
        if (filter_id <= 0x7ff) {
            CAN_FilterInitStructure.filter_list_high = (((INT32U)filter_id << 21) & 0xFFFF0000) >> 16;
            CAN_FilterInitStructure.filter_list_low  = (((INT32U)filter_id << 21) | CAN_FF_STANDARD| CAN_FT_DATA) & 0xFFFF;
            CAN_FilterInitStructure.filter_mask_high = (((INT32U)screen_id << 21) & 0xFFFF0000) >> 16;
            CAN_FilterInitStructure.filter_mask_low  = (((INT32U)screen_id << 21) | CAN_FF_STANDARD | CAN_FT_DATA) & 0xFFFF;
		} else {
            CAN_FilterInitStructure.filter_list_high = (((INT32U)filter_id << 3) & 0xFFFF0000) >> 16;
            CAN_FilterInitStructure.filter_list_low  = (((INT32U)filter_id << 3) | CAN_FF_EXTENDED| CAN_FT_DATA) & 0xFFFF;
            CAN_FilterInitStructure.filter_mask_high = (((INT32U)screen_id << 3) & 0xFFFF0000) >> 16;
            CAN_FilterInitStructure.filter_mask_low  = (((INT32U)screen_id << 3) | CAN_FF_EXTENDED | CAN_FT_DATA) & 0xFFFF;
		}
    } else if (CAN_FILTER_OFF == onoff) {                                       /* ���˲� */
        CAN_FilterInitStructure.filter_enable = ENABLE;
        CAN_FilterInitStructure.filter_mask_high = 0x0;
        CAN_FilterInitStructure.filter_mask_low  = 0x0;
        i = MAX_RXIDOBJ;
    } else {
        return false;
    }

    s_ccbt[channel].filteronoff = onoff;
    CAN_FilterInitStructure.filter_number			= i + 14 * channel;
    CAN_FilterInitStructure.filter_mode				= CAN_FILTERMODE_MASK;
    CAN_FilterInitStructure.filter_bits				= CAN_FILTERBITS_32BIT;
    if (channel != 1) {
        CAN_FilterInitStructure.filter_fifo_number= CAN_FIFO0;
    } else {
    	
        CAN_FilterInitStructure.filter_fifo_number = CAN_FIFO1;
    }
    can_filter_init(&CAN_FilterInitStructure);
    s_can_filter[channel].idcbt[i].isused = true;
    #if DEBUG_CAN > 0
        //Debug_SysPrint("CAN_RxFilterConfig ok\r\n");
    #endif
    return true;
}

/*******************************************************************
** ������:     CAN_GPIO_Configuration
** ��������:   CAN�ܽ�����
** ����:       [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
static void CAN_GPIO_Configuration(INT8U channel)
{
    

    if (channel == 0) {
        
		rcu_periph_clock_enable(RCU_AF);/*?����GPIOϵͳʱ��?*/
		rcu_periph_clock_enable(RCU_GPIOD);/*?����GPIOϵͳʱ��?*/
		rcu_periph_clock_enable(RCU_CAN0);
		
        
		gpio_init(CAN1_PIN_IO,GPIO_MODE_IPU,GPIO_OSPEED_50MHZ,CAN1_PIN_RX);/*?���ý��չܽ�?*/
		gpio_init(CAN1_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,CAN1_PIN_TX);/*?���÷��͹ܽ�?*/
		gpio_pin_remap_config(GPIO_CAN0_FULL_REMAP,ENABLE);
    } else if (channel == 1) {
      #if MAX_CANCHAN >= 2
        
	  
	  rcu_periph_clock_enable(RCU_AF);/*����GPIOϵͳʱ��*/
	  rcu_periph_clock_enable(RCU_GPIOB);/*����GPIOϵͳʱ��*/
	  rcu_periph_clock_enable(RCU_CAN1);
	  
	  
	  gpio_init(CAN2_PIN_IO,GPIO_MODE_IPU,GPIO_OSPEED_50MHZ,CAN2_PIN_RX);/*?���ý��չܽ�?*/
	  gpio_init(CAN2_PIN_IO,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,CAN2_PIN_TX);/*?���÷��͹ܽ�?*/
      gpio_pin_remap_config(GPIO_CAN1_REMAP,ENABLE);  
      #endif
    }
}

/*******************************************************************
** ������:     CAN_WorkModeSet
** ��������:   CAN����ģʽ����: ��ȫ͸��\�����ϱ�\������ѯ
** ����:       [in] para               ����
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
void CAN_WorkModeSet(CAN_ATTR_T *para, INT8U channel)
{
    //s_ccbt[channel].mode = para->mode; 
}

/*******************************************************************
** ������:     CAN_WorkModeInit
** ��������:   CAN����ģʽ��ʼ��
** ����:       [in] testmode           ����ģʽ
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
static void CAN_WorkModeInit(INT8U sjw, INT8U bs1, INT8U bs2, INT16U prescal,CAN_TEST_MODE_E testmode, INT8U channel)
{
    can_parameter_struct CAN_InitStructure;

	can_struct_para_init(CAN_INIT_STRUCT,&CAN_InitStructure);
    CAN_InitStructure.time_triggered		= DISABLE;
    CAN_InitStructure.auto_bus_off_recovery	= ENABLE;
    CAN_InitStructure.auto_wake_up			= DISABLE;
    CAN_InitStructure.no_auto_retrans		= DISABLE;
    CAN_InitStructure.rec_fifo_overwrite	= DISABLE;
    CAN_InitStructure.trans_fifo_order		= ENABLE;                                   /* �������ȼ���Ϊ�ɷ���˳����� */
    CAN_InitStructure.working_mode			= testmode;
    CAN_InitStructure.resync_jump_width		= sjw;
    CAN_InitStructure.time_segment_1		= bs1;
    CAN_InitStructure.time_segment_2		= bs2;
    CAN_InitStructure.prescaler				= prescal;
	
    if (channel == 0) {
        can_init(CAN0,&CAN_InitStructure);
    } else if (channel == 1) {
        can_init(CAN1,&CAN_InitStructure);
    }
}

/*******************************************************************
** ������:     CAN_CommParaSet
** ��������:   CANͨ�Ų������ã�roundbuf\����\����֡��ʽ\����
** ����:       [in] para               ����
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
void CAN_CommParaSet(CAN_ATTR_T *para, INT8U channel)
{
    if ((channel == 1) && (MAX_CANCHAN < 2)) {
        return;
    }
    #if DEBUG_CAN > 0
        Debug_SysPrint("CAN_CommParaSet %d\r\n",channel);
    #endif
    CAN_GPIO_Configuration(channel);

    if (channel == 0) {
        NVIC_IrqHandleInstall(CAN0_RX0_IRQ, (ExecFuncPtr)USER_CAN0_RX0_IRQHandler, CAN_PRIOTITY, true);
        NVIC_IrqHandleInstall(CAN0_TX_IRQ, (ExecFuncPtr)USER_CAN0_TX0_IRQHandler, CAN_PRIOTITY, true);
    } else if (channel == 1) {
        NVIC_IrqHandleInstall(CAN1_RX1_IRQ, (ExecFuncPtr)USER_CAN1_RX1_IRQHandler, CAN_PRIOTITY, true);
        NVIC_IrqHandleInstall(CAN1_TX_IRQ, (ExecFuncPtr)USER_CAN1_TX0_IRQHandler, CAN_PRIOTITY, true);
    } else {
        return;
    }

    s_ccbt[channel].baud      = para->baud;
    s_ccbt[channel].type      = para->type;
    s_ccbt[channel].fmat      = para->fmat;
    s_ccbt[channel].test_mode = para->test_mode;

    //s_msgbt[channel].rxobjused = 0;
    switch (s_ccbt[channel].baud)
    {
        case CAN_10:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_10K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_20:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_20K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_50:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_50K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_100:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_100K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_125:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_125K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_250:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_250K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_500:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_500K, CAN_BS2_500K, CAN_PRES_500K, s_ccbt[channel].test_mode, channel);
            break;

        case CAN_1000:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_1000K, CAN_BS2_1000K, CAN_PRES_1000K, s_ccbt[channel].test_mode, channel);
            break;

        default:
            CAN_WorkModeInit(CANSWJ, CAN_BS1_250K, CAN_BS2_250K, CAN_PRES_250K, s_ccbt[channel].test_mode, channel);
            break;
    }
}

/*******************************************************************
** ������:     CAN_OnOFFCtrl
** ��������:   CANͨѶ���ܿ����ģ��
** ����:       [in] onoff              ����
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
void CAN_OnOFFCtrl (BOOLEAN onoff, INT8U channel)
{
    s_ccbt[channel].onoff = onoff;
    s_sendstat[channel] = CAN_SEND_IDLENOW;
    if (onoff) {
        if (channel == 0) {
            can_fifo_release(CAN0, CAN_FIFO0);
			can_interrupt_enable(CAN0,CAN_INT_RFNE0);
			can_interrupt_enable(CAN0,CAN_INT_TME);
        } else if (channel == 1) {
            can_fifo_release(CAN1, CAN_FIFO1);
			can_interrupt_enable(CAN1,CAN_INT_RFNE1);
			can_interrupt_enable(CAN1,CAN_INT_TME);
        }
    } else {
        if (channel == 0) {
            can_fifo_release(CAN0, CAN_FIFO0);
            can_interrupt_disable(CAN0,CAN_INT_RFNE0);
			can_interrupt_disable(CAN0,CAN_INT_TME);
        } else if (channel == 1) {
            can_fifo_release(CAN1, CAN_FIFO1);
			can_interrupt_disable(CAN1,CAN_INT_RFNE1);
			can_interrupt_disable(CAN1,CAN_INT_TME);
        }
    }
}

/*******************************************************************
** ������:     CAN_ClearFilterPara
** ��������:   ���ָ����CAN�˲�ID
** ����:       [in] idnums             ��ţ�0 ~ 13
**             [in] channel            CAN ͨ��
** ����:       ���ý��
********************************************************************/
BOOLEAN CAN_ClearFilterPara(INT8U idnums, INT8U channel)
{
    can_filter_parameter_struct CAN_FilterInitStructure;

    /* ��������˶��󣬻���Ҫ��֤2012-2-2 by clt*/
    CAN_FilterInitStructure.filter_enable		= DISABLE;
    CAN_FilterInitStructure.filter_mask_high	= 0xFFFF;
    CAN_FilterInitStructure.filter_mask_low		= 0xFFFF;

    if (s_ccbt[channel].type == _FRAME_STD) {
        CAN_FilterInitStructure.filter_list_high = 0;
        CAN_FilterInitStructure.filter_list_low  = 0;
    } else if (s_ccbt[channel].type == _FRAME_EXT) {
        CAN_FilterInitStructure.filter_list_high = 0;
        CAN_FilterInitStructure.filter_list_low  = 0;
    } else {
        return false;
    }

    CAN_FilterInitStructure.filter_number = idnums + 14 * channel;
    CAN_FilterInitStructure.filter_mode= CAN_FILTERMODE_MASK;
    CAN_FilterInitStructure.filter_bits= CAN_FILTERBITS_32BIT;
    if (channel == 0) {
        CAN_FilterInitStructure.filter_fifo_number= CAN_FIFO0;
    } else {
        CAN_FilterInitStructure.filter_fifo_number = CAN_FIFO1;
    }

    can_filter_init(&CAN_FilterInitStructure);

    s_can_filter[channel].idcbt[idnums].isused = false;
    s_can_filter[channel].idcbt[idnums].id     = 0;

    if (idnums == MAX_RXIDOBJ) {
        s_can_filter[channel].screenid_last = 0xFFFFFFFF;
    }
    return true;
}

/*******************************************************************
** ������:     CAN_ClearFilterByID
** ��������:   ���ָ����CAN�˲�ID
** ����:       [in] id                 ��Ҫ���ID
**             [in] channel            CAN ͨ��
** ����:       ��
********************************************************************/
BOOLEAN CAN_ClearFilterByID(INT32U id, INT8U channel)
{
    INT8U i;
    can_filter_parameter_struct CAN_FilterInitStructure;

    for (i = 0; i < MAX_RXIDOBJ; i++) {
        if ((s_can_filter[channel].idcbt[i].isused) && (s_can_filter[channel].idcbt[i].id == id)) {
            break;
        }
    }
    if (i >= MAX_RXIDOBJ) {
        return false;
    }

    /* ��������˶��󣬻���Ҫ��֤2012-2-2 by clt*/
    CAN_FilterInitStructure.filter_enable	= DISABLE;
    CAN_FilterInitStructure.filter_mask_high= 0xFFFF;
    CAN_FilterInitStructure.filter_mask_low = 0xFFFF;

    if (s_ccbt[channel].type == _FRAME_STD) {
        CAN_FilterInitStructure.filter_list_high= 0;
        CAN_FilterInitStructure.filter_list_low = 0;
    } else if (s_ccbt[channel].type == _FRAME_EXT) {
        CAN_FilterInitStructure.filter_list_high = 0;
        CAN_FilterInitStructure.filter_list_low  = 0;
    } else {
        return false;
    }
	
	CAN_FilterInitStructure.filter_number= i + 14 * channel;
    CAN_FilterInitStructure.filter_mode  = CAN_FILTERMODE_MASK;
    CAN_FilterInitStructure.filter_bits	 = CAN_FILTERBITS_32BIT;
    if (channel == 0) {
        CAN_FilterInitStructure.filter_fifo_number= CAN_FIFO0;
    } else {
        CAN_FilterInitStructure.filter_fifo_number = CAN_FIFO1;
    }

    can_filter_init(&CAN_FilterInitStructure);

    s_can_filter[channel].idcbt[i].isused = false;
    s_can_filter[channel].idcbt[i].id     = 0;

    return true;
}

/*******************************************************************
** ������:     Dal_SetCANMsg_Period
** ��������:   ���������Է���CAN����
** ����:       [in] id                 ����ID
**             [in] ptr                ���ͳ��Ⱥ�����
**             [in] period             �������ڣ���λ10ms
**             [in] channel            CAN ͨ��
** ����:       ���ý��
********************************************************************/
BOOLEAN Dal_SetCANMsg_Period(INT32U id, INT8U *ptr, INT16U period, INT8U channel)
{
    INT8U i;
	if(MAX_CANCHAN < channel)return FALSE;
  #if DEBUG_CAN > 0
    //Debug_SysPrint("id = %x, len = %d\r\n", id, ptr[0]);
  #endif
    for (i = 0; i < MAX_RXIDOBJ; i++) {
        if ((s_msg_period[channel].idcbt[i].isused) && (s_msg_period[channel].idcbt[i].id == id)) {
            s_msg_period[channel].idcbt[i].period = period;
            s_msg_period[channel].idcbt[i].len = ptr[0];
            MMI_MEMCPY(s_msg_period[channel].idcbt[i].storebuf, 8, &ptr[1], s_msg_period[channel].idcbt[i].len);
            return true;
        }
    }

    if (s_msg_period[channel].sdobjused >= MAX_RXIDOBJ) {
        return false;
    }
    for (i = 0; i < MAX_RXIDOBJ; i++) {
        if (!s_msg_period[channel].idcbt[i].isused) {
            s_msg_period[channel].idcbt[i].isused = true;
            s_msg_period[channel].idcbt[i].id = id;
            s_msg_period[channel].idcbt[i].period = period;
            s_msg_period[channel].idcbt[i].timecnt = i;                         /* Ϊ���ö���������ڲ��� */
            s_msg_period[channel].idcbt[i].len = ptr[0];
            MMI_MEMCPY(s_msg_period[channel].idcbt[i].storebuf, 8, &ptr[1], s_msg_period[channel].idcbt[i].len);
            s_msg_period[channel].sdobjused++;
            return true;
        }
    }
    return false;
}

/*******************************************************************
** ������:     Dal_StopCANMsg_Period
** ��������:   ֹͣ���ڷ���
** ����:       [in] id                 ����ID
**             [in] channel            CAN ͨ��
** ����:       ���ý��
********************************************************************/
BOOLEAN Dal_StopCANMsg_Period(INT32U id, INT8U channel)
{
    INT8U i;

    for (i = 0; i < MAX_RXIDOBJ; i++) {
        if ((s_msg_period[channel].idcbt[i].isused) && (s_msg_period[channel].idcbt[i].id == id)) {
            s_msg_period[channel].idcbt[i].isused = false;
            s_msg_period[channel].sdobjused--;
            return true;
        }
    }
    return false;
}
#if 0
/*******************************************************************
** ������:     ChickCanID
** ��������:   ȷ��ID�Ƿ���Ч
** ����:       [in] id                 �����CAN ID
**             [in] channel            CAN ͨ��
** ����:       Ϊ0ʱ��ʾδ�ҵ�
********************************************************************/
INT32U  ChickCanID(INT32U id,INT8U chanl)
{
    INT8U i;
    INT32U retid = 0;

    if (s_ccbt[chanl].filteronoff == CAN_FILTER_OFF) {
        return id;
    }
    for (i = 0; i < MAX_CANIDS; i++) {
        if ((true == s_msgbt[chanl].idcbt[i].isused) && ((id == s_msgbt[chanl].idcbt[i].id)
          || ((id & s_msgbt[chanl].idcbt[i].screeid) == (s_msgbt[chanl].idcbt[i].id & s_msgbt[chanl].idcbt[i].screeid))) ) {
            retid = id;
            break;
        }
    }
    return retid;
}
#endif
/**************************************************************************************************
**  ��������:  CheckCanIsErrer
**  ��������:  �鿴CAN�����Ƿ����
**  �������:
**  ���ز���:
**************************************************************************************************/
BOOLEAN CheckCanIsErrer(INT8U channel)
{
    INT32U CANx;
    FlagStatus esr;

    DAL_ASSERT((channel == 0x00) || (channel == 0x01));
    if (channel == 0x00) {
        CANx = CAN0;
    } else {
        CANx = CAN1;
    }

    #if DEBUG_CAN > 0
        //Debug_SysPrint("CAN�����ʶ:%d\r\n", CANx->ESR & CAN_ESR_LEC);
    #endif
    esr = can_flag_get(CANx,CAN_FLAG_ERRIF);
    if (esr) {
        return TRUE;
    } else {
        return FALSE;
    }
}

/*********************** (C) COPYRIGHT 2012 XIAMEN YAXON.LTD *******************END OF FILE******/

