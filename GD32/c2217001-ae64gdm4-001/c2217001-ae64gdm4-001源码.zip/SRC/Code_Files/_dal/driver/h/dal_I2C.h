/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  dal_i2c.h                                                                         **
**  ��Ȩ����:  CopyRight @ Xiamen Yaxon NetWork CO.LTD. 2012                                     **
**  ������Ϣ:  2012-9-14 By lyj: �������ļ�                                                      **
**  �ļ�����:  ģ��I2C�ӿ�                                                                       **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/
#ifndef __DAL_I2C_H
#define __DAL_I2C_H


void dal_iic_init(void);
BOOLEAN dal_iic_writedata(INT8U devaddr, INT8U mode, INT8U devaddrextend, INT8U writeaddr, INT8U *data, INT8U num);
INT16S dal_iic_readdata(INT8U devaddr, INT8U mode, INT8U devaddrextend, INT8U readaddr, INT8U *data, INT16U readnum);

#endif
/**************************** (C) COPYRIGHT 2012  XIAMEN YAXON.LTD **************END OF FILE******/

