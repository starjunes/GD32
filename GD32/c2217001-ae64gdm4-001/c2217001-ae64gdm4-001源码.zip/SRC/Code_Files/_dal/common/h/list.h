/********************************************************************************
**
** �ļ���:     list.h
** ��Ȩ����:   (c) 2014-2020 ������Ѹ����ɷ����޹�˾
** �ļ�����:   �����ṹ
**
*********************************************************************************
**             �޸���ʷ��¼
**===============================================================================
**| ����       | ����   |  �޸ļ�¼
**===============================================================================
**| 2014/08/21 | ����   |  �������ļ�
**
*********************************************************************************/
#ifndef H_MMI_LIST_H
#define H_MMI_LIST_H

#ifdef __cplusplus
extern "C"
{
#endif

#define LISTMEM     INT8U
#define LISTNODE    struct node

/*************************************************************************************************/
/*                           �ڵ�ṹ��                                                          */
/*************************************************************************************************/
typedef struct node{
    LISTNODE  *prv;
    LISTNODE  *next;
} NODE;

/*************************************************************************************************/
/*                           �����ṹ��                                                          */
/*************************************************************************************************/
typedef struct {
    LISTNODE  *head;
    LISTNODE  *tail;
    INT32U     item;
} LIST_T;

BOOLEAN  CheckList(LIST_T *pl);
BOOLEAN  InitList(LIST_T *pl);
INT32U   GetListItem(LIST_T *pl);
LISTMEM *GetListHead(LIST_T *pl);
LISTMEM *GetListTail(LIST_T *pl);
LISTMEM *ListNextEle(LISTMEM *pb);
LISTMEM *ListPrvEle(LISTMEM *pb);
LISTMEM *DelListEle(LIST_T *pl, LISTMEM *pb);
LISTMEM *DelListHead(LIST_T *pl);
LISTMEM *DelListTail(LIST_T *pl);
BOOLEAN  AppendListEle(LIST_T *pl, LISTMEM *pb);
BOOLEAN  InsertListHead(LIST_T *pl, LISTMEM *pb);
BOOLEAN  ConnectHeadTail(LIST_T *pl);
BOOLEAN  BInsertListEle(LIST_T *pl, LISTMEM *curpb, LISTMEM *inspb);
BOOLEAN  InitMemList(LIST_T *mempl, LISTMEM *addr, INT32U nblks, INT32U blksize);

#ifdef __cplusplus
}
#endif

#endif

