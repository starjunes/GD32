/********************************************************************************
**
** �ļ���:     roundbuf.h
** ��Ȩ����:   (c) 2014-2020 ������Ѹ����ɷ����޹�˾
** �ļ�����:   ���λ���������ģ��
**
*********************************************************************************
**             �޸���ʷ��¼
**===============================================================================
**| ����       | ����   |  �޸ļ�¼
**===============================================================================
**| 2014/08/21 | ����   |  �������ļ�
**
*********************************************************************************/
#ifndef H_MMI_ROUNDBUF_H
#define H_MMI_ROUNDBUF_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "dal_structs.h"

/*************************************************************************************************/
/*                           ���λ��������ƿ�                                                    */
/*************************************************************************************************/
typedef struct {
    INT32U         bufsize;            /* round buffer size */
    INT32U         used;               /* used bytes */
    INT8U          *bptr;              /* begin position */
    INT8U          *eptr;              /* end position */
    INT8U          *wptr;              /* write position */
    INT8U          *rptr;              /* read position */
    ASMRULE_T      *rule;              /* assemble rules */
} ROUNDBUF_T;

void    InitRoundBuf(ROUNDBUF_T *round, INT8U *mem, INT32U memsize, ASMRULE_T *rule);
void    ResetRoundBuf(ROUNDBUF_T *round);
INT8U  *RoundBufStartPos(ROUNDBUF_T *round);
BOOLEAN WriteRoundBuf(ROUNDBUF_T *round, INT8U data);
INT32S  ReadRoundBuf(ROUNDBUF_T *round);
INT32S  ReadRoundBufNoMVPtr(ROUNDBUF_T *round);
INT32U  LeftOfRoundBuf(ROUNDBUF_T *round);
INT32U  UsedOfRoundBuf(ROUNDBUF_T *round);
BOOLEAN WriteBlockRoundBuf(ROUNDBUF_T *round, INT8U *bptr, INT32U blksize);

#ifdef __cplusplus
}
#endif

#endif

