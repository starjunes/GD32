/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  Scanner.h                                                                         **
**  ��Ȩ����:  CopyRight �� Xiamen Yaxon NetWork CO.LTD. 2010                                    **
**  ������Ϣ:  Lantu.Cai -- 2010��12��6��                                                        **
**  �ļ�����:  ɨ��ģ��ӿں���                                                                  **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/
#ifndef __SCANNER_H
#define __SCANNER_H
#include  "dal_include.h"

typedef void (*SCANENTRY)(void);

void InitScanner(void);
BOOLEAN  InstallScanner(SCANENTRY entry,INT32U cycles);
void ScannerRunning(void);

#endif /*__SCANNER_H*/

/************************ (C) COPYRIGHT 2010 XIAMEN YAXON.LTD ******************END OF FILE******/


