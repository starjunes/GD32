/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  Stream.H                                                                          **
**  ��Ȩ����:  CopyRight �� Xiamen Yaxon NetWork CO.LTD. 2010                                    **
**  ������Ϣ:  LEON -- 2010��12��1��                                                             **
**  �ļ�����:  ����������ģ��                                                                    **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/
#ifndef __STREAM_H
#define __STREAM_H

#include "dal_include.h"

/*************************************************************************************************/
/*                           ���������ƿ�                                                        */
/*************************************************************************************************/
typedef struct {
    INT32U       MaxLen;               /* �������������ڴ��ֽ��� */
    INT8U       *StartPtr;             /* �������������ڴ��ַ */
    INT32U       Len;                  /* �Ѷ�/д�ֽ��� */
    INT8U       *CurPtr;               /* ��/дָ�� */
} STREAM_T;

BOOLEAN Strm_Init(STREAM_T *Sp, void *Bp, INT32U MaxLen);
INT32U  Strm_GetLeaveLen(STREAM_T *Sp);
INT32U  Strm_GetLen(STREAM_T *Sp);
void   *Strm_GetCurPtr(STREAM_T *Sp);
void   *Strm_GetStartPtr(STREAM_T *Sp);
BOOLEAN Strm_MovPtr(STREAM_T *Sp, INT32U Len);
BOOLEAN Strm_WriteHEX(STREAM_T *Sp, INT8U writebyte);
BOOLEAN Strm_WriteBYTE(STREAM_T *Sp, INT8U writebyte);
BOOLEAN Strm_WriteWORD(STREAM_T *Sp, INT16U writeword);
BOOLEAN Strm_WriteLONG(STREAM_T *Sp, INT32U writelong);
BOOLEAN Strm_WriteLF(STREAM_T *Sp);
BOOLEAN Strm_WriteSTR(STREAM_T *Sp, char *Ptr);
BOOLEAN Strm_WriteDATA(STREAM_T *Sp, INT8U *Ptr, INT16U Len);
INT8U   Strm_ReadBYTE(STREAM_T *Sp);
INT16U  Strm_ReadWORD(STREAM_T *Sp);
void    Strm_ReadDATA(STREAM_T *Sp, INT8U *Ptr, INT16U Len);

#endif

