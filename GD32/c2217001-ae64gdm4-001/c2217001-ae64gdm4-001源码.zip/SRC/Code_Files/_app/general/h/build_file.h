#ifndef _BUILD_FILE_H_
#define _BUILD_FILE_H_

/* Build Date:2020-12-21 */
#define BUILD_DATE "2020-12-21"
/* Build Time:16:55:48 */
#define BUILD_TIME "16:55:48"

//#define APPDAL_VERSION_STR "c002d008-ae64s32k-001"

#endif
