/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  s_flash.h                                                                         **
**  ��Ȩ����:  CopyRight �� Xiamen Yaxon NetWork CO.LTD. 2010                                    **
**  ������Ϣ:  jump -- 2011��1��14��                                                             **
**  �ļ�����:  ����FLASH����ģ��                                                                 **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/




#ifndef _S_FLASH_H
#define _S_FLASH_H 1


#if 0
#if SWITCH_FLASH == AT45DB161
#define s_switch_flash.flashpage           528//264
#define BLOCKSIZE           8              /* 1 BLOCK = 8 PAGE */
#define BLOCK_NSIZE         4224//2112     /* 1 BLOCK = FLASHPAGE*BLOCKSIZE */
#define FLASHBLOCK          512//256
#define PAGENUM             4096//2048     /* BLOCKSIZE*FLASHBLOCK */
#define SIZEOFFLASH         0x210000L      /* 528*4096 */
#elif SWITCH_FLASH == MX25L1606E
#define FLASHPAGE           256                                                /* ҳ��С*/
#define BLOCKSIZE           16        /* 1 BLOCK = 16 PAGE */
#define BLOCK_NSIZE         4096     /* 1 BLOCK = FLASHPAGE*BLOCKSIZE */
#define FLASHBLOCK          512
#define PAGENUM             8192     /* BLOCKSIZE*FLASHBLOCK */
#define SIZEOFFLASH         0x200000L /* 264*2048,512+16 KB */
#else
#define FLASHPAGE           264
#define BLOCKSIZE           8        /* 1 BLOCK = 8 PAGE */
#define BLOCK_NSIZE         2112     /* 1 BLOCK = FLASHPAGE*BLOCKSIZE */
#define FLASHBLOCK          256
#define PAGENUM             2048     /* BLOCKSIZE*FLASHBLOCK */
#define SIZEOFFLASH         0x84000L /* 264*2048,512+16 KB */
#endif
#endif
/*************************************************************************************************/
/*                             FLASHоƬ����                                                      */
/*************************************************************************************************/
typedef enum {
    E_AT45DB041      = 0x00,                                
    E_AT45DB161      = 0x01,                                
    E_MX25L1606E     = 0x02,                               
} SWITCH_FLASH_E;

/*************************************************************************************************/
/*                             FLASHоƬ����                                                      */
/*************************************************************************************************/
typedef struct {
    SWITCH_FLASH_E     switch_flish;
    INT8U              blocksize;
    INT16U             flashpage;
    INT16U             block_nsize;
    INT16U             flashblock;
    INT16U             pagenum;
    INT16U             size_imagesector;
    INT32U             sizeofflash;
}SWITCH_FLASH_T;
extern SWITCH_FLASH_T s_switch_flash;
void InitFlash(void); 

void BlockErase(INT16U block);
void PageWrite(INT8U* pInData, INT16U length, INT16U startpage, INT16U startbyte);
void PageRead(INT8U* InData, INT16U length, INT16U startpage, INT16U startbyte);
void AbsWrite(INT8U* pInData, INT16U length, INT32U absaddr);
void AbsWrite_Byte(INT32U absaddr, INT8U byte);
void AbsRead(INT8U* InData, INT16U length, INT32U absaddr);
/********************************************************************************
** ������:   SFlashMode
** ��������: ����ģʽ����
** ����:     [in] mode�� ģʽ:0xB9Ϊ�͹��ģ�0xAB:�ӵ͹���ģʽ�˳���0xA3:������ģʽ
** ����:     ���óɹ�����TRUE������ʧ�ܷ���FALSE.
********************************************************************************/
void SFlashMode(INT8U mode);

#endif


