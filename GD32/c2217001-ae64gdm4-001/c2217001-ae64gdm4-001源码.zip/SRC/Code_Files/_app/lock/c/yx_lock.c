/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  YX_LOCK.c                                                                         **
**  ��Ȩ����:  CopyRight �� Xiamen Yaxon NetWork CO.LTD. 2011                                    **
**  ������Ϣ:  �ڴ��� -- 2017��7��31��                                                       **
**  �ļ�����:  ��������                                                                         **
**  ===========================================================================================  **
**  �޸���Ϣ:  2011-10-25 By clt: �������ƿ��عܽž�Ĭ�Ϲر�                                     **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/
#include "yx_lock.h"
#include "yx_includes.h"
#include "yx_can_man.h"
#include "yx_com_send.h"
#include "yx_com_recv.h"
#include "yx_protocal_hdl.h"
#include "yx_debugcfg.h"
#include "port_gpio.h"
#include "bal_pp_drv.h"
#include "port_timer.h"
#include "port_adc.h"

#include "yx_md5.H"
#include "yx_lc_md5.h"
#include "yx_signal_man.h"
#include "appmain.h"
#include "bal_input_reg.h"
#include "bal_input_drv.h"

#if 0
#ifdef DEBUG_LOCK
#undef DEBUG_LOCK
#endif

#define DEBUG_LOCK 1
#endif
#define               LOCK_CAN_CH       1//CAN_CHN_2
/* �������� */
static SCLOCKPARA_T s_sclockpara;
/* ������־ */
static LOCK_RECORD     s_lockrecord;
/* ������������ */
static SCLOCKPARABAK_T s_sclockparabak;

static INT8U           s_lockstatid[12];
static INT8U           s_seed[4];
static INT32U const    s_filtid[4] = {0x0cfffd00, 0x18fd0100, 0x18ff0800, 0x18fff400};
static SC_LOCK_STEP_E  s_sclockstep = CONFIG_OVER;
static INT8U           s_key[8];


static BOOLEAN         s_idfiltenable;
static BOOLEAN         s_handskenable;
static INT16U          s_idfiltcnt;
static BOOLEAN         s_parasendstat;
static INT8U           s_parasendcnt;
//static BOOLEAN         s_ecuonoffstat;
static INT8U           s_md5source[8];
static INT8U           s_md5result[16];
static INT8U           s_lock_tmr;
static INT16U          s_reqcnt;
static INT16U          s_poweron_times_cnt = 0;                             /* �ϵ�2�����ڶ�ȡ�ͺı��� */
static BOOLEAN         s_oilsumreq = FALSE;                                  /* FALSE:��ʾ�������ͺ�����TRUE����ʾ�����ͺ����� */
static INT8U           s_ycseed[4];
static BOOLEAN         f_handsk = FALSE;
static BOOLEAN         f_handskcnt = 0;

#if EN_KMS_LOCK > 0
#define KMS_CMD_NONE      0x00
#define KMS_CMD_ACTIVE    0x01
#define KMS_CMD_LOCK      0x02
#define KMS_CMD_UNLOCK    0x03
#define KMS_CMD_CLOSE     0x04

static KMS_LOCK_OBJ_T s_kms_obj = {KMS_CMD_NONE, {0xff, 0xff}};

/**************************************************************************************************
**  ��������:  KmsG5LockMsgSend
**  ��������:  ��������˹��5����ָ���
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
static void KmsG5LockMsgSend(void)
{
    static INT8U send_period_cnt = 0;
    INT8U senddata[13] = {0x18, 0xff, 0xf9, 0x4b, 0x08, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}; /* 0x18fff94b */ 

    #if DEBUG_LOCK > 1
    static INT8U printf_cnt = 0;
    if (++printf_cnt >= 100) {
        printf_cnt = 0;
        debug_printf("<KmsG5LockMsgSend,cmd:0x%x, speed[0]:0x%x,speed[1]:0x%x>\r\n",s_kms_obj.kms_cmd, s_kms_obj.rota_speed[0], s_kms_obj.rota_speed[1]);
    }
    #endif

    if ((s_kms_obj.kms_cmd >= KMS_CMD_ACTIVE) && (s_kms_obj.kms_cmd <= KMS_CMD_CLOSE)) {
        /* 50ms */
        if (++send_period_cnt >= 5) {
            send_period_cnt = 0;
            if (s_kms_obj.kms_cmd == KMS_CMD_ACTIVE) {
                senddata[5] = 0x00;
            } else if (s_kms_obj.kms_cmd == KMS_CMD_LOCK) {
                senddata[5] = 0x01;
                /* ת�� */
                senddata[6] = s_kms_obj.rota_speed[0];
                senddata[7] = s_kms_obj.rota_speed[1];
            } else if (s_kms_obj.kms_cmd == KMS_CMD_UNLOCK) {
                senddata[5] = 0x00;
            } else {
                return;
            }
            
            CAN_TxData(senddata, false, LOCK_CAN_CH);
        }
    } else {
        send_period_cnt = 0;
    }
}
#endif

/**************************************************************************************************
**  ��������:  GetFiltenableStat
**  ��������:  ��ȡCAN����������ֹ״̬
**  �������:  None
**  ���ز���:  ����״ֵ̬ TRUE or FALSE
**************************************************************************************************/
BOOLEAN GetFiltenableStat(void)
{
    return s_idfiltenable;
}

/**************************************************************************************************
**  ��������:  WC_HandShake
**  ��������:  Ϋ������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void WC_HandShake(void)
{
    INT8U senddata[13] = {0x18,0xff,0xc2,0x1c,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
    INT32U id;

    if (s_sclockpara.ecutype != ECU_WEICHAI) return;
    id = bal_chartolong(senddata);
    senddata[5] = s_md5result[0];
    senddata[6] = s_md5result[1];
    senddata[7] = s_md5result[2];
    senddata[8] = s_md5result[3];
    senddata[9] = s_md5result[4];
    senddata[10] = s_md5result[5];
    senddata[11] = s_md5result[6];
    senddata[12] = s_md5result[7];

    CAN_TxData(senddata, false, LOCK_CAN_CH);
    SetCANMsg_Period(id, &senddata[4], 100, LOCK_CAN_CH);
    s_sclockstep = CONFIG_CONFIRM_REC;
}

/**************************************************************************************************
**  ��������:  YC_HandShake
**  ��������:  �������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void YC_HandShake(void)
{
    INT8U senddata[13] = {0x18,0xea,0x00,0x21,0x08,0x01,0xfd,0x00,0x00,0x00,0x00,0x00,0x00};//0x18ea0021
    INT32U id;

    if (s_sclockpara.ecutype != ECU_YUCHAI) return;
    switch(s_sclockstep) {
        case CONFIG_REQ:
            #if DEBUG_LOCK > 0
                debug_printf("���÷���\r\n");
            #endif
            CAN_TxData(senddata, false, LOCK_CAN_CH);
            id = bal_chartolong(senddata);
            SetCANMsg_Period(id, &senddata[4], YC_HANDSK_PERIOD / 10, LOCK_CAN_CH); /* ��������1000ms -> 800ms */
            s_sclockstep = RAND_CODE_REC;
            break;
        case CHECK_CODE_SEND:
            senddata[1] = 0xfe;         /* ���� 0x18fe02fb ���� */
            senddata[2] = 0x02;
            senddata[3] = 0xfb;
            memcpy(&senddata[5],s_key,8);
            CAN_TxData(senddata, false, LOCK_CAN_CH);
            #if DEBUG_LOCK > 0
                debug_printf("У����s_key����  ");
                printf_hex(&senddata[5], 8);
            #endif
            id = bal_chartolong(senddata);
            SetCANMsg_Period(id, &senddata[4], YC_HANDSK_PERIOD/10, LOCK_CAN_CH); /* ��������1000ms -> 800ms */
            s_sclockstep = CONFIG_CONFIRM_REC;
            break;
        default:
            break;
    }
}
/**************************************************************************************************
**  ��������:  YC_Set18ea0021Period
**  ��������:  ����������ڷ�������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
static void YC_Set18ea0021Period(void)
{
    INT8U senddata[13] = {0x18,0xea,0x00,0x21,0x08,0x01,0xfd,0x00,0x00,0x00,0x00,0x00,0x00};//0x18ea0021
    INT32U id;

    if (s_sclockpara.ecutype != ECU_YUCHAI) return;

    id = bal_chartolong(senddata);
    SetCANMsg_Period(id, &senddata[4], YC_HANDSK_PERIOD / 10, LOCK_CAN_CH); /* ��������1000ms -> 800ms */

}
/**************************************************************************************************
**  ��������:  HandShakeMsgAnalyze
**  ��������:  CAN������ر��Ľ�����������,�����ж��У���ʱ����
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void HandShakeMsgAnalyze(CAN_DATA_HANDLE_T *CAN_msg, INT16U datalen)
{
    INT32U id;
    INT32U seed;
    INT8U can_seed[4];
    INT8U  senddata[13] = {0x18,0xfe,0x02,0xfb,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; // 0x18fe02fb



     id = bal_chartolong(CAN_msg->id);
     #if DEBUG_CAN > 0
        //Debug_SysPrint("�յ�CANid:%x\r\n", id);
     #endif

    if (s_sclockpara.ecutype == ECU_YUCHAI) {
        #if 0
    	if (id == 0x18fff400) {
            if (CAN_msg->databuf[7] == 0x01) {
                if (!s_ecuonoffstat) {
                    if (!s_sclockpara.unbindstat) {
                        s_sclockstep = CONFIG_REQ;
                        YC_HandShake();
                        s_ecuonoffstat = true;
                    }
                }
                s_ecuonoffstat = true;
            } else if (CAN_msg->databuf[7] == 0x00) {
                s_ecuonoffstat = false;
            }
        }
        #endif

        if (id == 0x18fd0100) {


            if (s_sclockstep == RAND_CODE_REC) {
                    #if DEBUG_LOCK > 0
                        debug_printf("�����seed����\r\n");
                    #endif

                    seed = bal_chartolong(CAN_msg->databuf);
                    if (((CAN_msg->databuf[5] & 0x70) == 0x70) && (seed != 0) && ((CAN_msg->databuf[7] & 0x0f) == 0x0d)) {
                        #if DEBUG_LOCK > 0
                            debug_printf("�����֡У��ɹ�������key\r\n");
                        #endif
                        memcpy(s_seed, CAN_msg->databuf, 4);
                        YX_LC_InputSeed(s_seed,4);
                        YX_LC_GetHKey(s_key);
                        s_sclockstep = CHECK_CODE_SEND;
                        YC_HandShake();
                    } else if (((CAN_msg->databuf[5] & 0x70) == 0x50) && (seed != 0)) {
                        s_sclockstep = CONFIG_OVER;
                        s_idfiltenable = TRUE;
                        f_handsk = true;
                        StopCANMsg_Period(0x18fe02fb, LOCK_CAN_CH);
                        s_handskenable = FALSE;
                        /* ���ֳɹ�������ȫ0�����־��0x18fe02fb */
                        CAN_TxData(senddata, false, LOCK_CAN_CH);
                        #if DEBUG_LOCK > 0
                        debug_printf("�Ѽ����������\r\n");
                        #endif
                    }
               } else if (s_sclockstep == CONFIG_CONFIRM_REC) {
                    if( (CAN_msg->databuf[5]& 0x30 ) == 0x10){//У��ͨ��
                        s_sclockstep = CONFIG_OVER;
                        s_idfiltenable = TRUE;
                        f_handsk = true;
                        StopCANMsg_Period(0x18fe02fb, LOCK_CAN_CH);
                        s_handskenable = FALSE;
                        /* ���ֳɹ�������ȫ0�����־��0x18fe02fb */
                        CAN_TxData(senddata, false, LOCK_CAN_CH);
                        #if DEBUG_LOCK > 0
                            debug_printf("���ֳɹ�\r\n");
                        #endif
                    }else{
                        if((f_handskcnt++) == 3){
                            f_handskcnt = 0;
                            s_sclockstep = CONFIG_OVER;
                            StopCANMsg_Period(0x18fe02fb, LOCK_CAN_CH);
                            s_idfiltenable = TRUE;
                            f_handsk = false;
                            s_handskenable = FALSE;
                        }
                    }
             }


            memcpy(s_lockstatid,CAN_msg->id,4);
            memcpy(s_lockstatid + 4,CAN_msg->databuf,8);
            //memcpy(s_seed, CAN_msg->databuf, 4);
            #if DEBUG_LOCK > 0
                debug_printf("id = %x\r\n",id);
            #endif

            memcpy(can_seed, CAN_msg->databuf, 4);
            /* ����У�� */
            if ((TRUE == f_handsk) && (!s_sclockpara.unbindstat)) {

                if( can_seed[0] != s_ycseed[0] ||
                    can_seed[1] != s_ycseed[1] ||
                    can_seed[2] != s_ycseed[2] ||
                    can_seed[3] != s_ycseed[3]) {
                    /* seed ���£������µ����ּ������� */
                    if(can_seed[0] == 0&& can_seed[1] == 0 && can_seed[2] == 0&&can_seed[3] == 0){

                    }else{
                       // if ((CAN_msg->databuf[5] & 0x30) == 0x30) { /* δУ�� */
                            f_handsk     = FALSE;
                            s_sclockstep = CONFIG_REQ;
                            YC_HandShake();
                            #if DEBUG_LOCK > 0
                                debug_printf("YC_EcuAnalyze - seed ���£������µ����ּ�������  ");
                            #endif
                       // }
                   }
                }
            }

            /* ����seed */
            s_ycseed[0] = can_seed[0];
            s_ycseed[1] = can_seed[1];
            s_ycseed[2] = can_seed[2];
            s_ycseed[3] = can_seed[3];


        }
    }
    if (s_sclockpara.ecutype == ECU_WEICHAI) {
        if (id == 0x18fd0100) {
            if(!s_sclockpara.unbindstat){
                s_md5source[0] = s_sclockpara.firmcode[0];
                s_md5source[1] = s_sclockpara.firmcode[1];
                s_md5source[2] = s_sclockpara.firmcode[2];
                s_md5source[3] = CAN_msg->databuf[0];
                s_md5source[4] = CAN_msg->databuf[1];
                s_md5source[5] = CAN_msg->databuf[2];
                s_md5source[6] = CAN_msg->databuf[3];
                s_md5source[7] = CAN_msg->databuf[4];
                MDString(s_md5source,s_md5result,sizeof(s_md5source));
                s_sclockstep = CHECK_CODE_SEND;
                WC_HandShake();
           }
        }
        if (id == 0x18FF0800) {
            if (s_sclockpara.ecutype == ECU_WEICHAI) {
                if (s_sclockstep == CONFIG_CONFIRM_REC) {
                    s_idfiltenable = TRUE;
                    s_sclockstep = CONFIG_OVER;
                    StopCANMsg_Period(0x18ffc21c, LOCK_CAN_CH);
                }
                memcpy(s_lockstatid,CAN_msg->id,4);
                memcpy(s_lockstatid + 4,CAN_msg->databuf,8);
            }
        }
    }
}
/**************************************************************************************************
**  ��������:  SendLockPara
**  ��������:  ��������ͬ��֡
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/

void SendLockPara(void)
{
    INT8U senddata[200];
    INT8U len = 0;

    bal_pp_ReadParaByID(SCLOCKPARA_,(INT8U *)&s_sclockpara, sizeof(SCLOCKPARA_T));
    bal_shorttochar(senddata, CLIENT_CODE);
    senddata[2] = 0x01;
    len = 3;
    senddata[len++] = s_sclockpara.ecutype;
    senddata[len++] = s_sclockpara.firmcodelen;
    memcpy(&senddata[len], s_sclockpara.firmcode, s_sclockpara.firmcodelen);
    len += s_sclockpara.firmcodelen;
    senddata[len++] = s_sclockpara.srlnumberlen;
    memcpy(&senddata[len], s_sclockpara.serialnumber, s_sclockpara.srlnumberlen);
    len += s_sclockpara.srlnumberlen;
    senddata[len++] = s_sclockpara.unbindstat;
    senddata[len++] = s_sclockpara.limitfunction;
    memcpy(&senddata[len], s_lockstatid, 12);
    if(GetAccState() == false){
        memset(&s_lockstatid, 0, sizeof(s_lockstatid));
    }
    YX_COM_DirSend(CLIENT_FUNCTION_DOWN_REQ_ACK, senddata, len + 12);

}

/**************************************************************************************************
**  ��������:  Lock_RecordReqHdl
**  ��������:  ��̨��ȡM3������־
**  �������:
**  ���ز���:  None
**************************************************************************************************/
void Lock_RecordReqHdl(void)
{
    INT8U senddata[150];
    INT8U datalen = 0, i;

    senddata[datalen++] = 0x09;
    senddata[datalen++] = 0x18;
    senddata[datalen++] = 0x02;
    senddata[datalen++] = s_lockrecord.storenum;
    if (s_lockrecord.storenum < 10) {
        for (i = 0;i < s_lockrecord.storenum; i++) {
            senddata[datalen++] = 8;
            memcpy(senddata + datalen, &s_lockrecord.lockrecord[i].locktime, 6);
            datalen += 6;
            senddata[datalen++] = s_lockrecord.lockrecord[i].locktype;
            senddata[datalen++] = 0;
        }
    } else {
        for (i = 0; i < 10; i++) {
            senddata[datalen++] = 8;
            memcpy(senddata + datalen, &s_lockrecord.lockrecord[(s_lockrecord.storeadd + i)%10].locktime, 6);
            datalen += 6;
            senddata[datalen++] = s_lockrecord.lockrecord[(s_lockrecord.storeadd + i)%10].locktype;
            senddata[datalen++] = 0;
        }
    }

    YX_COM_DirSend(CLIENT_FUNCTION_DOWN_REQ_ACK, senddata, datalen);
    #if DEBUG_CAN > 0
        debug_printf("������־");
        printf_hex(senddata, datalen);
    #endif

}

/**************************************************************************************************
**  ��������:  LockParaStore
**  ��������:  ���������洢������ͬ������״̬
**  �������:  ECU���ͣ�1��+��Կ��3��+GPSid��3��+�������ͣ�1��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
void LockParaStore(INT8U *userdata, INT8U userdatalen)
{
    BOOLEAN change = FALSE;
    BOOLEAN unbindchange = FALSE;
    INT8U len = 0,len1 = 0;

    //if (userdatalen != 8) return;

    #if 0 /* ����Ϋ��������10s���ֹͣ�ˣ���������������ɳ�̨���ƺ�ʱֹͣ */
    if (s_sclockpara.ecutype != ECU_YUCHAI) { /* ���, �ɳ�̨���ƺ�ʱֹͣ */
        if (s_parasendstat) {
            StopCANMsg_Period(0x18ea0021,0);  /* ��һ���յ���̨ͬ��֡(FDH)��ֹͣ����0x18ea0021 */
        }
    }
    #endif

    s_parasendstat = FALSE;
    #if EN_DEBUG > 0
        debug_printf("�·���������FD-01:");
        printf_hex(userdata,userdatalen);
        debug_printf("/r/n");
    #endif

    if (userdatalen != 11) {                        // �ܳ��Ȳ�����

        #if EN_DEBUG > 0
            debug_printf("�ܳ��Ȳ�����");
        #endif
        SendLockPara();
        return;
    }

    if (s_sclockpara.ecutype != userdata[len]) {
        //if (userdata[len] >= MAX_ECU_TYPE) {        // ���������ͷǷ�
        //    SendLockPara();
        //    return;
        //}
        change = TRUE;
        s_sclockpara.ecutype = userdata[len];
    }
    len++;
    len1 = userdata[len];
    if (s_sclockpara.ecutype == ECU_YUCHAI) {           // ���Ϋ��Ĺ̶���Կ��GPSID���ȷֱ�Ϊ(3��3)��(2��4)
        if (len1 != 2) {                                // �̶���Կ���ȷǷ�
            SendLockPara();
            return;
        }
    } else if (s_sclockpara.ecutype == ECU_WEICHAI) {
        if (len1 != 3) {                                // �̶���Կ���ȷǷ�
            SendLockPara();
            return;
        }
    }
    if (s_sclockpara.firmcodelen != len1) {
        change = TRUE;
        s_sclockpara.firmcodelen = len1;
        memcpy(s_sclockpara.firmcode, &userdata[len + 1], len1);
    } else {
        if (STR_EQUAL != bal_ACmpString(FALSE, s_sclockpara.firmcode, &userdata[len + 1], s_sclockpara.firmcodelen, len1)) {
            change = TRUE;
            memcpy(s_sclockpara.firmcode, &userdata[len + 1], len1);
        }
    }
    len += (len1 + 1);

    len1 = userdata[len];
    if (s_sclockpara.ecutype == ECU_YUCHAI) {
        if (len1 != 4) {                                // �̶���Կ���ȷǷ�
            SendLockPara();
            return;
        }
    } else if (s_sclockpara.ecutype == ECU_WEICHAI) {
        if (len1 != 3) {                                // �̶���Կ���ȷǷ�
            SendLockPara();
            return;
        }
    }
    if (s_sclockpara.srlnumberlen != len1) {
        change = TRUE;
        s_sclockpara.srlnumberlen = len1;
        memcpy(s_sclockpara.serialnumber, &userdata[len + 1], len1);
    } else {
        if (STR_EQUAL != bal_ACmpString(FALSE, s_sclockpara.serialnumber, &userdata[len + 1], s_sclockpara.srlnumberlen, len1)) {
            change = TRUE;
            memcpy(s_sclockpara.serialnumber, &userdata[len + 1], len1);
        }
    }
    len += (len1 + 1);
    if (s_sclockpara.unbindstat != userdata[len]) {
        s_sclockpara.unbindstat = userdata[len];
        change = TRUE;
        unbindchange = TRUE;
        if(!s_sclockpara.unbindstat){
            s_sclockstep = CONFIG_REQ;
            YC_HandShake();
        }else{
            f_handsk = FALSE;
            StopCANMsg_Period(0x18ea0021, LOCK_CAN_CH);
        }

        #if EN_DEBUG > 0
            debug_printf("���״̬�ı�:%d \r\n", s_sclockpara.unbindstat);
        #endif
    }
    len++;
    if (s_sclockpara.limitfunction != userdata[len]) {
        change = TRUE;

        if(userdata[len] == LC_CMD_BIND){
           YC_Set18ea0021Period();
        }

        if (++s_lockrecord.storenum >= 10) {
            s_lockrecord.storenum = 10;
        }
        PORT_GetSysTime1((SYSTIME_T *)&s_lockrecord.lockrecord[s_lockrecord.storeadd].locktime);
        s_lockrecord.lockrecord[s_lockrecord.storeadd].locktype = userdata[len];
        if (++s_lockrecord.storeadd >= 10) {
            s_lockrecord.storeadd = 0;
        }

        s_sclockpara.configsuccess = FALSE;
        s_sclockpara.limitfunction = userdata[len];
    }
    len++;

    if (change) {
        #if EN_DEBUG > 0
            debug_printf("ͬ��״̬�ı� \r\n");
            debug_printf("LockParaStore ecutype:%d unbindstat:%d\r\n", s_sclockpara.ecutype, s_sclockpara.unbindstat);
        #endif


        bal_pp_StoreParaByID(SCLOCKPARA_, (INT8U *)&s_sclockpara, sizeof(SCLOCKPARA_T));
        bal_pp_StoreParaByID(LOCKRECORD_, (INT8U *)&s_lockrecord, sizeof(LOCK_RECORD));

        if (unbindchange) {
            BakParaSave(s_sclockparabak.lock_en);
        }

    }
    SendLockPara();
}

void GetGpsID(INT8U *gpsid)
{
    memcpy(gpsid, s_sclockpara.serialnumber,s_sclockpara.srlnumberlen);
}

/**************************************************************************************************
**  ��������:  LockParaBak
**  ��������:  �������״̬���ݣ��������ܿ���ͬ��
**  �������:  �������ܿ��أ�1��
**  �������:  TRUE-����ɹ�  FALSE-δ����
**  ���ز���:  ��
**************************************************************************************************/
BOOLEAN LockParaBak(INT8U *userdata, INT8U userdatalen)
{
    #if EN_DEBUG > 0
        debug_printf("�������״̬���ݣ��������ܿ���ͬ�� len:%d  data:", userdatalen);
        printf_hex(userdata,userdatalen);
    #endif

    if (userdatalen != 1) {                        // �ܳ��Ȳ�����
        return FALSE;
    }

    bal_pp_ReadParaByID(SCLOCKPARABAK_,(INT8U *)&s_sclockparabak, sizeof(SCLOCKPARABAK_T));

    if (s_sclockparabak.lock_en != userdata[0]) {
        s_sclockparabak.lock_en = userdata[0];
        BakParaSave(s_sclockparabak.lock_en);
    } else {
        return FALSE;
    }

    return TRUE;
}

/**************************************************************************************************
**  ��������:  BakParaSave
**  ��������:  �������״̬���ݣ��������ܿ���ͬ��
**  �������:  locken: �������ܿ���
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
void BakParaSave(INT8U locken)
{
    INT8U sum;

    bal_pp_ReadParaByID(SCLOCKPARA_,(INT8U *)&s_sclockpara, sizeof(SCLOCKPARA_T));

    s_sclockparabak.lock_en = locken;
    s_sclockparabak.lock_en_bak1 = locken;
    s_sclockparabak.lock_en_bak2 = locken;
    s_sclockparabak.unbindstat_bak1 = s_sclockpara.unbindstat;
    s_sclockparabak.unbindstat_bak2 = s_sclockpara.unbindstat;
    sum = s_sclockparabak.lock_en + s_sclockparabak.lock_en_bak1 + s_sclockparabak.lock_en_bak1
        + s_sclockparabak.unbindstat_bak1 + s_sclockparabak.unbindstat_bak2;
    s_sclockparabak.chksum = sum;

    #if EN_DEBUG > 0
        debug_printf("BakParaSave \r\n");
        debug_printf("lock_en:%d lock_en bak1:%d lock_en bak2:%d\r\n", s_sclockparabak.lock_en, s_sclockparabak.lock_en_bak1, s_sclockparabak.lock_en_bak2);
        debug_printf("unbindstat:%d unbindstat bak1:%d unbindstat bak2:%d\r\n", s_sclockpara.unbindstat, s_sclockparabak.unbindstat_bak1, s_sclockparabak.unbindstat_bak2);
        debug_printf("s_sclockparabak.chksum:0x%02x\r\n\r\n", s_sclockparabak.chksum);
    #endif

}


/**************************************************************************************************
**  ��������:  IsBind
**  ��������:  �ж��Ƿ�Ϊ��״̬
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
BOOLEAN IsShakeEn(void)
{
    INT8U chksum;

    bal_pp_ReadParaByID(SCLOCKPARABAK_,(INT8U *)&s_sclockparabak, sizeof(SCLOCKPARABAK_T));

    chksum = s_sclockparabak.lock_en + s_sclockparabak.lock_en_bak1 + s_sclockparabak.lock_en_bak1
           + s_sclockparabak.unbindstat_bak1 + s_sclockparabak.unbindstat_bak2;
    if (chksum != s_sclockparabak.chksum) {
        #if EN_DEBUG > 0
            debug_printf("IsShakeEn FALSE (У��ʹ���) \r\n");
        #endif
        return FALSE;
    }


    #if EN_DEBUG > 0
        debug_printf("s_sclockpara.unbindstat:%d bak1:%d bak2:%d\r\n", s_sclockpara.unbindstat, s_sclockparabak.unbindstat_bak1, s_sclockparabak.unbindstat_bak2);
        debug_printf("s_sclockparabak.lock_en:%d bak1:%d bak2:%d\r\n", s_sclockparabak.lock_en, s_sclockparabak.lock_en_bak1, s_sclockparabak.lock_en_bak2);
    #endif

    if ((!s_sclockpara.unbindstat)
     && (!s_sclockparabak.unbindstat_bak1)
     && (!s_sclockparabak.unbindstat_bak2)
     && (s_sclockparabak.lock_en)
     && (s_sclockparabak.lock_en_bak1)
     && (s_sclockparabak.lock_en_bak2)){
        #if EN_DEBUG > 0
            debug_printf("IsShakeEn TRUE \r\n");
        #endif
        return TRUE;
    } else {
        #if EN_DEBUG > 0
            debug_printf("IsShakeEn FALSE (����������) \r\n");
        #endif
        return FALSE;
    }
}

/**************************************************************************************************
**  ��������:  CanLocateFiltidSet
**  ��������:  ������������ID����
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void CanLocateFiltidSet(void)
{
    IDPARA_T canid;
    INT8U i,idnum,j;

    canid.isused = FALSE;
    for (i = 0; i < MAX_CANIDS; i++) {                      /* ����������ù���ID�˲����� */
        SetIDPara(&canid, i, 1);
    }

    PORT_ClearCanFilter(LOCK_CAN_CH);                           /* �����Ϣ���� */

    idnum = sizeof(s_filtid)/sizeof(s_filtid[0]);
    #if DEBUG_CAN > 0
        debug_printf("idnum = %d\r\n",idnum);
    #endif
    //idnum = 4;
    for (i = 0; i < idnum; i++) {
        PORT_SetCanFilter(LOCK_CAN_CH, 1,s_filtid[i], 0xffffffff);
        canid.id = s_filtid[i];
        canid.stores = 1;
        canid.isused = TRUE;
        for (j = 0; j < MAX_CANIDS; j++) {
            if (FALSE == GetIDIsUsed(j, LOCK_CAN_CH)) break;        /* ���ҵ�δ�����õģ��������� */
        }
        SetIDPara(&canid, j, LOCK_CAN_CH);
    }
}

/**************************************************************************************************
**  ��������:  CANAppTmrProc
**  ��������:  CANӦ�ò�ģ�鶨ʱ����
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
static void LockTmrProc(void*index)
{
    INT8U acc_state;
    #if EN_KMS_LOCK > 0
    static INT16U acc_off_delay = 0;
    #endif
    INT8U senddata[13] = {0x18,0xea,0x00,0x21,0x08,0xcb,0xfe,0x00,0xff,0xff,0xff,0xff,0xff}; /* 0x18ea0021 */
	INT32U accpwrad;
    //acc_state = bal_input_ReadSensorFilterStatus(TYPE_ACC);
	accpwrad	 = PORT_GetADCValue(ADC_ACCPWR);
	if(accpwrad >= 2800){
		acc_state = FALSE;
	}else{
		acc_state = TRUE;
	}

    #if EN_KMS_LOCK > 0
    if (!acc_state) {
        acc_off_delay = 3000;    /* ��ʱ30�� */
        KmsG5LockMsgSend();
    } else {
        /* acc off��ʱ30��ֹͣ���� */
        if (acc_off_delay) {
            acc_off_delay--;
            KmsG5LockMsgSend();
        }
    }
    #endif

    #if 0
    if (++s_reqcnt >= 3000/*2500*/) {                /* 2017-06-12 �޸��ͺ���������Ϊ30�� */
        s_reqcnt = 0;
        senddata[5] = 0xe9;                        /* 0xe9 �����ͺ� */
        CAN_TxData(senddata, false, 1);
    }
    #else
    if(acc_state == FALSE){    //ACC ON
        if(s_poweron_times_cnt < 12000){// 12000             /* �ϵ�2�����ڼ����û���յ��ͺı���ID:0x18FEE900 */
            s_poweron_times_cnt++;
            s_oilsumreq = GetOilMsg_State();
            s_reqcnt = 3000;                         /* ���û������ID,1���Ӻ���������ϱ��ͺ����� */
        }else{
            if(s_oilsumreq == TRUE){
                if (++s_reqcnt >= 3000/*2500*/) {                /* 2017-06-12 �޸��ͺ���������Ϊ30�� */
                    s_reqcnt = 0;
                    senddata[5] = 0xe9;                        /* 0xe9 �����ͺ� */
                    CAN_TxData(senddata, false, LOCK_CAN_CH);
                }
            }
        }
    }
    else{    //ACC OFF
        s_poweron_times_cnt = 0;
        ResetOilMsg_State();
    }
    #endif


    if (++s_idfiltcnt >= 900) {                    /* 10���������̨������������ */
        s_idfiltenable = TRUE;
        if(TRUE == s_handskenable){
            s_handskenable = FALSE;
            if(s_sclockstep == RAND_CODE_REC){
                s_sclockstep = CONFIG_OVER;
            }
            if (s_sclockpara.ecutype != ECU_YUCHAI) {/* ���10s��ʱ��ֹͣ���ͣ��ɳ�̨���ƺ�ʱֹͣ */
                StopCANMsg_Period(0x18ea0021, LOCK_CAN_CH);
            }else{
                if(s_sclockpara.unbindstat == 0){
                    StopCANMsg_Period(0x18ea0021, LOCK_CAN_CH);
                }
            }
        }
    }

    if (++s_parasendcnt >= 100) {                   /* ����ÿ�뷢��ͬ��֡��ֱ����̨��Ӧ */
        s_parasendcnt = 0;
        if (s_parasendstat) {
            //SendLockPara();
        }
    }
}

/**************************************************************************************************
**  ��������:  ACCON_HandShake
**  ��������:  ACC�ϵ����ִ���
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void ACCON_HandShake(void)
{
    s_parasendstat = TRUE;
    s_handskenable = TRUE;
    s_idfiltenable = FALSE;
    s_idfiltcnt    = 0;
    s_parasendcnt  = 0;

    memset(&s_ycseed, 0, sizeof(s_ycseed));

    OS_StartTmr(s_lock_tmr, MILTICK, 1);

    if (s_sclockpara.ecutype == ECU_YUCHAI){
         if (!s_sclockpara.unbindstat) {
             f_handsk = FALSE;
             s_sclockstep = CONFIG_REQ;
             YC_HandShake();
             #if DEBUG_LOCK > 0
                 debug_printf("App_CAN_Init YC_HandShake\r\n");
             #endif
         }
    }


}

/**************************************************************************************************
**  ��������:  ACCOFF_HandShake
**  ��������:  ACC�ϵ����ִ���
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void ACCOFF_HandShake(void)
{
   if (s_sclockpara.ecutype == ECU_YUCHAI){
     #if DEBUG_LOCK > 0
         debug_printf("stop\r\n");
      #endif
      s_idfiltenable = FALSE;
      f_handsk = FALSE;
      StopCANMsg_Period(0x18ea0021, LOCK_CAN_CH);
      StopCANMsg_Period(0x18fe02fb, LOCK_CAN_CH);
   }
}

#if EN_KMS_LOCK > 0
/**************************************************************************************************
**  ��������:  Lock_KmsG5Cmd
**  ��������:  ��������˹��5����ָ��
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
void Lock_KmsG5Cmd(INT8U* data, INT16U len) 
{
    BOOLEAN is_change;
    INT8U ack[10];
    /* client code */
    ack[0] = 0x09;
    ack[1] = 0x18;

    /* ָ�� */
    ack[2] = 0x2e;

    /* ��ˮ�� */
    ack[3] = data[0];

    ack[4] = 0x00;

    is_change = FALSE;

    #if DEBUG_LOCK > 1
    debug_printf("<Lock_KmsG5Cmd,cmd:0x%x, speed[0]:0x%x,speed[1]:0x%x>\r\n",s_kms_obj.kms_cmd, s_kms_obj.rota_speed[0], s_kms_obj.rota_speed[1]);
    printf_hex(data, len);
    #endif
    
    if ((data[1] >= KMS_CMD_ACTIVE) && (data[1] <= KMS_CMD_CLOSE)) {

        if (data[1] == KMS_CMD_LOCK) {
            if ((data[2] != s_kms_obj.rota_speed[0]) || (data[3] != s_kms_obj.rota_speed[1])) {
                s_kms_obj.rota_speed[0] = data[2];
                s_kms_obj.rota_speed[1] = data[3];
                is_change = TRUE;
            }
        }
        
        if (data[1] != s_kms_obj.kms_cmd) {
            s_kms_obj.kms_cmd = data[1];
            is_change = TRUE;
        } 
    } else {
        ack[4] = 0x01;  /* ʧ�� */
    }

    if (is_change) {
        is_change = FALSE;
        bal_pp_StoreParaByID(KMS_LOCK_PARA_,(INT8U *)&s_kms_obj, sizeof(KMS_LOCK_OBJ_T));
    }
    
    YX_COM_DirSend( CLIENT_FUNCTION_DOWN_REQ_ACK, ack, 5);
}
#endif

/**************************************************************************************************
**  ��������:  Lock_Init
**  ��������:  ������ʼ��
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
void Lock_Init(void)
{

    bal_pp_ReadParaByID(LOCKRECORD_,(INT8U *)&s_lockrecord, sizeof(LOCK_RECORD));
    bal_pp_ReadParaByID(SCLOCKPARA_,(INT8U *)&s_sclockpara, sizeof(SCLOCKPARA_T));
    #if EN_KMS_LOCK > 0
    bal_pp_ReadParaByID(KMS_LOCK_PARA_,(INT8U *)&s_kms_obj, sizeof(KMS_LOCK_OBJ_T));
    #endif
    CanLocateFiltidSet();

    s_lock_tmr = OS_InstallTmr(TSK_ID_OPT, 0, LockTmrProc);

    ACCON_HandShake();

}

