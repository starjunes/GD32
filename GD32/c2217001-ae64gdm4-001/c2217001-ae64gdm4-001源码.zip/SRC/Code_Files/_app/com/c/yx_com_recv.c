/*
********************************************************************************
** �ļ���:     yx_com_recv.c
** ��Ȩ����:   (c) 2017 ������Ѹ����ɷ����޹�˾
** �ļ�����:    Э�����ݴ����ӿ�(����)
** �����ˣ�        л��ɣ�2017.5.18
********************************************************************************
*/
#include  "yx_includes.h"
#include  "yx_protocal_type.h"
#include  "yx_protocal_hdl.h"
#include  "yx_com_recv.h"
#include  "yx_com_send.h"
#include  "yx_com_man.h"
/******************************************************************************/
/*                           Э�������봦�����������ṹ��                                                                                                             */
/*********************************************************** ******************/
#define  PERIOD_SCAN               MILTICK,1              /* 10ms */
#define  SIZE_RECVBUF              1536



typedef struct {
    INT8U  command;                                       /* �������    */
    void   (*hdl)(INT8U,INT8U,INT8U *, INT16U);           /* ָ��ӿں���ָ��     */
}PROTOHDL_REG_S;


typedef struct {
    INT8U  chksum;                               /* У����                        */
    INT8U  version;                              /* Э��汾                  */
    INT8U  devcode;                              /* �������                  */
   // INT8U  devid;                                /* �������                  */
    INT8U  command;                              /* ����                              */
} RECV_FRAME_HEAD_S;


/******************************************************************************/
/*                           ע��ӿں���                                                                                                                                                */
/******************************************************************************/

#ifdef   PROTOHDL_REG_DEF
#undef   PROTOHDL_REG_DEF
#endif

#define  PROTOHDL_REG_DEF(_COMMAND_,_HDL)  {_COMMAND_,_HDL},

 static  const PROTOHDL_REG_S  s_protohdl_reg_tbl[] = {
        #include "yx_protohdl_reg.def"
        {0,0}
 };

/******************************************************************************/
/*                           ������ر���                                                                                                                                                */
/******************************************************************************/
 static INT8U   s_recvbuf[SIZE_RECVBUF];
 static INT16S  s_recvlen = -1;
 static INT8U   s_scantmrid;                              /* ɨ�趨ʱ�� */
 static ASMRULE_T  s_rules = {0x7e, 0x7d, 0x02, 0x01};    /* ת�����   */

/*******************************************************************************
**  ��������:  ParseRecvProtocolData
**  ��������:  ���������������ڵ�Э�����ݣ�ͨ����������ע����������Ӧ�Ĵ�������
**  �������:  data     : ָ����յ���Э������
**          :  datalen  : Э�����ݳ���
**  ���ز���:  None
*******************************************************************************/
static void ParseRecvProtocolData(INT8U *data, INT16U datalen)
{
    INT8U  i;
    INT8U  nums;
    INT8U *userdata;
    INT16U userdatalen;

    RECV_FRAME_HEAD_S *recvhead = (RECV_FRAME_HEAD_S *)data;

    #if DEBUG_COM_REC > 0
    debug_printf("data:");              /* ��ӡ��Ϣ */
    printf_hex(data,datalen > 30 ? 30 : datalen);
    debug_printf("\r\n");              /* ��ӡ��Ϣ */
    #endif
		if (recvhead->devcode != DEV_CODE) return;

    nums        = sizeof(s_protohdl_reg_tbl) / sizeof(s_protohdl_reg_tbl[0]) -1;
    userdata    = data + sizeof(RECV_FRAME_HEAD_S);
    userdatalen = datalen - sizeof(RECV_FRAME_HEAD_S);
    for (i = 0; i < nums; i++) {
        if (s_protohdl_reg_tbl[i].command == recvhead->command) {
            if (s_protohdl_reg_tbl[i].hdl != 0) {
                s_protohdl_reg_tbl[i].hdl(recvhead->version, recvhead->command, userdata, userdatalen);
            }
            return;
        }
    }

}

#if 0
/*******************************************************************************
**  ��������:  ScanTmrProc
**  ��������:  ��ʱɨ����ں���
**  �������:  None
**  ���ز���:  None
*******************************************************************************/
static INT16S FindFrameHead(INT8U *pdata, INT16U datalen)
{
    INT16U findpos, dlen;
    INT8U *dataptr;

    dataptr = pdata;
    dlen = datalen;
    while (dlen > 0) {
        findpos = bal_FindCharPos(dataptr, 0xaa, 0, dlen);
        if (findpos == dlen - 1) return datalen - 1;
        if (findpos == dlen) return -1;
        if (*(dataptr + findpos + 1) == 0x75) return findpos + (dataptr - pdata);
        dataptr += findpos + 1;
        dlen -= findpos + 1;
    }
    return -1;
}

// ����FALSE��ʾ��Ҫ�˳�ѭ������
static BOOLEAN HandleFrame(void)
{
    INT16U  datalen;
    INT16S findpos;

    if (s_recvlen >= 7) {
    	datalen = ((s_recvbuf[5] << 8) + s_recvbuf[6]);
        if ((datalen + 7) > SIZE_RECVBUF) {                   // �ܳ���������
            s_recvlen -= 2;
            findpos = FindFrameHead(s_recvbuf + 2, s_recvlen);
            if (findpos != -1) {
                s_recvlen -= findpos;
                memmove(s_recvbuf, s_recvbuf + 2 + findpos, s_recvlen);
                return true;
            } else {
                s_recvlen = 0;
                return FALSE;
            }
        }
        if (s_recvlen >= (datalen + 7)) {                     // �������
            if ((s_recvbuf[2] ==  bal_ChkSum_Xor(s_recvbuf + 4, datalen + 3)) && (s_recvbuf[3] == DEVICETYPE)) {
                ParseRecvProtocolData(s_recvbuf + 4, datalen + 3);
                s_recvlen -= datalen + 7;
                if(s_recvlen != 0) {
                	memmove(s_recvbuf, s_recvbuf + datalen + 7, s_recvlen);
                }
            } else {
                s_recvlen -= 2;
                findpos = FindFrameHead(s_recvbuf + 2, s_recvlen);
                if (findpos != -1) {
                    s_recvlen -= findpos;
                    memmove(s_recvbuf, s_recvbuf + 2 + findpos, s_recvlen);
                }
            }
        } else {
            return FALSE;
        }
    }
    return TRUE;
}
#endif


static void ScanTmrProc(void* pdata)
{
    INT16S  curchar;
    //BOOLEAN ret;
    while ((curchar = PORT_UartRead(MAIN_COM)) != -1) {
        if (s_recvlen == -1) {
            if (curchar == 0x7e) {
                s_recvlen = 0;
            }
            #if DEBUG_COM_REC > 1
            debug_printf("receive: %02x ", curchar);              /* ��ӡ��Ϣ */
            #endif
        } else {
             #if DEBUG_COM_REC > 1
             debug_printf("%02x ", curchar);                     /* ��ӡ��Ϣ */
             #endif
             if (curchar == 0x7e) {
                #if DEBUG_COM_REC > 1
                debug_printf("\r\n", curchar);                     /* ��ӡ��Ϣ */
                #endif
                if (s_recvlen > 0) {
                    #if DEBUG_CAN_OTA > 1
                    if (DATA_SEQ_TRANSF_CAN == s_recvbuf[3]) {
                        //debug_printf("s_recvbuf %d:", s_recvlen);
                        //printf_hex_dir(s_recvbuf, s_recvlen);
                        //debug_printf("\r\n");
                        //printf_hex(&s_recvbuf[256], 30);
                        //debug_printf("\r\n");
                    }
                    #endif

                    s_recvlen = bal_DeassembleByRules(s_recvbuf,s_recvbuf, (INT16U)s_recvlen, &s_rules);
                    if (s_recvbuf[0] == bal_GetChkSum(&s_recvbuf[1], s_recvlen - 1)) {
                        if (s_recvlen >= 2) {
                            ParseRecvProtocolData(s_recvbuf, s_recvlen);
                        }
                    } else {
                        #if DEBUG_CAN_OTA > 1
                        debug_printf("ChkSumErr\r\n", curchar);                     /* ��ӡ��Ϣ */
                        #endif
                    }
                    s_recvlen = -1;
                }
            } else {
                if (s_recvlen >= SIZE_RECVBUF) {
                    s_recvlen = -1;
                    #if DEBUG_CAN_OTA > 0
                    debug_printf("s_recvlen >= SIZE_RECVBUF\r\n");                     /* ��ӡ��Ϣ */
                    #endif
                } else {
                    s_recvbuf[s_recvlen++] = (INT8U)curchar;
                }
            }
        }
	}
}

/*******************************************************************************
**  ��������:  YX_ComRecv_Init
**  ��������:  ��ʼ������Э������ģ��
**  �������:  None
**  ���ز���:  None
*******************************************************************************/
void YX_ComRecv_Init(void)
{
	s_scantmrid = OS_InstallTmr(TSK_ID_OPT, 0, ScanTmrProc);
	OS_StartTmr(s_scantmrid, PERIOD_SCAN);
}

/************************ (C) COPYRIGHT 2010 XIAMEN YAXON.LTD *****************/
 /*****END OF FILE******/
