/*
********************************************************************************
** �ļ���:     yx_exuart_man.c
** ��Ȩ����:   (c) 2017 ������Ѹ����ɷ����޹�˾
** �ļ�����:    ������չ����Ӧ�ò����ӿ�
** �����ˣ�        л��ɣ�2017.7.13
********************************************************************************
*/
#include "yx_includes.h"
#include "yx_exuart_man.h"
#include "yx_com_man.h"
#include "yx_com_send.h"
#include "port_uart.h"
#include "port_gpio.h"

/******************************************************************************/
/*                           ��ʱ������                                       */
/******************************************************************************/
#define  DELAY_TICKS          1
#define  PERIOD_SCAN          MILTICK, 1
#define  PERIOD_DELAY         MILTICK, DELAY_TICKS

/******************************************************************************/
/*                           �������ݻ�������                                 */
/******************************************************************************/
#define  SIZE_RECVBUF_PHY1    (1200 * 1)                       /* ���ջ����С*/
#if EN_DEBUG > 0
#define  SIZE_SENDBUF_PHY1    (1000 * 2)                       /* ���ͻ����С(����������չ����ʱ���Դ��ڻᱻ�������á���������ʱ���û�����Ϊ2400�������ӡ��ȫ����) */
#else
#define  SIZE_SENDBUF_PHY1    (1200 * 1)                       /* ���ͻ����С*/
#endif
#define  SIZE_TRANSBUF_PHY1    256                            /* ͸����������С*/

#define  SIZE_RECVBUF_PHY2    (1200 * 1)                       /* ���ջ����С*/
#define  SIZE_SENDBUF_PHY2    (1200 * 1)                       /* ���ͻ����С*/
#define  SIZE_TRANSBUF_PHY2    256                            /* ͸����������С*/


static INT8U s_phy1_transbuf[SIZE_TRANSBUF_PHY1 + 5];           /* ͸��������(+5��Ϊ�˷�ֹ�洢ʱ����Խ��) */
#if 0
static INT8U s_phy2_transbuf[SIZE_TRANSBUF_PHY2 + 5];           /* ͸��������(+5��Ϊ�˷�ֹ�洢ʱ����Խ��) */
#endif

/******************************************************************************/
/*                           ������չ���ڽ��սṹ��                                                         */
/******************************************************************************/
typedef struct {
   INT16U   rlen_limit;                           /* ���մﵽ����󳤶Ⱥ���ϴ� */
   INT16U   otime_limit;                          /* ��ʱ�ϴ� */
   INT8U*   transbuf;                             /* ָ��洢�ϴ����ݵĴ洢�ռ� */
   INT16U   transbufsize;                         /* �ϴ���������С */
   INT16U   recvlen;                              /* ���յ��ĳ��� */
   INT16U   delaytime;                            /* ��ʱ��ʱ�� */
} EXUSART_RECV_T;

/******************************************************************************/
/*                      ��������������չ���ڷ������ݻ���ṹ��                */
/******************************************************************************/
static EXUSART_RECV_T   s_phy_recv[MAX_EXUART_IDX];

static INT8U      s_scantmrid;
static INT8U      s_delaytmrid;

static INT16U     s_send_index;                  /* ������ˮ�� */
static INT16U     s_rec_index[MAX_EXUART_IDX];                   /* ������ˮ�� */
static BOOLEAN    s_rec_flag[MAX_EXUART_IDX];                    /* ��һ����ˮ��һ����Ҫ���⴦�� */

static BOOLEAN    s_exuartstatus[MAX_EXUART_IDX] = {false, false};
static INT32U     s_com_baudvalue[MAX_EXUART_IDX] = {BAUD_115200, BAUD_9600};


static INT16U const s_sendbuf_size[MAX_EXUART_IDX] = {SIZE_SENDBUF_PHY1, SIZE_SENDBUF_PHY2};
static INT16U const s_recvbuf_size[MAX_EXUART_IDX] = {SIZE_RECVBUF_PHY1, SIZE_RECVBUF_PHY2};

/*******************************************************************************
**  ��������:  ExUartData_Down_Hdl
**  ��������:  ����͸������Э�鴦��
**  �������:
**  ���ز���:
*******************************************************************************/
void ExUartData_Down_Hdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
	INT8U uartno;
    INT16U len;
    INT16U index;
    INT8U  temp[3];


    #if DEBUG_EXUART > 0
    debug_printf("��չ�����������\r\n");
    printf_hex(data, datalen);
    debug_printf("\r\n");
    #endif

    uartno = data[0] - 1;
    if (uartno >= MAX_EXUART_IDX) {
        #if DEBUG_EXUART > 0
        debug_printf("��չ���ںŴ��� %d\r\n", uartno);
        #endif
        return;
    }
	if (s_exuartstatus[uartno] == false) {
        #if DEBUG_EXUART > 0
        debug_printf("��չ����δ��ʼ��\r\n");
        #endif
        return;
	}
    len = data[3] << 8 | data[4];
    index = data[1] << 8 | data[2];

    #if DEBUG_EXUART > 0
    debug_printf("uartno:%d len:%d index:%d  s_rec_index:%d  s_rec_flag:%d\r\n", uartno, len, index, s_rec_index[uartno], s_rec_flag[uartno]);
    #endif
    if (index != s_rec_index[uartno] || (s_rec_flag[uartno] == FALSE)) {
        if (len > s_sendbuf_size[uartno]) {
            len = s_sendbuf_size[uartno];
        }
        PORT_UartWriteBlock(s_exuart_idx[uartno], data + 5, len);
        #if DEBUG_EXUART > 0
        debug_printf("PORT_UartWriteBlock  len:%d  data: ", len);
        printf_hex(data + 5, len);
        debug_printf("\r\n");
        #endif

        s_rec_flag[uartno] = TRUE;
        s_rec_index[uartno] = index;
    }

    memcpy(temp, data, 3);
    YX_COM_DirSend( DATA_DELIVER_DOWN_ACK, temp, 3);
}

/*******************************************************************************
**  ��������:  DataDeliver_ReqAck_Hdl
**  ��������:  ����͸������Ӧ����
**  �������:
**  ���ز���:
*******************************************************************************/
void ExUartData_ReqAck_Hdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    mancode = mancode;
    command = command;
    datalen = datalen;
}
/*******************************************************************************
**  ��������:  EXTDelayTmrProc
**  ��������:  ��ʱ��ʱ����ں�����һ����ʱ�����ϱ�
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
*******************************************************************************/
static void ExtDelayTmrProc(void *pdata)
{
    INT8U i;

    for (i = EXUART_IDX1; i < MAX_EXUART_IDX; i++) {
    	if (s_exuartstatus[i] == false) {
            return;
    	}

        if (s_phy_recv[i].recvlen > 0) {
            s_phy_recv[i].delaytime += (DELAY_TICKS * 10);
            if (s_phy_recv[i].delaytime >= s_phy_recv[i].otime_limit) {
                s_phy_recv[i].transbuf[0] = i + 1;   /* ���ں� */
			    s_phy_recv[i].transbuf[1] = s_send_index >> 8;
			    s_phy_recv[i].transbuf[2] = s_send_index;
			    s_phy_recv[i].transbuf[3] = s_phy_recv[i].recvlen >> 8;
			    s_phy_recv[i].transbuf[4] = s_phy_recv[i].recvlen;
				if (YX_COM_Islink()) {
					YX_COM_DirSend( DATA_DELIVER_REQ, s_phy_recv[i].transbuf, s_phy_recv[i].recvlen + 5);
				}
				s_send_index++;
                s_phy_recv[i].recvlen = 0;
                s_phy_recv[i].delaytime = 0;
            }
        }
    }
}
/*******************************************************************************
**  ��������:  EXTScanTmrProc
**  ��������:  ��ʱɨ����չ���ڻ�����
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
*******************************************************************************/
static void ExtScanTmrProc(void *pdata)
{
	INT8U i;
    INT32S  curchar;

    for (i = EXUART_IDX1; i < MAX_EXUART_IDX; i++) {
    	if (s_exuartstatus[i] == false) {
            return;
    	}

        while ((curchar = PORT_UartRead(s_exuart_idx[i])) != -1) {
            #if DEBUG_EXUART > 1
            PORT_UartWriteByte(DEBUG_UART_NO, curchar);
            #endif
        	s_phy_recv[i].transbuf[s_phy_recv[i].recvlen + 5] = (INT8U)curchar;
            if (++s_phy_recv[i].recvlen >= s_phy_recv[i].transbufsize) {
                s_phy_recv[i].transbuf[0] = i + 1;   /* ���ں� */
			    s_phy_recv[i].transbuf[1] = s_send_index >> 8;
			    s_phy_recv[i].transbuf[2] = s_send_index;
			    s_phy_recv[i].transbuf[3] = s_phy_recv[i].recvlen >> 8;
			    s_phy_recv[i].transbuf[4] = s_phy_recv[i].recvlen;
				if (YX_COM_Islink()) {
					YX_COM_DirSend( DATA_DELIVER_REQ, s_phy_recv[i].transbuf, s_phy_recv[i].recvlen + 5);
				}
				s_send_index++;
                s_phy_recv[i].recvlen = 0;
                s_phy_recv[i].delaytime = 0;
            }
        }

        if (s_phy_recv[i].recvlen >= s_phy_recv[i].rlen_limit + 3) {
            s_phy_recv[i].transbuf[0] = i + 1;   /* ���ں� */
		    s_phy_recv[i].transbuf[1] = s_send_index >> 8;
		    s_phy_recv[i].transbuf[2] = s_send_index;
		    s_phy_recv[i].transbuf[3] = s_phy_recv[i].recvlen >> 8;
		    s_phy_recv[i].transbuf[4] = s_phy_recv[i].recvlen;
			if (YX_COM_Islink()) {
				YX_COM_DirSend( DATA_DELIVER_REQ, s_phy_recv[i].transbuf, s_phy_recv[i].recvlen + 5);
			}
			s_send_index++;
            s_phy_recv[i].recvlen = 0;
            s_phy_recv[i].delaytime = 0;
        }
    }
}

/*******************************************************************************
 ** ������:    YX_ExUart_Init
 ** ��������:  ��չ���ڳ�ʼ��
 ** ����:       ��
 ** ����:       ��
 ******************************************************************************/
void YX_ExUart_Init(void)
{
    /* ��չ����1 */
    s_phy_recv[EXUART_IDX1].rlen_limit  = 128;                  /* ����64�ֽھ��ϴ� */
    s_phy_recv[EXUART_IDX1].otime_limit = 100;                 /* ����100ms��������������Ҳ�ϴ� */
    s_phy_recv[EXUART_IDX1].transbuf = s_phy1_transbuf;
    s_phy_recv[EXUART_IDX1].transbufsize = SIZE_TRANSBUF_PHY1;
    s_phy_recv[EXUART_IDX1].recvlen = 0;
    s_phy_recv[EXUART_IDX1].delaytime = 0;
    PORT_CloseUart(s_exuart_idx[EXUART_IDX1]);
    PORT_InitUart(s_exuart_idx[EXUART_IDX1], s_com_baudvalue[EXUART_IDX1], s_recvbuf_size[EXUART_IDX1], s_sendbuf_size[EXUART_IDX1]);
    s_exuartstatus[EXUART_IDX1] = true;
    s_rec_flag[EXUART_IDX1] = false;

    #if 0
    /* ��չ����2 */
    s_phy_recv[EXUART_IDX2].rlen_limit  = 128;                  /* ����64�ֽھ��ϴ� */
    s_phy_recv[EXUART_IDX2].otime_limit = 100;                 /* ����100ms��������������Ҳ�ϴ� */
    s_phy_recv[EXUART_IDX2].transbuf = s_phy2_transbuf;
    s_phy_recv[EXUART_IDX2].transbufsize = SIZE_TRANSBUF_PHY2;
    s_phy_recv[EXUART_IDX2].recvlen = 0;
    s_phy_recv[EXUART_IDX2].delaytime = 0;
    PORT_CloseUart(s_exuart_idx[EXUART_IDX2]);
    PORT_InitUart(s_exuart_idx[EXUART_IDX2], s_com_baudvalue[EXUART_IDX2], s_recvbuf_size[EXUART_IDX2], s_sendbuf_size[EXUART_IDX2]);
    s_exuartstatus[EXUART_IDX2] = true;
    s_rec_flag[EXUART_IDX2] = false;
    #endif
	
	s_send_index = 0;
    s_scantmrid  = OS_InstallTmr(TSK_ID_OPT, 0, ExtScanTmrProc);
    s_delaytmrid = OS_InstallTmr(TSK_ID_OPT, 0, ExtDelayTmrProc);

    OS_StartTmr(s_scantmrid, PERIOD_SCAN);
    OS_StartTmr(s_delaytmrid, PERIOD_DELAY);
}


/**************************************************************************************************
**  ��������:  EXUartParaSetReqHdl
**  ��������:  �������ڲ�����������������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void EXUsartParaSetReqHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U ack[2];
    INT8U uartno;

    ack[0] = data[0];

    uartno = data[0] - 1;
    if (uartno >= MAX_EXUART_IDX) {
        ack[1] = 0x02;
        YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
        return;
    }

    /* ������ */
    switch (data[1]) {
        case 0x01:
            s_com_baudvalue[uartno] = BAUD_1200;
            break;
        case 0x02:
            s_com_baudvalue[uartno] = BAUD_2400;
            break;
        case 0x03:
            s_com_baudvalue[uartno] = BAUD_4800;
            break;
        case 0x04:
            s_com_baudvalue[uartno] = BAUD_9600;
            break;
        case 0x05:
            s_com_baudvalue[uartno] = BAUD_19200;
            break;
        case 0x06:
            s_com_baudvalue[uartno] = BAUD_38400;
            break;
        case 0x07:
            s_com_baudvalue[uartno] = BAUD_57600;
            break;
        case 0x08:
           s_com_baudvalue[uartno] = BAUD_115200;
            break;
        default:
            ack[1] = 0x02;
            YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
            return;
    }
    /* ����λ */
    switch (data[2]) {
        case 0x04:
           // s_phy_para[channel].databits = DATABITS_8;
            break;
        //case 0x05:
            //s_phy_para[channel].databits = DATABITS_9;
          //  break;
        default:
            ack[1] = 0x02;
            YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
            return;
    }
    /* ֹͣλ */
    switch (data[3]) {
        case 0x01:
            //s_phy_para[channel].stopbits = STOPBITS_1;
            break;
      //  case 0x03:
            //s_phy_para[channel].stopbits = STOPBITS_2;
           // break;
        default:
            ack[1] = 0x02;
            YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
            return;
    }
    /* У�鷽ʽ */
    switch (data[4]) {
        case 0x01:
            break;
        default:
            ack[1] = 0x02;
            YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
            return;
    }

    PORT_CloseUart(s_exuart_idx[uartno]);
    PORT_InitUart(s_exuart_idx[uartno], s_com_baudvalue[uartno], s_recvbuf_size[uartno], s_sendbuf_size[uartno]);

    ack[1] = 0x01;
    YX_COM_DirSend( PHYCOM_PARA_CONFIG_REQ_ACK, ack, 2);
}

/**************************************************************************************************
**  ��������:  EXUartParaQueryHdl
**  ��������:  �������ڲ�����ѯ��������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void EXUsartParaQueryHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U  ack[6];
    INT8U  uartno;

    uartno = data[0] - 1;
    ack[0] = data[0];

    if (uartno >= MAX_EXUART_IDX) {
        ack[1] = 0x02;
        YX_COM_DirSend( PHYCOM_PARA_QUERY_ACK, ack, 2);
        return;
    }

    ack[1] = 0x01;
    switch (s_com_baudvalue[uartno]) {
        case BAUD_1200:
            ack[2] = 0x01;
            break;
        case BAUD_2400:
            ack[2] = 0x02;
            break;
        case BAUD_4800:
            ack[2] = 0x03;
            break;
        case BAUD_9600:
            ack[2] = 0x04;
            break;
        case BAUD_19200:
            ack[2] = 0x05;
            break;
        case BAUD_38400:
            ack[2] = 0x06;
            break;
        case BAUD_57600:
            ack[2] = 0x07;
            break;
        case BAUD_115200:
            ack[2] = 0x08;
            break;
        default:
            break;
    }
    /* ����λ */
    ack[3] = 0x04;
    ack[4] = 0x01;
    ack[5] = 0x01;
    #if 0
    switch (s_phy_para[channel].databits) {
        case DATABITS_8:
            ack[3] = 0x04;
            break;
        case DATABITS_9:
            ack[3] = 0x05;
            break;
        default:
            break;
    }

    /* ֹͣλ */
    switch (s_phy_para[channel].stopbits) {
        case STOPBITS_1:
            ack[4] = 0x01;
            break;
        case STOPBITS_2:
            ack[4] = 0x03;
            break;
        default:
            break;
    }
    /* У�鷽ʽ */
    switch (s_phy_para[channel].parity) {
        case PARITY_NONE:
            ack[5] = 0x01;
            break;
        case PARITY_EVEN:
            ack[5] = 0x02;
            if (s_phy_para[channel].databits == DATABITS_9) {
                ack[3] = 0x04;
            }
            break;
        case PARITY_ODD:
            ack[5] = 0x03;
            if (s_phy_para[channel].databits == DATABITS_9) {
                ack[3] = 0x04;
            }
            break;
        default:
            break;
    }
    #endif
    YX_COM_DirSend( PHYCOM_PARA_QUERY_ACK, ack, 6);
}

/**************************************************************************************************
**  ��������:  EXUartPowerCtrlHdl
**  ��������:  �������ڵ�Դ���ƴ�������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void EXUsartPowerCtrlHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U  ack[3];
    INT8U  uartno;

    ack[0] = data[0];
    ack[1] = data[1];
    uartno = data[0] - 1;

    if (uartno >= MAX_EXUART_IDX){
        ack[2] = 0x02;
        YX_COM_DirSend( PHYCOM_POWER_CONTROL_REQ_ACK, ack, 2);
        return;
    }

    switch (uartno) {
        case EXUART_IDX1:
            if (0x01 == data[1]) {
            } else if (0x02 == data[1]) {
            } else {
                ack[2] = 0x02;
                YX_COM_DirSend( PHYCOM_POWER_CONTROL_REQ_ACK, ack, 3);
                return;
            }
            break;
        case EXUART_IDX2:
            if (0x01 == data[1]) {
                PORT_ClearGpioPin(PIN_GPSPWR);
            } else if (0x02 == data[1]) {
                PORT_SetGpioPin(PIN_GPSPWR);
            } else {
                ack[2] = 0x02;
                YX_COM_DirSend( PHYCOM_POWER_CONTROL_REQ_ACK, ack, 3);
                return;
            }
            break;
        default:
            break;
    }

    #if 0
    if (0x01 == data[1]) {
        PORT_CloseUart(s_exuart_idx[uartno]);
        PORT_InitUart(s_exuart_idx[uartno], s_com_baudvalue[uartno], s_recvbuf_size[uartno], s_sendbuf_size[uartno]);
    } else if (0x02 == data[1]) {
        PORT_CloseUart(s_exuart_idx[uartno]);
    } else {
        ack[2] = 0x02;
        YX_COM_DirSend( PHYCOM_POWER_CONTROL_REQ_ACK, ack, 3);
        return;
    }
    #endif

    ack[2] = 0x01;
    YX_COM_DirSend( PHYCOM_POWER_CONTROL_REQ_ACK, ack, 3);
}



