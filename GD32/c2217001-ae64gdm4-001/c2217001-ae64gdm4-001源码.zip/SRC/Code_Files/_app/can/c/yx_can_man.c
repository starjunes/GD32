/*
********************************************************************************
** �ļ���:     yx_can_man.c
** ��Ȩ����:   (c) 2017 ������Ѹ����ɷ����޹�˾
** �ļ�����:   canҵ���߼���Э�鴦��
** �����ˣ�        л��ɣ�2017.5.18
********************************************************************************
*/
#include "yx_includes.h"
#include "yx_can_man.h"
#include "yx_com_send.h"
#include "yx_com_recv.h"
#include "yx_protocal_hdl.h"
#include "yx_debugcfg.h"
#include "port_gpio.h"
#include "yx_lock.h"
#include "appmain.h"
#include "Dal_Structs.h"


#define UDS_ID_REC              0x18DA1DF9
#define UDS_ID_SEND             0x18DAF91D

#define UDS_ID_REC1             0x18DA1D00
#define UDS_ID_SEND1            0x18DA001D

#define UDS_ID_REC2             0x18DA1CF9                /* ���������CAN ID */
#define UDS_ID_SEND2            0x18DAF91C                /* �ն���ӦCAN ID */

#define UDS_ID_REC3             0x7E8
#define UDS_ID_SEND3            0x7E0

#define UDS_ID_REC4             0x18EA1DFF
#define UDS_ID_SEND4            0x18EAFF1D

#define UDS_ID_REC5             0x18EA1700
#define UDS_ID_SEND5            0x18EA0017

#define UDS_ID_REC6             0x18DAF100
#define UDS_ID_SEND6            0x18DA00F1


#define UDS_ID_FUNC             0x18DB33F1   /* ���ܵ�ַ  */


#define NONE_TYPE   0
#define UDS_TYPE    1
#define J1939_TYPE  2
static CAN_PARA_T s_can_para[MAX_CAN_CHN];
static AAPCAN_MSG_T  s_msgbt[MAX_CAN_CHN];                    /* ���յ�CAN id�� */
#define MAXPACKETPARANUM         10                            /* ���������໺����� */
#define PACKETOVERTMR            500                            /* ��ʱ�������ֵ */
static PACKET_PARA_T s_packetpara[MAXPACKETPARANUM] ;
static MULTIPACKET_SEND_T s_sendpacket[MAXPACKETPARANUM];
static INT8U  s_packet_tmr;
static INT8U  s_packet_cnt;                                    /* ���������ۼ���ˮ�� */
static INT8U  s_oilsum_check = 0;                             /* 1��ʾ����������0��ʾ�������� */

static INT32U s_last_packetid;                                 /* ���µ�֡id */
static INT8U s_canRxMsg = 0;                             /* can���Ľ��ձ�־ */
static INT16U  s_canMsgLossTmr;                                /* ������Ľ��ձ�־������ */

typedef struct {
    INT32U id;
    INT8U  data[8];
    INT8U  dlc;
    INT8U  can_ch;
    INT8U  resend_num;
    INT8U  time_cnt;
    INT8U  period;
    BOOLEAN is_start;
} RESENT_CAN_T;
#define MAX_RESEND_NUM    2
static RESENT_CAN_T s_resend_can[MAX_RESEND_NUM];

/*****************************************************************************
**  ������:  StartCanResend
**  ��������: �����ط�
**  ����:    [in] chn  : canͨ��
**           [in] id   : can id
**           [in] data : can����
**           [in] dlc  : can����
**  ����:    ��
*****************************************************************************/
static void StartCanResend(INT8U chn, INT32U id, INT8U* data, INT8U dlc)
{    
    INT8U idx;
    for (idx = 0; idx < MAX_RESEND_NUM; idx++) {
        if (s_resend_can[idx].is_start == FALSE) {
            break;
        }
    }
    
    if (idx == MAX_RESEND_NUM) return;
    
    s_resend_can[idx].id = id;
    s_resend_can[idx].dlc = dlc;
    memcpy(s_resend_can[idx].data, data, dlc);
    s_resend_can[idx].can_ch = chn;
    s_resend_can[idx].resend_num = 0;
    s_resend_can[idx].time_cnt = 0;
    s_resend_can[idx].period = 3;    /* 30ms */
    s_resend_can[idx].is_start = TRUE;
}

/*****************************************************************************
**  ������:  CanResendHdl
**  ��������: �ط�
**  ����:    ��
**  ����:    ��
*****************************************************************************/
static void CanResendHdl(void)
{      
    INT8U idx;
    CAN_DATA_SEND_T candata;
    for (idx = 0; idx < MAX_RESEND_NUM; idx++) {
        if (s_resend_can[idx].is_start) {
            if (++s_resend_can[idx].time_cnt >= s_resend_can[idx].period) {
                s_resend_can[idx].time_cnt = 0;
                if (++s_resend_can[idx].resend_num >= 2) {
                    s_resend_can[idx].resend_num = 0;
                    s_resend_can[idx].is_start = FALSE;
            }
			
            memset(&candata, 0x00, sizeof(candata));
                candata.can_DLC = s_resend_can[idx].dlc;
                candata.can_id = s_resend_can[idx].id;
            if(candata.can_id <= 0x7ff){
                candata.can_IDE = 0;  /*��׼֡*/
            } else {
                candata.can_IDE = 1;
            }
            
            candata.channel = s_resend_can[idx].can_ch;
        	candata.period = 0xffff;
            memcpy(candata.Data, s_resend_can[idx].data, candata.can_DLC);
            PORT_CanSend(&candata);
        }
    }
}
}

/*******************************************************************************
**  ��������:  CheckCanID
**  ��������:  ȷ��ID�Ƿ���Ч
**  �������:  GPN: ����GPN TRUE:��ʾΪGPN FALSE:ʵ����ID
               ID : �����CAN ID
               chanl: CAN ͨ����  0:ͨ��1; 1:ͨ��2
**  ���ز���:  ID: Ϊ0ʱ��ʾδ�ҵ�
*******************************************************************************/
static INT32U  CheckCanID(INT32U id,INT8U chanl)
{
    INT8U i;
    INT32U retid = 0;

    for (i = 0; i < MAX_CANIDS; i++) {
        if ((TRUE == s_msgbt[chanl].idcbt[i].isused)
            && ((id == s_msgbt[chanl].idcbt[i].id)
                || ((id & s_msgbt[chanl].idcbt[i].screeid) == (s_msgbt[chanl].idcbt[i].id & s_msgbt[chanl].idcbt[i].screeid))) ) {
            retid = id;
            break;
        }
    }
    return retid;
}

/**************************************************************************************************
**  ��������:  CAN_TxData
**  ��������:  CAN�������ݽӿں���
**  �������:  *data ָ����������ָ�� ���� ID len ����
**  ���ز���:  None
**************************************************************************************************/
BOOLEAN CAN_TxData(INT8U *data, BOOLEAN wait, INT8U channel)
{
    CAN_DATA_SEND_T candata;
    INT32U id;

    memset(&candata, 0x00, sizeof(candata));
    id = bal_chartolong(data);
    candata.can_DLC = data[4];
    candata.can_id = id;
    if(id <= 0x7ff){
        candata.can_IDE = 0;  /*��׼֡*/
    } else {
        candata.can_IDE = 1;
    }

    candata.channel = channel;
    candata.period = 0xffff;
    memcpy(candata.Data, &data[5], candata.can_DLC);
    return PORT_CanSend(&candata);
}
/**************************************************************************************************
**  ��������:  SetCANMsg_Period
**  ��������:  ���������Է���CAN����
**  �������:
**  ���ز���:
**************************************************************************************************/
BOOLEAN SetCANMsg_Period(INT32U id, INT8U *ptr, INT16U period, INT8U channel)
{
    CAN_DATA_SEND_T candata;

    memset(&candata, 0x00, sizeof(candata));
    candata.can_DLC = ptr[0];
    candata.can_id = id;
    candata.can_IDE = 1;
    candata.channel = channel;
    candata.period = period;
    memcpy(candata.Data, &ptr[1], candata.can_DLC);

    return PORT_CanSend(&candata);

}

/**************************************************************************************************
**  ��������:  StopCANMsg_Period
**  ��������:  ֹͣ���ڷ���
**  �������:
**  ���ز���:
**************************************************************************************************/
BOOLEAN StopCANMsg_Period(INT32U id, INT8U channel)
{
    CAN_DATA_SEND_T candata;


    memset(&candata, 0x00, sizeof(candata));
    candata.can_DLC = 8;
    candata.can_id = id;
    candata.can_IDE = 1;
    candata.channel = channel;
    candata.period = 0;

    return PORT_CanSend(&candata);

}

/**************************************************************************************************
**  ��������:  FindFreeItem_SendList
**  ��������:  ���ҿ��õķ�����
**  �������:  None
**  ���ز���:  MAXPACKETPARANUM��ʾδ�ҵ�
**************************************************************************************************/
static INT8U FindFreeItem_SendList(void)
{
    INT8U i;

    for (i = 0;i < MAXPACKETPARANUM; i++) {
        if (s_sendpacket[i].packet_com == FALSE) {
            break;
        }
    }
    return i;
}

/**************************************************************************************************
**  ��������:  Find_J1939Sending
**  ��������:  �����Ƿ���J1939��֡�ڷ���
**  �������:  None
**  ���ز���:  TRUE��ʾ�ҵ�
**************************************************************************************************/
static BOOLEAN Find_J1939Sending(void)
{
    INT8U i;

    for (i = 0;i < MAXPACKETPARANUM; i++) {
        if ((s_sendpacket[i].prot_type == J1939_TYPE) && (TRUE == s_sendpacket[i].sendcontinue)) {
            return TRUE;
        }
    }
    return FALSE;
}

/**************************************************************************************************
**  ��������:  SendJ1939FirPacket
**  ��������:  CAN���Ͷ�֡�еĵ�һ֡
**  �������:  MULTIPACKET_SEND_T
**  ���ز���:  None
**************************************************************************************************/
static void SendJ1939FirPacket(MULTIPACKET_SEND_T *sendpacket)
{
    INT8U data[13] = {0x00,0x00,0x00,0x00,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
    bal_longtochar(data, ((sendpacket->sendid & 0xFF0000FF) | 0xECFF00));
    data[5] = 0x20;//BAM���ͱ���
    data[6] = sendpacket->packet_totallen;//LSB message size
    data[7] = 0x00;//MSB message size
    data[8] = (sendpacket->packet_totallen+6)/7;//total number of packet
    data[9] = 0xFF;//reserved
    data[10] = (INT8U)((sendpacket->sendid & 0x0000FF00) >>  8);//PGN
    data[11] = (INT8U)((sendpacket->sendid & 0x00FF0000) >> 16);//PGN
    data[12] = 0x00;
    CAN_TxData(data, FALSE, sendpacket->channel);

    sendpacket->sendcontinue = TRUE;//�������ڷ�������
    sendpacket->periods = 8;       //80ms
    sendpacket->tmrcnt = 0;         //��ʱ��,���������ڵĻ��Ϳ�ʼ����
    sendpacket->packet_tmrcnt = 0;  //��;:��ʱ���Ͳ��ɹ���ɾ������֡
    sendpacket->cf_cnt = 0;          //����Ҫ�õ����С
    sendpacket->sendpacket = 1;     //����ȥ���͵�01����֡
    sendpacket->sendlen = 0;        //�ѷ�������Ϊ0

}

/**************************************************************************************************
**  ��������:  SendJ1939ContinuePacket
**  ��������:  CAN�����м�֡
**  �������:  MULTIPACKET_SEND_T
**  ���ز���:  None
**************************************************************************************************/
static void SendJ1939ContinuePacket(MULTIPACKET_SEND_T *sendpacket)
{
    INT8U len;
    INT8U data[13] = {0x00,0x00,0x00,0x00,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
    bal_longtochar(data, ((sendpacket->sendid & 0xFF0000FF) | 0xEBFF00));
    data[5] = sendpacket->sendpacket;   //���
    len = sendpacket->packet_totallen - sendpacket->sendlen;
    if (len > 7){
        memcpy(&data[6],&sendpacket->packet_buf[sendpacket->sendlen],7);
        sendpacket->sendlen = sendpacket->sendlen + 7;
        sendpacket->periods = 8;       //80ms
        sendpacket->tmrcnt = 0;         //��ʱ��,���������ڵĻ��Ϳ�ʼ����
        sendpacket->packet_tmrcnt = 0;  //��;:��ʱ���Ͳ��ɹ���ɾ������֡
        sendpacket->sendpacket++;       //����ȥ���͵�01����֡
    }else{
        memcpy(&data[6],&sendpacket->packet_buf[sendpacket->sendlen],len);
        sendpacket->sendcontinue = FALSE;//�������ͽ���
        sendpacket->packet_com = FALSE;
        sendpacket->prot_type = NONE_TYPE;
        PORT_Free(sendpacket->packet_buf);
    }
    CAN_TxData(data, FALSE, sendpacket->channel);
}

/**************************************************************************************************
**  ��������:  SendCF
**  ��������:  CAN���Ͷ�֡�е�����֡
**  �������:
**  ���ز���:  None
**************************************************************************************************/
void SendCF(void)
{
    INT8U i,j;
    //INT8U data[13] = {0x00,0x00,0x00,0x00,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
    INT8U data[13] = {0x00,0x00,0x00,0x00,0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   // CAN_TxData(data, FALSE, 0);
    for (i = 0; i < MAXPACKETPARANUM; i++) {
        if(UDS_TYPE == s_sendpacket[i].prot_type){
            if ((s_sendpacket[i].packet_com) && (s_sendpacket[i].sendcontinue)) {
                if (s_sendpacket[i].tmrcnt++ >= s_sendpacket[i].periods) {
                    if (s_sendpacket[i].blocksize > 0) {
                        if (s_sendpacket[i].cf_cnt > 0) {
                            s_sendpacket[i].cf_cnt--;
                            if (s_sendpacket[i].cf_cnt == 0) {
                                s_sendpacket[i].sendcontinue = FALSE;       /* �ﵽ���С ֹͣ�´η���  */
                                #if DEBUG_CAN > 0
                                debug_printf("��ֹͣ�´�CF����,%d->0\r\n",  s_sendpacket[i].blocksize);
                                #endif
                            }
                        }
                    }

                    s_sendpacket[i].tmrcnt = 0;
                    #if DEBUG_CAN > 0
                    debug_printf("completelength,%d\r\n",s_sendpacket[i].sendlen);
                    #endif
                    bal_longtochar(data, s_sendpacket[i].sendid);
                    data[5] = 0x20 + s_sendpacket[i].sendpacket;
                    if ((s_sendpacket[i].packet_totallen - s_sendpacket[i].sendlen) > 7) {
                        #if DEBUG_CAN > 0
                        debug_printf("��������֡,%d,%x\r\n",i, data[5]);
                        #endif
                        for (j = 0; j < 7 ; j++) {
                            data[6 + j] = s_sendpacket[i].packet_buf[s_sendpacket[i].sendlen + j];
                        }
                        CAN_TxData(data, FALSE, s_sendpacket[i].channel);
                        s_sendpacket[i].sendlen += 7;
                        s_sendpacket[i].sendpacket++;
                        s_sendpacket[i].packet_tmrcnt = 0;
                        if (s_sendpacket[i].sendpacket == 16) {
                            s_sendpacket[i].sendpacket = 0;
                        }
                    } else {
                        #if DEBUG_CAN > 0
                        debug_printf("�������֡,%d,%x\r\n",i, data[5]);
                        #endif
                        for (j = 0; j < (s_sendpacket[i].packet_totallen - s_sendpacket[i].sendlen) ; j++) {

                            data[6 + j] = s_sendpacket[i].packet_buf[s_sendpacket[i].sendlen + j];
                        }
                        CAN_TxData(data, FALSE, s_sendpacket[i].channel);
                        s_sendpacket[i].packet_com = FALSE;
                        s_sendpacket[i].sendcontinue = FALSE;
                        if (s_sendpacket[i].packet_buf != NULL) {
                            PORT_Free(s_sendpacket[i].packet_buf);
                            s_sendpacket[i].packet_buf = NULL;
                        }
                        s_sendpacket[i].packet_tmrcnt = 0;
                    }
                }
            }
        }else if((J1939_TYPE == s_sendpacket[i].prot_type) && (s_sendpacket[i].packet_com)){
            if(s_sendpacket[i].sendcontinue){   //�Ѿ��ڷ�������
                 if (s_sendpacket[i].tmrcnt++ >= s_sendpacket[i].periods) {
                    SendJ1939ContinuePacket(&s_sendpacket[i]);
                 }
            }else{                              //��Ҫ���͵�һ֡
                if(FALSE == Find_J1939Sending())//û��J1939�ĳ�֡�ڷ���,�ŷ�����һ��֡
                {
                    SendJ1939FirPacket(&s_sendpacket[i]);
                }
            }
        }
    }
}

/**************************************************************************************************
**  ��������:  SendFirstPacket
**  ��������:  CAN���Ͷ�֡�еĵ�һ֡
**  �������:  MULTIPACKET_SEND_T
**  ���ز���:  None
**************************************************************************************************/
static void SendFF(MULTIPACKET_SEND_T *sendpacket)
{
    INT8U data[13] = {0x00,0x00,0x00,0x00,0x08,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
    INT8U i, highbyte;
    INT32U dw_tmp;

    if (sendpacket->sendid < 0xFFF) {
        sendpacket->recvid = sendpacket->sendid + 8;
    } else {
        dw_tmp  = (sendpacket->sendid & 0xFFFF0000);
        dw_tmp |= ((sendpacket->sendid & 0x0000FF00) >> 8);
        dw_tmp |= ((sendpacket->sendid & 0x000000FF) << 8);
        sendpacket->recvid = dw_tmp;
    }
    bal_longtochar(data, sendpacket->sendid);

    highbyte = (sendpacket->packet_totallen & 0x0F00) >> 8;
    data[5] = 0x10 | highbyte;
    data[6] = sendpacket->packet_totallen;
    for (i = 0; i < 6; i++) {
        data[7 + i] = sendpacket->packet_buf[i];
    }
    sendpacket->sendlen = 6;
    if (FALSE == CAN_TxData(data, FALSE, sendpacket->channel)) {
        #if DEBUG_CAN > 0
        debug_printf("���͵�һ֡ʧ��\r\n");
        #endif
    }
    sendpacket->sendpacket++;
    sendpacket->packet_tmrcnt = 0;
    #if DEBUG_CAN > 0
    debug_printf("��֡��һ֡,%d, %x, %x\r\n",sendpacket->channel, sendpacket->sendid, sendpacket->recvid);
    #endif
}
/**************************************************************************************************
**  ��������:  J1939_CANMsgAnalyze
**  ��������:  J1939 CAN���Ľ�����������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
static BOOLEAN  J1939_CANMsgAnalyze(INT8U *data, INT16U datalen)
{
    CAN_DATA_HANDLE_T* CAN_msg;
    INT32U id;
    INT32U packet_id;
    INT8U  i = 0;

    CAN_msg =  (CAN_DATA_HANDLE_T*)data;

    id      =  bal_chartolong(CAN_msg->id);

    if ((id & 0x00ffff00) == 0x00ecff00) {
        packet_id = (id & 0xff000000) | (CAN_msg->databuf[6] << 16) | (CAN_msg->databuf[5] << 8) | (id & 0x000000ff);

        for (i = 0; i < MAXPACKETPARANUM; i++) {
            /* �ѱ���id��δ�����꣬������������ */
            if ((s_packetpara[i].packet_id == packet_id) && (s_packetpara[i].packet_com == TRUE)) {
                s_last_packetid = packet_id;
                #if DEBUG_J1939 > 0
                debug_printf("EC �ѱ���id��δ�����꣬������������ \r\n");
                #endif
                return TRUE;
            }
        }

        for (i = 0; i < MAXPACKETPARANUM; i++) {
            if (s_packetpara[i].packet_com == FALSE) {
                #if DEBUG_J1939 > 0
                debug_printf("1939λ�� i:%d\r\n", i);
                #endif
                break;
            }
        }

        if (i == MAXPACKETPARANUM) {
            #if DEBUG_J1939 > 0
            debug_printf("EC ��֡��������\r\n");
            #endif
            return FALSE;
        }

        if ((CAN_msg->databuf[0] == 0x20) && (CheckCanID(packet_id, CAN_msg->channel))) {
            s_packetpara[i].packet_com       = TRUE;
            s_packetpara[i].packet_totallen  = (CAN_msg->databuf[2] << 8) + CAN_msg->databuf[1];
            if (s_packetpara[i].packet_totallen > (0xfc)) {
                s_packetpara[i].packet_totallen = 0xfc; //7�ı���
            }
            s_packetpara[i].packet_buf = PORT_Malloc(CAN_msg->databuf[3] * 7 + 11);
            if (s_packetpara[i].packet_buf == NULL) {
                s_packetpara[i].packet_com = FALSE;
            } else {
                s_last_packetid = packet_id;
                s_packetpara[i].packet_id = packet_id;
                s_packetpara[i].packet_index = 0;
                s_packetpara[i].packet_total = CAN_msg->databuf[3];
                s_packetpara[i].packet_tmrcnt  = 0;
            }
        }
        #if DEBUG_J1939 > 0
        debug_printf("EC ��֡�ɹ�����\r\n");
        #endif
        return TRUE;

     } else if ((id & 0x00ffff00) == 0x00ebff00) {
        for (i = 0; i < MAXPACKETPARANUM; i++) {
            if (((s_packetpara[i].packet_id & 0x000000ff) == (id & 0x000000ff)) 
                && (s_packetpara[i].packet_com)) {
                if (s_packetpara[i].packet_id == s_last_packetid) {
                    break;
                }
            }
        }

        if (i == MAXPACKETPARANUM) {
            #if DEBUG_J1939 > 0
            debug_printf("EB ��֡��������\r\n");
            #endif
           return FALSE;
        }

        if ((CAN_msg->databuf[0] <= s_packetpara[i].packet_total) && (CAN_msg->databuf[0] != 0)) {
            if ((CAN_msg->databuf[0] == s_packetpara[i].packet_index) || (CAN_msg->databuf[0] == s_packetpara[i].packet_index + 1)) {
                if (((CAN_msg->databuf[0]) * 7) <= s_packetpara[i].packet_totallen) {
                    memcpy(&s_packetpara[i].packet_buf[(CAN_msg->databuf[0] - 1) * 7 + 11], &CAN_msg->databuf[1], 7);
                } else if (((CAN_msg->databuf[0] - 1) * 7) <= s_packetpara[i].packet_totallen) {   /* ���һ������7���ֽ� */
                    memcpy(&s_packetpara[i].packet_buf[(CAN_msg->databuf[0] - 1) * 7 + 11], &CAN_msg->databuf[1], s_packetpara[i].packet_totallen - (CAN_msg->databuf[0] - 1) * 7);
                }
                s_packetpara[i].packet_index++;
                #if DEBUG_J1939 > 0
                debug_printf("�м��֡\r\n");
                #endif

                if (CAN_msg->databuf[0] == s_packetpara[i].packet_total) {
                    s_packetpara[i].packet_buf[0] = CAN_msg->channel + 1;
                    bal_longtochar(&s_packetpara[i].packet_buf[1], s_packetpara[i].packet_id);
                    s_packetpara[i].packet_buf[5] = 0x01;                           /* һ�� */
                    s_packetpara[i].packet_buf[6] = CAN_msg->format;
                    s_packetpara[i].packet_buf[7] = 0x00;                           /* reserve */
                    s_packetpara[i].packet_buf[8] = s_packet_cnt++;                 /* seq */
                    bal_shorttochar(&s_packetpara[i].packet_buf[9], s_packetpara[i].packet_totallen);/* LEN: 2 BYTE*/

                    YX_COM_DirSend(DATA_REPORT_CAN, s_packetpara[i].packet_buf , s_packetpara[i].packet_totallen + 11);
                    #if DEBUG_J1939 > 0
                    debug_printf("��֡�������\r\n");
                    printf_hex(s_packetpara[i].packet_buf, s_packetpara[i].packet_totallen + 11);
                    debug_printf("\r\n");
                    #endif
                    s_packetpara[i].packet_com = FALSE;
                    s_packetpara[i].packet_tmrcnt = 0;
                    if (s_packetpara[i].packet_buf != NULL) {
                        PORT_Free(s_packetpara[i].packet_buf);
                        s_packetpara[i].packet_buf = NULL;
                    }
                    s_packetpara[i].packet_id = 0x00;
                }

                return TRUE;
            } else {
                if (CAN_msg->databuf[0] == s_packetpara[i].packet_total) {
                    #if DEBUG_J1939 > 0
                    debug_printf("�쳣֡���һ֡, i:%d packet_id:%x total:%d index:%d\r\n", i, s_packetpara[i].packet_id, s_packetpara[i].packet_total, s_packetpara[i].packet_index);
                    #endif
                    s_packetpara[i].packet_com = FALSE;
                    if (s_packetpara[i].packet_buf != NULL ) {
                        PORT_Free(s_packetpara[i].packet_buf);
                        s_packetpara[i].packet_buf = NULL;
                    }
                    s_packetpara[i].packet_id = 0x00;
                }
            }
        }
   }


   #if DEBUG_J1939 > 0
   debug_printf("id:%x error\r\n", id);
   #endif

   return FALSE;
}

/**************************************************************************************************
**  ��������:  UDS_CANMsgAnalyze
**  ��������:  UDS CAN���Ľ�����������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
static BOOLEAN UDS_CANMsgAnalyze(INT8U *data, INT16U datalen)
{
    INT8U data2[13] = {0x00,0x00,0x00,0x01,0x08,0x30,0x00,0x32,0x00,0x00,0x00,0x00,0x00};
    CAN_DATA_SEND_T senddata;
    CAN_DATA_HANDLE_T* CAN_msg;
    INT32U id;
    INT8U  i = 0;
    INT8U  leftlen;
    INT8U  midata;

    CAN_msg = (CAN_DATA_HANDLE_T*)data;

    id = bal_chartolong(CAN_msg->id);

    if ((id == UDS_ID_REC) || (id == UDS_ID_REC1) || (id == UDS_ID_REC2) || (id == UDS_ID_REC3)
     || (id == UDS_ID_REC4) || (id == UDS_ID_REC5) || (id == UDS_ID_REC6)) {//--RF--  �����������ʱ����Ҫ�����ػظ�
        if (CAN_msg->databuf[0] == 0x30) {
            for (i = 0; i < MAXPACKETPARANUM; i++) {
                #if DEBUG_UDS > 0
                debug_printf("����,%d recv%x send%x com%d channel%d\r\n",i,s_sendpacket[i].recvid,s_sendpacket[i].sendid,s_sendpacket[i].packet_com,s_sendpacket[i].channel);
                #endif
                if ((s_sendpacket[i].recvid == id) && (s_sendpacket[i].packet_com)) {
                    break;
                }
            }
            #if DEBUG_UDS > 0
            debug_printf("�յ�����֡,%d\r\n",i);
            #endif

            if (i == MAXPACKETPARANUM) {
                return FALSE;
            }

            s_sendpacket[i].blocksize = CAN_msg->databuf[1];
            s_sendpacket[i].cf_cnt = s_sendpacket[i].blocksize;

            if ((CAN_msg->databuf[2]) <= 0x7f) {
                s_sendpacket[i].periods = CAN_msg->databuf[2]/10;
            } else {
                s_sendpacket[i].periods = 1;
            }
            s_sendpacket[i].tmrcnt = 0;
            s_sendpacket[i].packet_tmrcnt = 0;
            s_sendpacket[i].sendcontinue = TRUE;

            #if DEBUG_UDS > 0
            debug_printf("���ݳ���%d,�ѷ�����%d,seq:%x,bs:%d,period:%dms",s_sendpacket[i].packet_totallen,s_sendpacket[i].sendlen, s_sendpacket[i].sendpacket, s_sendpacket[i].blocksize, s_sendpacket[i].periods);
            //Debug_PrintHex(true, s_sendpacket[i].packet_buf, s_sendpacket[i].packet_totallen);
            #endif
            return TRUE;
        }else if (CAN_msg->databuf[0] == 0x31) {//wait
            ;//����packet_tmrcnt,���ͳ�ʱ�������֡
        } else if (CAN_msg->databuf[0] == 0x32) {//���
            ;//�ȴ����ͳ�ʱ�������֡
        }
    }
    if ((id == UDS_ID_REC) || (id == UDS_ID_REC1)|| (id == UDS_ID_REC2)|| (id == UDS_ID_REC3)
        || (id == UDS_ID_REC4) || (id == UDS_ID_REC5) || (id == UDS_ID_REC6)) {//--RF--  ������մ���
        #if DEBUG_UDS > 1
        debug_printf("CAN֡ ");
        printf_hex(CAN_msg->databuf, CAN_msg->len);
        debug_printf("\r\n");
        #endif
        if (((CAN_msg->databuf[0]) & 0xf0) == 0x10) {
            #if DEBUG_UDS > 0
            debug_printf("UDS��һ֡1\r\n");
            #endif
            for (i = 0; i < MAXPACKETPARANUM; i++) {
               if(id == s_packetpara[i].packet_id && s_packetpara[i].packet_com == TRUE){/*�޸���ͬid���ǵ���һ��*/
                  s_packetpara[i].packet_com = FALSE;
                  if (s_packetpara[i].packet_buf != NULL ) {
                       PORT_Free(s_packetpara[i].packet_buf);
                       #if DEBUG_UDS > 0
                       debug_printf("���յ���ͬid�� packet_buf �ڴ��ͷ� i:%d id:%x\r\n", i, s_sendpacket[i].sendid);
                       #endif
                       s_packetpara[i].packet_buf = NULL;
                       break;
                  }
               }
               if (s_packetpara[i].packet_com == FALSE) {
                    #if DEBUG_UDS > 0
                    debug_printf("UDSλ�� i:%d\r\n", i);
                    #endif
                    break;
               }
            }
            if (i == MAXPACKETPARANUM) {
                #if DEBUG_UDS > 0
                debug_printf("UDS ��֡��������\r\n");
                #endif
                return FALSE;
            }
            s_packetpara[i].packet_com = TRUE;
            s_packetpara[i].packet_totallen = (((CAN_msg->databuf[0]) & 0x0f) << 8) + CAN_msg->databuf[1] + 1;
            if (s_packetpara[i].packet_totallen < (8 + 1)) { /* ��֡����8���ֽ����� */
		#if DEBUG_UDS > 0
                debug_printf("��֡���ݴ���\r\n");
                #endif
                s_packetpara[i].packet_com = FALSE;
                return false;
            }
            s_packetpara[i].packet_buf = PORT_Malloc(s_packetpara[i].packet_totallen + 11);
            if (s_packetpara[i].packet_buf == NULL) {
                #if DEBUG_UDS > 0
                debug_printf("û�ڴ�\r\n");
                #endif
                s_packetpara[i].packet_com = FALSE;
                return false;
            } else {
                s_packetpara[i].packet_id = id;
                s_packetpara[i].packet_tmrcnt  = 0;
                s_packetpara[i].packet_total  = 0;                                    //�������ڼ����ѽ��ܵ�������֡����
                s_packetpara[i].packet_index = 1;                                     //�����ʾ����ȥ��Ҫ�����
                memcpy(&s_packetpara[i].packet_buf[11], &CAN_msg->databuf[1], 7);
                if (id > 0xFFF) {
                    bal_longtochar(data2, s_packetpara[i].packet_id);
                    midata = data2[2];
                    data2[2] = data2[3];
                    data2[3] = midata;
                } else {
                    bal_longtochar(data2, s_packetpara[i].packet_id - 8);
                }
                #if 1
                senddata.can_id = bal_chartolong(data2);
                if(senddata.can_id <= 0x7ff){
                     senddata.can_IDE = 0;  /*��׼֡*/
                } else {
                     senddata.can_IDE = 1;
                }
                senddata.can_DLC = 8;
                senddata.period = 0xffff;
                senddata.channel = CAN_msg->channel;
                memcpy(senddata.Data, data2 + 5, senddata.can_DLC);
                #endif


                if (FALSE == PORT_CanSend(&senddata)) {              /* ��������֡,ʹ��û50���뷢��һ֡ */
                    s_packetpara[i].packet_com = FALSE;
                    if (s_packetpara[i].packet_buf != NULL ) {
                        PORT_Free(s_packetpara[i].packet_buf);
                        s_packetpara[i].packet_buf = NULL;
                    }
                    #if DEBUG_UDS > 0
                    debug_printf("���ز��ɹ�\r\n");
                    #endif
                }
                return TRUE;
            }
        }
        if (((CAN_msg->databuf[0]) & 0xf0) == 0x20) {
            for (i = 0; i < MAXPACKETPARANUM; i++) {
                if ((s_packetpara[i].packet_id == id) && (s_packetpara[i].packet_com)) {
                    #if DEBUG_UDS > 0
                    debug_printf("����\r\n");
                    #endif
                    break;
                }
                #if DEBUG_UDS > 0
                debug_printf("packet_id[%d]:%x==id:%x, pk_com:%d\r\n", i, s_packetpara[i].packet_id, id, s_packetpara[i].packet_com);
                #endif
            }
            if (i == MAXPACKETPARANUM) {
                #if DEBUG_UDS > 0
                debug_printf("meiyouweizhi\r\n");
                #endif
                return FALSE;
            }

            #if DEBUG_UDS > 0
            debug_printf("index[%d]:%x, total:%d, pklen:%d\r\n", s_packetpara[i].packet_index, CAN_msg->databuf[0], s_packetpara[i].packet_total, s_packetpara[i].packet_totallen);
            #endif
            if (((CAN_msg->databuf[0]) & 0x0f) == s_packetpara[i].packet_index++) {
                s_packetpara[i].packet_total++;
                if (s_packetpara[i].packet_index > 15) {
                    s_packetpara[i].packet_index = 0;
                }
                if ((s_packetpara[i].packet_total * 7 + 7) < s_packetpara[i].packet_totallen) {
                    memcpy(&s_packetpara[i].packet_buf[11 + s_packetpara[i].packet_total * 7], &CAN_msg->databuf[1], 7);
                    return true;
                } else {
                    leftlen = s_packetpara[i].packet_totallen - ((s_packetpara[i].packet_total) * 7);
                    memcpy(&s_packetpara[i].packet_buf[11 + s_packetpara[i].packet_total * 7], &CAN_msg->databuf[1], leftlen);
                    s_packetpara[i].packet_com = FALSE;
                       #if 0
                        s_packetpara[i].packet_buf[3] = CAN_msg->channel + 1;
                        bal_longtochar(&s_packetpara[i].packet_buf[4], s_packetpara[i].packet_id);
                        s_packetpara[i].packet_buf[4] = 1;
                    s_packetpara[i].packet_buf[9] = CAN_msg->format + 1;
                        s_packetpara[i].packet_buf[10] = s_packetpara[i].packet_totallen;
                        YX_COM_DirSend(DATA_REPORT_CAN, s_packetpara[i].packet_buf + 3, s_packetpara[i].packet_totallen + 8);
                      #else
                        s_packetpara[i].packet_buf[0] = CAN_msg->channel + 1;
                        bal_longtochar(&s_packetpara[i].packet_buf[1], s_packetpara[i].packet_id);
                        s_packetpara[i].packet_buf[5] = 0x01;                           /* һ�� */
                    s_packetpara[i].packet_buf[6] = CAN_msg->format + 1;
                        s_packetpara[i].packet_buf[7] = 0x00;                           /* reserve */
                        s_packetpara[i].packet_buf[8] = s_packet_cnt++;                 /* seq */
                        bal_shorttochar(&s_packetpara[i].packet_buf[9], s_packetpara[i].packet_totallen);/* LEN: 2 BYTE*/
                        YX_COM_DirSend(DATA_REPORT_CAN, s_packetpara[i].packet_buf, s_packetpara[i].packet_totallen + 11);
                      #endif
                    s_packetpara[i].packet_tmrcnt  = 0;
                    //CANDataReprot(s_packetpara[i].packet_buf, s_packetpara[i].packet_totallen + 11);
                    #if DEBUG_CAN > 0
                    debug_printf_dir("���һ֡:");
                    printf_hex_dir(s_packetpara[i].packet_buf, s_packetpara[i].packet_totallen + 11);
                    debug_printf_dir("\r\n");
                    #endif
                    
                    if (s_packetpara[i].packet_buf != NULL) {
                        PORT_Free(s_packetpara[i].packet_buf);
                        s_packetpara[i].packet_buf = NULL;
                    }
                    return TRUE;
                }
            }
        }
    }
    return FALSE;
}

/*******************************************************************
** ������:     Can_LossCanMsg
** ��������:   ��ʧCAN ���ļ���
** ����:       ��
** ����:       ��
********************************************************************/
static void Can_LossCanMsg(void)
{
    if (s_canRxMsg & 0x3F) {
        if (s_canMsgLossTmr) {
            s_canMsgLossTmr--;
        } else {
            s_canRxMsg = 0;
        }
    }
}

/*******************************************************************
** ������:     Can_RxMsg
** ��������:   ���յ�CAN ����
** ����:       ��
** ����:       ��
********************************************************************/
static void Can_RxMsg(INT8U channel)
{
    switch (channel){
		case 0:
			s_canRxMsg |= 0x01;
			break;
		case 1:
			s_canRxMsg |= 0x02;
			break;
		default:
			s_canRxMsg = 0;
			break;
	}
    s_canMsgLossTmr = 200;
}
/*******************************************************************
** ������:     Can_TxMsg
** ��������:   ����CAN ���ĳɹ�
** ����:       ��
** ����:       ��
********************************************************************/
void Can_TxMsg(INT8U channel)
{
    switch (channel){
		case 0:
			s_canRxMsg |= 0x01;
			break;
		case 1:
			s_canRxMsg |= 0x02;
			break;
		default:
			s_canRxMsg = 0;
			break;
	}
    s_canMsgLossTmr = 200;
}

/*******************************************************************
**  ��������:  Can_GetRxStat
**  ��������:  ��ȡcanͨ��״̬
**  �������:
**  ���ز���:
*******************************************************************/
INT8U Can_GetRxStat(void)
{
    return s_canRxMsg;
}

/*******************************************************************************
**  ��������:  CANDataHdl
**  ��������:  CAN���ĵײ�ص�������������
**  �������:  None
**  ���ز���:  None
*******************************************************************************/
void CANDataHdl(CAN_DATA_HANDLE_T *CAN_msg)
{
    INT32U id;
    //INT32U packet_id;
    INT8U        tempbuf[220];
    INT8U        rxobj;
    INT8U        i, j;
    INT16U       len;

    Can_RxMsg(CAN_msg->channel);
	
	#if DEBUG_TEMP > 1
	debug_printf("CANDataHdl\r\n");
	#endif
    id = bal_chartolong(CAN_msg->id);
    if(id == 0x18FEE900){   //�ͺı���
        s_oilsum_check = 1;
    }

    #if DEBUG_CAN > 0
    debug_printf("can:%d, ���յ�id = %x ",CAN_msg->channel, id);
    printf_hex(CAN_msg->databuf, CAN_msg->len);
    #endif
    HandShakeMsgAnalyze(CAN_msg,sizeof(CAN_msg));

    for (i = 0; i < MAX_CANIDS; i++) {
        if ((id == s_msgbt[CAN_msg->channel].idcbt[i].id
            || ((id & s_msgbt[CAN_msg->channel].idcbt[i].screeid) == (s_msgbt[CAN_msg->channel].idcbt[i].id & s_msgbt[CAN_msg->channel].idcbt[i].screeid)) )
              && (TRUE == s_msgbt[CAN_msg->channel].idcbt[i].isused)) {
            break;
        }
    }
    if (s_msgbt[CAN_msg->channel].idcbt[i].mode == CAN_COVER_OLD) {
        rxobj = i + s_msgbt[CAN_msg->channel].idcbt[i].storeadd;
        if (id != s_msgbt[CAN_msg->channel].idcbt[rxobj].id) {
            return;
        }
    } else {
        rxobj = i;
    }
    if (rxobj >= MAX_CANIDS) {
        return;
    }
    s_msgbt[CAN_msg->channel].idcbt[rxobj].len = CAN_msg->len;          //�洢��������
    memcpy(s_msgbt[CAN_msg->channel].idcbt[rxobj].storebuf, CAN_msg->databuf, CAN_msg->len);
    s_msgbt[CAN_msg->channel].recvcnt[rxobj]++;                        //��ˮ������
    s_msgbt[CAN_msg->channel].format[rxobj] = CAN_msg->format + 1;
    s_msgbt[CAN_msg->channel].type[rxobj] = CAN_msg->type;

    if (J1939_CANMsgAnalyze((INT8U*)CAN_msg, sizeof(CAN_DATA_HANDLE_T))) {
        return;
    }

    if (UDS_CANMsgAnalyze((INT8U*)CAN_msg, sizeof(CAN_DATA_HANDLE_T))) {
        return;
    }
    switch (s_can_para[CAN_msg->channel].mode) {
        case CAN_MODE_LUCIDLY:                                        //͸��ģʽ
            tempbuf[0] = CAN_msg->channel + 1;
            memcpy(&tempbuf[1], CAN_msg->id, 4);                      //ID
            tempbuf[5] = s_msgbt[CAN_msg->channel].format[rxobj];
            tempbuf[6] = 0;
            tempbuf[7] = 0;
            tempbuf[8] = s_msgbt[CAN_msg->channel].recvcnt[rxobj];    //��ˮ��
            tempbuf[9] = CAN_msg->len;                                //���ݰ�����
            memcpy(&tempbuf[10], CAN_msg->databuf, CAN_msg->len);     //�������ݰ�
            YX_COM_DirSend( DATA_LUCIDLY_CAN, tempbuf, CAN_msg->len + 10);
            break;
        case CAN_MODE_REPORT:                                         //�����ϱ�
            s_msgbt[CAN_msg->channel].idcbt[i].storeadd++;
            if ((++s_msgbt[CAN_msg->channel].idcbt[i].storecnt >= s_msgbt[CAN_msg->channel].idcbt[i].stores) && (s_msgbt[CAN_msg->channel].idcbt[rxobj].stores != 0xff)) {
                tempbuf[0] = CAN_msg->channel + 1;
                memcpy(&tempbuf[1], CAN_msg->id, 4);
                if (s_msgbt[CAN_msg->channel].idcbt[i].mode == CAN_COVER_OLD) {
                    tempbuf[5] = s_msgbt[CAN_msg->channel].idcbt[i].stores;
                    len = 6;
                    for (j = 0; j < s_msgbt[CAN_msg->channel].idcbt[i].stores; j++) {
                        tempbuf[len++] = s_msgbt[CAN_msg->channel].format[i + j];
                        tempbuf[len++] = 0;
                        tempbuf[len++] = s_msgbt[CAN_msg->channel].recvcnt[i + j]; //��ˮ��
                        tempbuf[len++] = 0;
                        tempbuf[len++] = s_msgbt[CAN_msg->channel].idcbt[i + j].len; //��������
                        memcpy(&tempbuf[len], s_msgbt[CAN_msg->channel].idcbt[i + j].storebuf, s_msgbt[CAN_msg->channel].idcbt[i + j].len);
                        len += s_msgbt[CAN_msg->channel].idcbt[i + j].len;
                    }
                } else {
                    tempbuf[5] = 1;
                    tempbuf[6] = s_msgbt[CAN_msg->channel].format[rxobj];
                    tempbuf[7] = 0;
                    tempbuf[8] = s_msgbt[CAN_msg->channel].recvcnt[rxobj]; //���һ����ˮ��
                    tempbuf[9] = 0;
                    tempbuf[10] = CAN_msg->len;                            //���һ���ĵ�������
                    memcpy(&tempbuf[11], CAN_msg->databuf, CAN_msg->len);
                    len = CAN_msg->len + 11;
                }
                YX_COM_DirSend( DATA_REPORT_CAN, tempbuf, len);
                s_msgbt[CAN_msg->channel].idcbt[rxobj].storecnt = 0;
                s_msgbt[CAN_msg->channel].idcbt[rxobj].storeadd = 0;
            }
            break;
        case CAN_MODE_QUERY:                                              //������ѯ
            if (s_msgbt[CAN_msg->channel].idcbt[i].mode == CAN_COVER_OLD) {
                if (++s_msgbt[CAN_msg->channel].idcbt[i].storeadd >= s_msgbt[CAN_msg->channel].idcbt[i].stores) {
                    s_msgbt[CAN_msg->channel].idcbt[i].storeadd = 0;
                }
                if (++s_msgbt[CAN_msg->channel].idcbt[i].storecnt > s_msgbt[CAN_msg->channel].idcbt[i].stores) {
                    s_msgbt[CAN_msg->channel].idcbt[i].storecnt = s_msgbt[CAN_msg->channel].idcbt[i].stores;
                }
            } else {
                s_msgbt[CAN_msg->channel].idcbt[i].storecnt = 1;
            }
            break;
        default :
            break;
    }




}
/**************************************************************************************************
**  ��������:  GetOilMsg_State
**  ��������:  ��ȡ�ͺı���ID��0x18FEE900״̬
**  �������:  ��
**  ���ز���:  FALSE:�յ���ID��TRUE:û�յ���ID
**************************************************************************************************/
BOOLEAN GetOilMsg_State(void)
{
    if(s_oilsum_check == 0){
        return TRUE;
    }else{
        return FALSE;
    }
}

/**************************************************************************************************
**  ��������:  ResetOilMsg_State
**  ��������:  �����ͺı���ID��0x18FEE900״̬
**  �������:  ��
**  ���ز���:  ��
**************************************************************************************************/
void ResetOilMsg_State(void)
{
    s_oilsum_check = 0;
}

/*******************************************************************************
**  ��������:  GetIDIsUsed
**  ��������:  ��ȡID�Ƿ�ʹ��
**  �������:  idcnts ���
**  ���ز���:  TRUE  or FALSE
*******************************************************************************/
BOOLEAN GetIDIsUsed(INT8U idcnts, INT8U channel)
{
    return s_msgbt[channel].idcbt[idcnts].isused;
}
/**************************************************************************************************
**  ��������:  GetIDCnts
**  ��������:  ��ȡ��ǰͨ���Ѿ����õĹ���ID����
**  �������:  channel: CAN ͨ��
**  ���ز���:  s_can0objcnt_rx / s_can1objcnt_rx
**************************************************************************************************/
INT8U GetIDCnts(INT8U channel)
{
    return s_msgbt[channel].rxobjused;
}

/**************************************************************************************************
**  ��������:  GetID
**  ��������:  ��ȡIDֵ
**  �������:  idcnts ���
**  ���ز���:  IDֵ
**************************************************************************************************/
INT32U GetID(INT8U idcnts, INT8U channel)
{
    return s_msgbt[channel].idcbt[idcnts].id;
}
/**************************************************************************************************
**  ��������:  GetStoreData
**  ��������:  app���ȡ�����CAN���ݣ����ڱ�����ѯģʽ
**  �������:
               idcnts  : ID���
               buf     : �洢�������ݵ���ʼ��ַ
**  ���ز���:  ����
**************************************************************************************************/
INT16U GetStoreData(INT8U idcnts, INT8U *buf, INT8U channel)
{
    INT16U storeaddr;
    INT8U  len;
    INT8U  *ptr;
    INT8U  i;
    INT8U  idadd;
    INT8U  storecnt;

    ptr = buf;

    storeaddr = 0;
    bal_longtochar(ptr, s_msgbt[channel].idcbt[idcnts].id);              /* ID */
    storeaddr = 4;
    if (s_msgbt[channel].idcbt[idcnts].mode == CAN_COVER_OLD) {
        storecnt = s_msgbt[channel].idcbt[idcnts].storecnt;      /* ����֡�� */
        if (s_msgbt[channel].idcbt[idcnts].storecnt >= s_msgbt[channel].idcbt[idcnts].stores) {
            idadd = idcnts + s_msgbt[channel].idcbt[idcnts].storeadd;
        } else {
            idadd = idcnts;
        }
    } else {
        if (s_msgbt[channel].idcbt[idcnts].storecnt) {
            storecnt = 1;
        } else {
            storecnt = 0;
        }
        idadd = idcnts;
    }
    ptr[storeaddr++] = storecnt;
    for (i = 0; i < storecnt; i++) {
        ptr[storeaddr++] = s_msgbt[channel].type[idadd];
        ptr[storeaddr++] = 0;
        ptr[storeaddr++] = s_msgbt[channel].recvcnt[idadd];          /* ��ˮ�� */
        ptr[storeaddr++] = 0;
        len = s_msgbt[channel].idcbt[idadd].len;                     /* ��ȡ���ݰ����� */
        ptr[storeaddr++] = len;
        memcpy(&ptr[storeaddr], (s_msgbt[channel].idcbt[idadd].storebuf), len);
        storeaddr += len;
        if (++idadd >= idcnts + s_msgbt[channel].idcbt[idcnts].stores) {
            idadd = idcnts;
        }
    }
    s_msgbt[channel].idcbt[idcnts].storecnt = 0;                     /* �Ѿ��յ�������֡������ */
    s_msgbt[channel].idcbt[idcnts].storeadd = 0;
    return storeaddr;                                                /* ɾ�����һ�μ��ϵĳ��� */
}

/**************************************************************************************************
**  ��������:  GetIDPara
**  ��������:  ��ȡ�˲�ID���Բ���
**  �������:  idcnts ���
               channel ͨ����
**  ���ز���:  ָ��ID���Խṹ��ĵ�ַ
**************************************************************************************************/
IDPARA_T* GetIDPara(INT8U idcnts, INT8U channel)
{
    return &s_msgbt[channel].idcbt[idcnts];
}

/**************************************************************************************************
**  ��������:  SetID
**  ��������:  �����˲�ID
**  �������:  idnums : Ҫ���õ�ID����Ŀ
               idpara : ID����ز���
**  ���ز���:  �ɹ�TRUE ʧ��FALSE
**************************************************************************************************/
static BOOLEAN SetID(INT8U idnums, INT8U *idpara, CAN_FILTERCTRL_E onoff, INT8U channel)
{
    INT8U  idindex;
    INT8U  i, k;
    INT8U  tempi;
    IDPARA_T canid;
    INT8U frameformat=0;

    idindex = 0;
    if (onoff == CAN_FILTER_OFF) {
        PORT_ClearCanFilter((CAN_CHN_E)channel);
        return TRUE;
    }
    for (i = 0; i < idnums; i++) {
        for (; idindex < MAX_CANIDS; idindex++) {
            if (FALSE == GetIDIsUsed(idindex, channel)) break;       /* ���ҵ�δ�����õģ��������� */
        }
        tempi = 2 + i * 6;
        canid.id = bal_chartolong(&idpara[tempi]);
        canid.screeid  = 0xffffffff;
        #if DEBUG_CAN > 0
          debug_printf_dir("id = %x\r\n", canid.id);
        #endif
        canid.stores = idpara[tempi + 4];
        canid.mode = idpara[tempi + 5];
        canid.isused = TRUE;                                         /* ��ID�����ñ�־ */

        if(canid.id <= 0x7ff){//����ID�жϱ�׼֡������չ֡
        	frameformat= FMAT_STD;
        } else {
        	frameformat =FMAT_EXT;
        }
        if (!PORT_SetCanFilter((CAN_CHN_E)channel, frameformat, canid.id, 0xffffffff)){
            return FALSE;
        }

        if (canid.mode == CAN_COVER_OLD) {
            k = canid.stores;
        } else {
            k = 1;
        }
        while (k--) {
            if (idindex >= MAX_CANIDS) {
                return FALSE;
            }
            SetIDPara(&canid, idindex, channel);
            idindex++;
        }
    }
    return TRUE;
}

/*******************************************************************************
**  ��������:  SetIDPara
**  ��������:  �����˲�ID���Բ���
**  �������:  idcnts ���
               channel ͨ����
**  ���ز���:  ָ��ID���Խṹ��ĵ�ַ
*******************************************************************************/
void SetIDPara(IDPARA_T *idset, INT8U idcnts, INT8U channel)
{
    if (idset->isused) {
        s_msgbt[channel].recvcnt[idcnts] = 0;                                /* ��ˮ������ */
        s_msgbt[channel].idcbt[idcnts].isused = idset->isused;               /* ʹ����� */
        s_msgbt[channel].idcbt[idcnts].storecnt = 0;                         /* �Ѿ����մ洢��֡������ */
        s_msgbt[channel].idcbt[idcnts].storeadd = 0;
        s_msgbt[channel].idcbt[idcnts].stores = idset->stores;
        s_msgbt[channel].idcbt[idcnts].id = idset->id;                       /* ID */
        s_msgbt[channel].idcbt[idcnts].screeid = idset->screeid & 0x00ffffff;/* ǰ�����ֽڲ����� */
        s_msgbt[channel].idcbt[idcnts].mode = idset->mode;

        s_msgbt[channel].rxobjused++;
    } else {
        if (s_msgbt[channel].idcbt[idcnts].isused) {
            s_msgbt[channel].idcbt[idcnts].isused = FALSE;
            s_msgbt[channel].recvcnt[idcnts] = 0;
            if (s_msgbt[channel].rxobjused) {
                s_msgbt[channel].rxobjused--;
            }
        }
    }
}

/*******************************************************************************
**  ��������:  SetScreenID
**  ��������:  ��������ģʽ�˲�ID
**  �������:  idnums : Ҫ���õ�ID����Ŀ
               idpara : ID����ز���
**  ���ز���:  �ɹ�TRUE ʧ��FALSE
*******************************************************************************/
static BOOLEAN SetScreenID(INT8U idnums, INT8U *idpara, CAN_FILTERCTRL_E onoff, INT8U channel)
{
    INT8U  idindex, idcnt;
    INT8U  i, j, k;
    INT16U  tempi;
    IDPARA_T canid;
    INT32U filter_id, screen_id;
    INT8U frameformat=0;

    idindex = 0;
    if (onoff == CAN_FILTER_OFF) {
        PORT_ClearCanFilter((CAN_CHN_E)channel);
    }
    tempi = 2;
    for (i = 0; i < idnums; i++) {
    	filter_id = bal_chartolong(&idpara[tempi]);
        tempi += 4;
        screen_id = bal_chartolong(&idpara[tempi]);
        tempi += 4;
        if(filter_id <= 0x7ff){//����ID�жϱ�׼֡������չ֡
        	frameformat= FMAT_STD;
        } else {
        	frameformat =FMAT_EXT;
        }
         #if DEBUG_CAN > 0
            debug_printf_dir("SetID:%x,%x,%d\r\n",filter_id,screen_id,frameformat);
        #endif
        if (!PORT_SetCanFilter((CAN_CHN_E)channel, frameformat, filter_id, screen_id)) {
            #if DEBUG_CAN > 0
                debug_printf_dir("CAN����ʧ��\r\n");
            #endif
            return FALSE;
        }

        idcnt = idpara[tempi++];
        #if DEBUG_CAN > 0
            debug_printf_dir("idcnt%d\r\n",idcnt);
        #endif

        if (idcnt == 0) {                                            // id����Ϊ0ʱ��ʾ������λȫ����
            for (; idindex < MAX_CANIDS; idindex++) {
                if (FALSE == GetIDIsUsed(idindex, channel)) break;    //���ҵ�δ�����õģ���������
            }
            if (idindex >= MAX_CANIDS) {
                return FALSE;
            }

            canid.id      = filter_id;
            canid.screeid = screen_id;
            canid.stores  = 0x01;
            canid.isused  = TRUE;
            SetIDPara(&canid, idindex, channel);
            continue;
        }

        for (j = 0; j < idcnt; j++) {
            for (; idindex < MAX_CANIDS; idindex++) {
                if (FALSE == GetIDIsUsed(idindex, channel)) break;  //���ҵ�δ�����õģ���������
            }

            canid.id = bal_chartolong(&idpara[tempi]);
            canid.screeid  = 0xffffffff;
            tempi += 4;
            canid.stores = idpara[tempi++];
            canid.mode = idpara[tempi++];
            canid.isused = TRUE;                                   // ��ID�����ñ�־
            if (canid.mode == CAN_COVER_OLD) {
                k = canid.stores;
            } else {
                k = 1;
            }
            while (k--) {
                if (idindex >= MAX_CANIDS) {
                    return FALSE;
                }
                SetIDPara(&canid, idindex, channel);
                idindex++;
            }
        }
    }
    return TRUE;
}

void Test_CAN_Send(void)
{
    CAN_DATA_SEND_T candata;
	memset(&candata, 0x11, sizeof(candata));
	candata.can_DLC = 8;
	candata.can_id = 0xaa;
	candata.can_IDE = 0;
	candata.period = 0xffff;
	candata.channel = 0;
	PORT_CanSend(&candata);
    candata.can_id = 0xbb;
    PORT_CanSend(&candata);
    
	candata.channel = 1;
    candata.can_id = 0xaa;
	PORT_CanSend(&candata);
    candata.can_id = 0xbb;
    PORT_CanSend(&candata);    
}

/*******************************************************************************
**  ��������:  PacketTimeOut
**  ��������:  �ְ����䳬ʱ
**  �������:  ��
**  �������:  ��
**  ���ز���:  ��
*******************************************************************************/
static void PacketTimeOut(void* pdata)
{
    INT8U i = 0;
    #if DEBUG_CAN > 1
    static INT8U test_cnt = 0;
    if (++test_cnt >= 100) {
        test_cnt = 0;
        Test_CAN_Send();
    }
    #endif
    
    CanResendHdl();
    for (i = 0 ; i < MAXPACKETPARANUM; i++) {
        if (s_packetpara[i].packet_com == TRUE) {
            if (++s_packetpara[i].packet_tmrcnt > PACKETOVERTMR) {
           #if DEBUG_UDS > 0
               debug_printf("���ճ�ʱ�������%d���֡\r\n", i);
           #endif
               s_packetpara[i].packet_com = FALSE;
               if (s_packetpara[i].packet_buf != NULL) {
                  PORT_Free(s_packetpara[i].packet_buf);
                  s_packetpara[i].packet_buf = NULL;
               }
            }
        }

        if (s_sendpacket[i].packet_com == TRUE) {               /* ������ͳ�ʱ���� */
            if (++s_sendpacket[i].packet_tmrcnt > PACKETOVERTMR) {
               s_sendpacket[i].packet_com = FALSE;
               s_sendpacket[i].sendcontinue = FALSE;
               if (s_sendpacket[i].packet_buf != NULL ) {
                  PORT_Free(s_sendpacket[i].packet_buf);
                  s_sendpacket[i].packet_buf = NULL;
               }
            }
        }
    }

    SendCF();

    Can_LossCanMsg();    
}

/**************************************************************************************************
**  ��������:  BusTypeSetReqHdl
**  ��������:  ������������������
**  �������:
**  ���ز���:  None
**************************************************************************************************/
void BusTypeSetReqHdl(INT8U mancode,  INT8U command, INT8U *data, INT16U datalen)
{
    INT8U ack[3];
    #if DEBUG_CAN > 0
    debug_printf_dir("BusTypeSetReqHdl()");
    printf_hex_dir(data, datalen);
    debug_printf_dir("\r\n");
    #endif


    ack[0] = data[0];
    ack[1] = data[1];

    if (0x01 == data[0]) {

    } else {
        ack[2] = 0x02;                                                         /* ��������Ƿ� */
        YX_COM_DirSend( BUS_TYPE_SET_ACK, ack, 3);
        return;
    }
    ack[2] = 0x01;                                                             /* ��������Ϸ� */
    YX_COM_DirSend( BUS_TYPE_SET_ACK, ack, 3);

}

/**************************************************************************************************
**  ��������:  BusOnOffReqHdl
**  ��������:  ���߿�������������
**  �������:
**  ���ز���:  None
**************************************************************************************************/
void BusOnOffReqHdl(INT8U mancode,INT8U command, INT8U *data, INT16U datalen)
{
    INT8U ack[3];
    INT8U channel;
    #if DEBUG_CAN > 0
    debug_printf_dir("BusOnOffReqHdl()");
    printf_hex_dir(data, datalen);
    debug_printf_dir("\r\n");
    #endif


    ack[0] = data[0];
    ack[1] = data[1];
    channel = data[0] - 1;


    if (channel >= MAX_CAN_CHN) {
        ack[2] = 0x02;
        YX_COM_DirSend( BUS_ONOFF_CTRL_ACK, ack, 3);
        return;
    }


    if (0x01 == data[1]) {                                                 /* ��������ͨ�� */
         PORT_CanEnable((CAN_CHN_E)channel, true);
         s_can_para[channel].onoff = true;
       //}else{
           if( s_can_para[channel].onoff == true){/*����Ѿ�������Ϊ�ɹ�*/

           }else{
              #if DEBUG_CAN > 0
                  debug_printf_dir("PORT_OpenCan(%d)fail,ONOFF%d\r\n",channel, s_can_para[channel].onoff);
              #endif
              ack[2] = 0x02;
              YX_COM_DirSend( BUS_ONOFF_CTRL_ACK, ack, 3);
              return;
           }
       //}
    } else if (0x02 == data[1]) {                                          /* �ر�����ͨ�� */
       PORT_CanEnable((CAN_CHN_E)channel,false);
       s_can_para[channel].onoff = false;
    } else {                                                                   /* ����Ƿ���ʧ�� */
        ack[2] = 0x02;
        YX_COM_DirSend( BUS_ONOFF_CTRL_ACK, ack, 3);
        return;
    }

    ack[2] = 0x01;
    YX_COM_DirSend( BUS_ONOFF_CTRL_ACK, ack, 3);
}

/*******************************************************************************
 ** ������:     HdlMsg_PARA_SET_CAN
 ** ��������:   CANͨ�Ų����������������������ò����ʡ�֡��ʽ��֡����
 ** ����:       [in]cmd:�������
 **             [in]data:����ָ��
 **             [in]datalen:���ݳ���
 ** ����:       ��
 ******************************************************************************/
void CANCommParaSetReqHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
	INT8U ack[2];
	INT8U channel;

	#if DEBUG_CAN > 0
	debug_printf_dir("HdlMsg_PARA_SET_CAN(), CANͨ�Ų�������:");
	printf_hex_dir(data, datalen);
	debug_printf_dir("\r\n");
	#endif
        if (!GetFiltenableStat()) return;
		ack[0] = data[0];
		channel = data[0]-1;

		if (channel >= MAX_CAN_CHN) {
			ack[1] = 0x03; /* ��������Ƿ� */
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

		//���߻��ѣ�ʧȥ������ʱ��SIMCOM�����·�����CAN������������رգ������ûᵼ�¸�λ��
		//PORT_CloseCan(channel);//�ȹص�������������ٿ��������������ʧ��

		if ((data[1] < 0x01) || (data[1] > 0x08)) {
			ack[1] = 0x03;
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

		if ((data[4] < 0x01) || (data[4] > 0x03)) {
			ack[1] = 0x05;
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

		switch (data[1]) {
		case 0x01:
			s_can_para[channel].baud = CAN_BAUD_10K;
			break;
		case 0x02:
			s_can_para[channel].baud = CAN_BAUD_20K;
			break;
		case 0x03:
			s_can_para[channel].baud = CAN_BAUD_50K;
			break;
		case 0x04:
			s_can_para[channel].baud = CAN_BAUD_100K;
			break;
		case 0x05:
			s_can_para[channel].baud = CAN_BAUD_125K;
			break;
		case 0x06:
			s_can_para[channel].baud = CAN_BAUD_250K;
			break;
		case 0x07:
			s_can_para[channel].baud = CAN_BAUD_500K;
			break;
		case 0x08:
			s_can_para[channel].baud = CAN_BAUD_1000K;
			break;
		default:
			ack[1] = 0x03;
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

		switch (data[2]) {
		case 0x01:
		    s_can_para[channel].frameformat = FMAT_STD;
			break;
		case 0x02:
		    s_can_para[channel].frameformat = FMAT_EXT;
			break;
		default:
			ack[1] = 0x05;
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

		switch (data[4]) {
		case 0x01:
		    s_can_para[channel].mode = CAN_MODE_LUCIDLY;
			break;
		case 0x02:
		    s_can_para[channel].mode = CAN_MODE_REPORT;
			break;
		case 0x03:
		    s_can_para[channel].mode = CAN_MODE_QUERY;
			break;
		default:
			ack[1] = 0x05;
			YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
			return;
		}

        ack[1] = 0x01;
        YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
        #if 0
        if (PORT_OpenCan(channel, s_can_para[channel].baud , s_can_para[channel].frameformat)) {
            ack[1] = 0x01;
            YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
            s_can_para[channel].onoff = true;
        } else {
            #if DEBUG_CAN > 0
                debug_printf_dir("para set fail\r\n");
            #endif
            ack[1] = 0x05;
            YX_COM_DirSend( PARA_SET_CAN_ACK, ack, 2);
        }
        #endif
}

/**************************************************************************************************
**  ��������:  CANWorkModeSetHdl
**  ��������:  CAN����ģʽ���ô�������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void CANWorkModeSetHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U  ack[3];
    INT8U  channel;
    IDPARA_T canid;
    INT8U  i;


    ack[0] = data[0];
    ack[1] = data[1];
    channel = data[0] - 1;

    #if DEBUG_CAN > 0
    debug_printf_dir("����ģʽ����:");
    printf_hex_dir(data,datalen);
    #endif

    if (channel >= MAX_CAN_CHN) {
        ack[2] = 0x04;                                               /* ��������Ƿ� */
        YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
        return;
    }

    PORT_CanEnable((CAN_CHN_E)channel,false);//�ȹص�������������ٿ��������������ʧ��

    #if DEBUG_CAN > 0
        debug_printf_dir("CAN%dģʽ����:%d\r\n",data[0], data[1]);
    #endif

    if (0x01 == data[1]) {                                       /* ��ȫ͸��ģʽ */
        if (s_can_para[channel].mode != CAN_MODE_LUCIDLY) {
            s_can_para[channel].mode = CAN_MODE_LUCIDLY;
        }
    } else if (0x02 == data[1]) {                                /* �����ϱ�ģʽ */
        if (s_can_para[channel].mode != CAN_MODE_REPORT) {
            s_can_para[channel].mode = CAN_MODE_REPORT;
        }
    } else if (0x03 == data[1]) {                                /* ������ѯģʽ */
        if (s_can_para[channel].mode != CAN_MODE_QUERY) {
            s_can_para[channel].mode = CAN_MODE_QUERY;
        }
    } else {                                                         /* ���� */
        ack[2] = 0x04;
        YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
        return;
    }
    /* ��ʼ���˲�ID�������ã�������ģʽ�ı�ʱ��������ʹ�õ��˲�ID��Ҫ��գ�������IDδ���� */
    canid.isused = FALSE;
    for (i = 0; i < MAX_CANIDS; i++) {                      /* ����������ù���ID�˲����� */
        SetIDPara(&canid, i, channel);
    }
    PORT_ClearCanFilter((CAN_CHN_E)channel);                  /* �����Ϣ���� */

  //  YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
    //ack[2] = 0x01;
   // YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
    #if 1
    if (PORT_OpenCan((CAN_CHN_E)channel, s_can_para[channel].baud , s_can_para[channel].frameformat)) {
        ack[2] = 0x01;
        YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
        s_can_para[channel].onoff = true;
    } else {
        #if DEBUG_CAN > 0
            debug_printf_dir("para set fail\r\n");
        #endif
        ack[2] = 0x05;
        YX_COM_DirSend( WORKMODE_SET_CAN_ACK, ack, 3);
    }
   #endif
}

/**************************************************************************************************
**  ��������:  CANFilterIDSetReqHdl
**  ��������:  CAN�˲�ID��������������
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**************************************************************************************************/
void CANFilterIDSetReqHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U  idcnts;
    INT8U  idused;
    INT8U  i, tempi;
    INT8U  ack[3];
    INT32U tempid;
    INT8U  channel;
    IDPARA_T canid;


    #if DEBUG_CAN > 0
        debug_printf_dir("�����˲�����:");
       // printf_hex_dir(data,datalen);
    #endif
   if (!GetFiltenableStat()) return;// if (!s_idfiltenable) return;

    ack[0] = data[0];
    ack[1] = data[1];
    channel = data[0] - 1;

    if (channel >= MAX_CAN_CHN) {
        ack[2] = 0x05;                                               /* ��������Ƿ� */
        YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
        return;
    }


    switch (data[1]) {
        case ID_CLRALL:                                              /* ������� */
            #if DEBUG_CAN > 0
                debug_printf_dir("D7_ID_CLRALL:%d\r\n",channel);
            #endif
            #if 1
            canid.isused = FALSE;

            for (i = 0; i < MAX_CANIDS; i++) {                      /* ����������ù���ID�˲����� */
                SetIDPara(&canid, i, channel);
            }

            PORT_ClearCanFilter((CAN_CHN_E)channel);                           /* �����Ϣ���� */

            if (SetID(data[2], &data[1], CAN_FILTER_ON, channel)) {
                ack[2] = 0x01;
            } else {
                ack[2] = 0x07;
            }

            #endif
            YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
            break;
        case ID_ADD:                                                 /* ׷�Ӳ��� */
             #if DEBUG_CAN > 0
                debug_printf_dir("D7 ID_ADD:\r\n");
            #endif
            for (i = 0; i < data[2]; i++) {
                tempi = 3 + i * 6;
                tempid = bal_chartolong(&data[tempi]);               /* ��ȡID */
                for (idcnts = 0; idcnts < MAX_CANIDS; idcnts++) {
                    if ((tempid == GetID(idcnts, channel)) && (TRUE == GetIDIsUsed(idcnts, channel))) {
                        ack[2] = 0x05;
                        YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
                        return;
                    }
                }
            }
            if (SetID(data[2], &data[1], CAN_FILTER_ON, channel)) {
                ack[2] = 0x01;
            } else {
                ack[2] = 0x07;
            }
            ack[2] = 0x01;
            YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
            break;
        case ID_DEL:                                                 /* ɾ��ָ�� ����֤*/
            #if DEBUG_CAN > 0
                debug_printf_dir("D7 ID_DEL:\r\n");
            #endif
            idused = GetIDCnts(channel);                             /* ��ȡ����ID���� */
            if (idused < data[2]) {                              /* ���趨�Ļ�С��Ҫɾ���ĸ��������� */
                ack[2] = 0x05;
                YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
                return;
            }
            for (i = 0; i < data[2]; i++) {
                tempi = 3 + i * 6;
                tempid = bal_chartolong(&data[tempi]);               /* ��ȡID */
                for (idcnts = 0; idcnts < MAX_CANIDS; idcnts++) {
                    if ((tempid == GetID(idcnts, channel)) && (TRUE == GetIDIsUsed(idcnts, channel))) {
                        canid.isused = FALSE;
                        SetIDPara(&canid, idcnts, channel);
                        break;
                    }
                }
                if (idcnts >= MAX_CANIDS) {                         /* ��������󣬻���û����ͬ��ID������ */
                    ack[2] = 0x05;
                    YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
                    return;
                }
                //CAN_ClearFilterByID(tempid, channel);
            }
            if (idused == data[2]) {                             /* ��ȫɾ�� */
            }
            ack[2] = 0x01;
            YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
            break;
        case ID_NOFILTER:
            #if DEBUG_CAN > 0
                debug_printf_dir("D7 ID_NOFILTER:\r\n");
            #endif
            SetID(0, 0, CAN_FILTER_OFF, channel);
            ack[2] = 0x01;
            YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
            break;
        default :
            ack[2] = 0x05;                                                     /* ���������趨��Χ */
            YX_COM_DirSend( FILTER_SET_CAN_ACK, ack, 3);
            break;
    }
}

/**************************************************************************************************
**  ��������:  CANFilterIDQueryHdl
**  ��������:  CAN�˲����ò�ѯ��������
**  �������:
**  ���ز���:  None
**************************************************************************************************/
void CANFilterIDQueryHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U ack[4 + 52];
    INT8U i, start;
    IDPARA_T *idptr;
    INT8U channel;



    ack[0] = data[0];
    channel = data[0] - 1;

    if (channel >= MAX_CAN_CHN) {
        ack[1] = 0x02;                                               /* ��������Ƿ� */
        YX_COM_DirSend( FILTER_QUERY_CAN_ACK, ack, 2);
        return;
    }


    ack[1] = 0x01;                                                   /* �������������Բ�ѯ */
    ack[2] = MAX_CANIDS;
    ack[3] = GetIDCnts(channel);

    if (0 == ack[3]) {                                               /* û������ID */
        YX_COM_DirSend( FILTER_QUERY_CAN_ACK, ack, 4);
    } else {
        start = 0x04;
        for (i = 0; i < MAX_CANIDS; i++) {                           /* ��ͷ��β������Ŀ�����Է���Щ��ɾ�����м��пհ� */
            idptr = GetIDPara(i, channel);
            if (TRUE == idptr->isused) {
                bal_longtochar(&ack[start], idptr->id);
                start = start + 4;
            }
        }
        if (start <= 0x04) {                                         /* û���ѵ�ID ���� */
            ack[1] = 0x03;
            YX_COM_DirSend( FILTER_QUERY_CAN_ACK, ack, 2);
            return;
        }
        YX_COM_DirSend( FILTER_QUERY_CAN_ACK, ack, start);
    }
}

/**************************************************************************************************
**  ��������:  CANWorkModeQueryHdl
**  ��������:  CAN����ģʽ��ѯ��������
**  �������:  None
**  ���ز���:  None
**************************************************************************************************/
void CANWorkModeQueryHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen)
{
    INT8U  ack[3];
    INT8U  channel;


    ack[0] = data[0];
    channel = data[0] - 1;

    if (channel >= MAX_CAN_CHN) {
        ack[1] = 0x02;                                               /* ��������Ƿ� */
        YX_COM_DirSend( WORKMODE_QUERY_CAN_ACK, ack, 2);
        return;
    }

    ack[1] = 0x01;
    ack[2] = (INT8U)s_can_para[channel].mode;
    YX_COM_DirSend( WORKMODE_QUERY_CAN_ACK, ack, 3);
}

/*******************************************************************************
 ** ������:     HdlMsg_FILTER_SCREEN_CAN
 ** ��������:   CAN�����˲�������������������
 ** ����:       [in]cmd:�������
 **             [in]data:����ָ��
 **             [in]datalen:���ݳ���
 ** ����:       ��
 ******************************************************************************/
void CANScreenIDSetReqHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen) {
	INT8U i;
	INT8U ack[3];
	INT8U channel;
	IDPARA_T canid;

	ack[0] = data[0];
	ack[1] = data[1];
	channel = data[0]-1;

    if (!GetFiltenableStat()) return;
     #if DEBUG_CAN > 0
         debug_printf_dir("CANScreenIDSetReqHdl:\r\n");
     #endif

	if (channel >= MAX_CAN_CHN) {
        #if DEBUG_CAN > 0
            debug_printf_dir("CANcommand false:\r\n");
        #endif
		ack[2] = 0x05;  //��������Ƿ�
		YX_COM_DirSend( FILTER_SCREEN_CAN_ACK, ack, 3);
		return;
	}

	switch (data[1]) {
	    case ID_CLRALL:  //�������
	        #if DEBUG_CAN > 0
                debug_printf_dir(" DE_ID_CLRALL:idnum = %d\r\n",data[2]);
            #endif
			canid.isused = false;
			for (i = 0; i < MAX_CANIDS; i++) {  //����������ù���ID�˲�����
				SetIDPara(&canid, i, channel);
			}
			PORT_ClearCanFilter((CAN_CHN_E)channel);
			ack[2] = 0x01;
			if (SetScreenID(data[2], &data[1], CAN_FILTER_ON, channel)) {
				ack[2] = 0x01;
			} else {
				ack[2] = 0x07;
			}
			YX_COM_DirSend( FILTER_SCREEN_CAN_ACK, ack, 3);
			break;
	    case ID_ADD:  //׷�Ӳ���
	    	 #if DEBUG_CAN > 0
                debug_printf_dir("DE_ID_ADD:\r\n");
            #endif
			if (SetScreenID(data[2], &data[1], CAN_FILTER_ON, channel)) {
				ack[2] = 0x01;
			} else {
				ack[2] = 0x07;
			}
			YX_COM_DirSend( FILTER_SCREEN_CAN_ACK, ack, 3);
			break;
	default:
         #if DEBUG_CAN > 0
             debug_printf_dir("DE_CAN SET DEFAUL:\r\n");
         #endif
		ack[2] = 0x05;  //���������趨��Χ
		YX_COM_DirSend( FILTER_SCREEN_CAN_ACK, ack, 3);
		break;
	}
}

/*******************************************************************************
 ** ������:     HdlMsg_DATA_TRANSF_CAN
 ** ��������:   CAN����ת������������
 ** ����:       [in]cmd:�������
 **             [in]data:����ָ��
 **             [in]datalen:���ݳ���
 ** ����:       ��
 ******************************************************************************/
void CANDataTransReqHdl(INT8U mancode, INT8U command,INT8U *data, INT16U datalen) {
	INT8U ack[6];
	INT8U temp[4];
	INT8U i,j;
	INT8U num;
	INT8U type,sendlen;
	INT16U period;
	INT32U id;
	STREAM_T strm;
	CAN_DATA_SEND_T senddata;

    mancode     = mancode;
    command     = command;

#if DEBUG_UDS > 0
    debug_printf_dir("<*****CANDataTransReqHdl*****>:\r\n");
    printf_hex_dir(data, datalen);
    debug_printf_dir("\r\n");
#endif
    senddata.channel = data[0]-1;
	ack[0] = data[0];
   	ack[1] = data[1];
	ack[2] = data[2];                              /* ��ˮ�� */
 
	if (senddata.channel >= MAX_CAN_CHN)  {
		ack[3] = 0x05;  //��������Ƿ�
		YX_COM_DirSend( DATA_TRANSF_CAN_ACK, ack, 4);
		return;
	}

	ack[3] = 0x01;
	bal_InitStrm(&strm, data + 4, datalen - 4);
	num = bal_ReadBYTE_Strm(&strm);
    #if DEBUG_UDS > 0
    debug_printf_dir("<*****CANDataTransReqHdl:num:%d *****>\r\n",num);
    #endif
	for (i = 0; i < num; i++) {
		bal_ReadDATA_Strm(&strm, temp, 4);
		id = bal_chartolong(temp);
		type = bal_ReadBYTE_Strm(&strm);
		period = (INT16U) bal_ReadBYTE_Strm(&strm) << 8;
		period |= bal_ReadBYTE_Strm(&strm);
		sendlen = bal_ReadBYTE_Strm(&strm);

		if (sendlen > 8) {             //���ȴ���8�����ö�֡����
            #if DEBUG_CAN > 0
            debug_printf("��֡\r\n");
            #endif
            j = FindFreeItem_SendList();
            if (j == MAXPACKETPARANUM) {
                return;
            }
            s_sendpacket[j].packet_com = TRUE;
            s_sendpacket[j].channel = data[0]-1;
            s_sendpacket[j].sendid = id;
            s_sendpacket[j].packet_totallen = sendlen - 1;
            s_sendpacket[j].sendlen = 0;
            s_sendpacket[j].sendpacket = 0;
            s_sendpacket[j].packet_buf= PORT_Malloc(s_sendpacket[j].packet_totallen);
            if (s_sendpacket[j].packet_buf == NULL) {
                s_sendpacket[j].packet_com = FALSE;
                bal_MovStrmPtr(&strm, sendlen);
            } else {
                bal_MovStrmPtr(&strm, 1);                      /* 1 for PCItype ����Ҫ�õ� */
                bal_ReadDATA_Strm(&strm, s_sendpacket[j].packet_buf, sendlen-1);
            }
            if((UDS_ID_SEND == id) || (UDS_ID_SEND1 == id)|| (id == UDS_ID_SEND2)|| (id == UDS_ID_SEND3)
            || (UDS_ID_SEND4 == id)|| (id == UDS_ID_SEND5)|| (id == UDS_ID_SEND6)) {//UDS��֡
                #if DEBUG_CAN > 0
                debug_printf("UDS��֡����,%d\r\n",s_sendpacket[j].packet_totallen);
                #endif
                s_sendpacket[j].prot_type = UDS_TYPE;
                if (s_sendpacket[j].packet_com) {
                    SendFF(&s_sendpacket[j]);
                }
            } else {
                #if DEBUG_CAN > 0
                    debug_printf("J1939��֡����,%d\r\n",s_sendpacket[j].packet_totallen);
                #endif
                s_sendpacket[j].prot_type = J1939_TYPE;
                if ((s_sendpacket[j].packet_com) && (FALSE == Find_J1939Sending())) {//û�ҵ����ڷ��͵�J1939��֡
                    SendJ1939FirPacket(&s_sendpacket[j]);
                }
            }
            YX_COM_DirSend( DATA_TRANSF_CAN_ACK, ack, 4);
            return;
        } else {
    		senddata.can_id = id;
            #if DEBUG_CAN > 0
                if (id == 0x18ea0021)
                debug_printf("��������·�\r\n");
            #endif
    		senddata.period = period/10;
    		senddata.can_DLC = sendlen;
            if(id <= 0x7ff){
                senddata.can_IDE = 0;  /*��׼֡*/
            } else {
                senddata.can_IDE = 1;
            }
    		bal_ReadDATA_Strm(&strm, senddata.Data, senddata.can_DLC);
        }
		switch (type) {
		case CAN_SEND_NOMAL:
		    senddata.period = 0xffff;
			if (false == PORT_CanSend(&senddata)){  //����æµ������
				ack[3] = 0x02;
			}
            if ((id == 0x0CFE21EE) || (id == 0x18FFD034)) {
                StartCanResend(senddata.channel, id, senddata.Data, sendlen);
            }
			break;
		case CAN_SEND_PERIOD:
			if (false == PORT_CanSend(&senddata)) {
				ack[3] = 0x02;
			}
			break;
		case CAN_SEND_STOP:
		    senddata.period = 0;
			if (false == PORT_CanSend(&senddata)) {
				ack[3] = 0x02;
			}
			break;
		default:
			ack[3] = 0x02;
			break;
		}
	}
	YX_COM_DirSend( DATA_TRANSF_CAN_ACK, ack, 4);
}


/**************************************************************************************************
**  ��������:  GetCANDataReqHdl
**  ��������:  ��̨��ȡCAN��������������
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**************************************************************************************************/
void GetCANDataReqHdl(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    INT32U  tempid;
    INT8U   i, j;
    INT8U   ack[3 + (4 + 1 + 4 + 1 + 8) * MAX_CANIDS / 2];
    INT8U   IDSum = 0;
    INT8U   IDCnt = 0;
    INT8U   channel;
    INT16U  addr, temlen;

    ack[0] = data[0];
    channel = data[0] - 1;

    if (channel >= MAX_CAN_CHN) {
        ack[1] = 0x03;                                               /* ��������Ƿ� */
        YX_COM_DirSend( GET_CAN_DATA_REQ_ACK, ack, 2);
        return;
    }


    if ((CAN_MODE_QUERY != s_can_para[channel].mode)) {
        ack[1] = 0x02;                                               /* ����ģʽ���󣬲�ѯʧ�� */
        YX_COM_DirSend( GET_CAN_DATA_REQ_ACK, ack, 2);
        return;
    }

    IDSum = data[1];                                             //ID����
    if (IDSum > (MAX_CANIDS / 2)) {
        IDSum = MAX_CANIDS / 2;
    }
    addr = 3;
    for (j = 0; j < IDSum; j++) {
        tempid = bal_chartolong(&data[2 + 4 * j]);
        for (i = 0; i < MAX_CANIDS; i++) {
            if ((tempid == GetID(i, channel)) && (GetIDIsUsed(i, channel))) {
                break;
            }
        }
        if (i >= MAX_CANIDS) {
            continue ;
        }
        temlen = GetStoreData(i, &ack[addr], channel);

        if (temlen == 0) {                                           /* û�������� */
            memcpy(&ack[addr], &data[2 + 4 * j], 4);
            addr += 4;
            ack[addr] = 0;
            addr += 1;
        }
        addr += temlen;

        IDCnt++;
    }

    ack[1] = 0x01;                                                   /* ��ѯ�ɹ� */
    ack[2] = IDCnt;
    YX_COM_DirSend( GET_CAN_DATA_REQ_ACK, ack, addr);
}

/**************************************************************************************************
**  ��������:  CANDataReportAckHdl
**  ��������:  CAN���������ϱ�����յ�Ӧ��
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**************************************************************************************************/
void CANDataReportAckHdl(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    mancode     = mancode;
    command     = command;
    data        = data;
    datalen     = datalen;
}
/**************************************************************************************************
**  ��������:  CANDataLucidlyAckHdl
**  ��������:  CAN��������͸�����յ�Ӧ��
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**************************************************************************************************/
void CANDataLucidlyAckHdl(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    mancode     = mancode;
    command     = command;
    data        = data;
    datalen     = datalen;
}

/*******************************************************************************
 ** ������:    YX_CAN_SelfCheckInit
 ** ��������:   CAN���߹����Լ��ʼ��
 ** ����:       ��
 ** ����:       ��
 ******************************************************************************/
#if DEBUG_CANSFLFSEND >= 0
static void YX_CAN_SelfCheckInit(void)
{
	//MCU�����оƬTJA1043���ͱ��ģ����CAN���ߴ����쳣��ERR_N�Ż�����Ч״̬
	INT8U dat[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	CAN_DATA_SEND_T sdata;
	sdata.can_DLC=8;
	sdata.can_IDE=0;
	sdata.can_id=0x0;
	sdata.channel=0;
	sdata.period =200;//��������200*10ms
	memcpy(sdata.Data,dat,8);
	PORT_CanSend(&sdata);
	sdata.channel=1;
	PORT_CanSend(&sdata);
	sdata.channel=2;
	//PORT_CanSend(&sdata);
}
#endif
/*******************************************************************************
 ** ������:    YX_CAN_SoftStatus
 ** ��������:   ��ȡCAN�����Ĺ���״̬
 ** ����:       ��
 ** ����:       ��
 ******************************************************************************/
INT8U YX_CAN_SoftStatus(void)
{
	INT8U cansoftstatus = 0;
	if(true == s_can_para[0].onoff) {
		cansoftstatus |= 0x01;
	} else {
		cansoftstatus &= ~0x01;
	}

	if(true == s_can_para[1].onoff) {
		cansoftstatus |= 0x02;
	} else {
		cansoftstatus &= ~0x02;
	}

	if(true == s_can_para[2].onoff) {
		cansoftstatus |= 0x04;
	} else {
		cansoftstatus &= ~0x04;
	}
	return cansoftstatus;

}
/*******************************************************************************
 ** ������:    YX_CAN_Init
 ** ��������:   CANͨѶ����ģ���ʼ��
 ** ����:       ��
 ** ����:       ��
 ******************************************************************************/
void YX_CAN_Init(void)
{
    INT8U i;

    PORT_InitCan();
    for (i = 0; i < MAX_RESEND_NUM; i++) {
        YX_MEMSET((INT8U*)&s_resend_can[i], 0x00, sizeof(RESENT_CAN_T));
    }
	
    s_oilsum_check = 0;
	s_can_para[0].baud = CAN_BAUD_250K;
	s_can_para[0].frameformat= FMAT_EXT;
	s_can_para[0].mode = CAN_MODE_REPORT;

	s_can_para[1].baud = CAN_BAUD_250K;
	s_can_para[1].frameformat= FMAT_EXT;
	s_can_para[1].mode = CAN_MODE_REPORT;

	s_can_para[2].baud = CAN_BAUD_250K;
	s_can_para[2].frameformat= FMAT_EXT;
	s_can_para[2].mode = CAN_MODE_REPORT;

    for (i = CAN_CHN_1; i < MAX_CAN_CHN-1; i++) {
    	if(PORT_OpenCan((CAN_CHN_E)i, s_can_para[i].baud, s_can_para[i].frameformat)){
    		s_can_para[i].onoff = true;
    	} else {
    		s_can_para[i].onoff = false;
    	}

        #if DEBUG_CAN > 0
    	PORT_SetCanFilter((CAN_CHN_E)i, 0, 0x7e8, 0xffffffff);
        #endif
        PORT_CanEnable((CAN_CHN_E)i, true);
    }
	
    Lock_Init();
	PORT_RegCanCallbakFunc(CANDataHdl);

	#if DEBUG_CANSFLFSEND > 0
	YX_CAN_SelfCheckInit();//CAN�Լ��ʼ��
	#endif
    s_packet_tmr = OS_InstallTmr(TSK_ID_OPT, 0, PacketTimeOut);
    OS_StartTmr(s_packet_tmr, MILTICK, 1);
    
    
    #if DEBUG_CAN > 1
    // test
    CAN_DATA_SEND_T candata;
	memset(&candata, 0x00, sizeof(candata));
	candata.can_DLC = 8;
	candata.can_id = 0x401;
	candata.can_IDE = 0;
	candata.period = 0xffff;
	candata.channel = 1;
	PORT_CanSend(&candata);
    #endif
}
