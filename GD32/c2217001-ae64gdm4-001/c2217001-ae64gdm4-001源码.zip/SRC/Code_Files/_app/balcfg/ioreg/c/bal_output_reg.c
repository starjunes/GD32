/********************************************************************************
**
** �ļ���:     bal_output_reg.c
** ��Ȩ����:   (c) 1998-2017 ������Ѹ����ɷ����޹�˾
** �ļ�����:   ��ģ����Ҫʵ��I/O�����ע����Ϣ������
**
*********************************************************************************
**                  �޸���ʷ��¼
**===============================================================================
**| ����              | ����        |  �޸ļ�¼
**===============================================================================
**| 2017/05/12 | ���˷�    |  ��ֲ���޸ġ��淶��
********************************************************************************/
#define GLOBALS_OUTPUT_REG    1
#include "yx_includes.h"
#include "bal_output_reg.h"

/*
*********************************************************************************
*   ���������������
*********************************************************************************
*/
#ifdef BEGIN_OUTPUT_DEF
#undef BEGIN_OUTPUT_DEF
#endif

#ifdef OUTPUT_DEF
#undef OUTPUT_DEF
#endif

#ifdef END_OUTPUT_DEF
#undef END_OUTPUT_DEF
#endif

#define BEGIN_OUTPUT_DEF(_TYPE_)
#define OUTPUT_DEF(_TYPE_, _PORT_ID_, _LEVEL_, _INIT_, _PULLUP_, _PULLDOWN_)  \
                   void _INIT_(void);                                         \
                   void _PULLUP_(void);                                       \
                   void _PULLDOWN_(void);
                   
#define END_OUTPUT_DEF(_TYPE_)

#include "bal_output_reg.def"


/*
*********************************************************************************
*   ����IOע���
*********************************************************************************
*/

#ifdef BEGIN_OUTPUT_DEF
#undef BEGIN_OUTPUT_DEF
#endif

#ifdef OUTPUT_DEF
#undef OUTPUT_DEF
#endif

#ifdef END_OUTPUT_DEF
#undef END_OUTPUT_DEF
#endif

#if EN_FREECONST > 0  /* EN_FREECONST > 0 */
#define BEGIN_OUTPUT_DEF(_TYPE_)
#define OUTPUT_DEF(_TYPE_, _PORT_ID_, _LEVEL_, _INIT_, _PULLUP_, _PULLDOWN_)   \
                   {_TYPE_, _PORT_ID_, _LEVEL_, _INIT_, _PULLUP_, _PULLDOWN_},
                 
#define END_OUTPUT_DEF(_TYPE_)
                   
static const OUTPUT_IO_T s_io_regtbl[] = {
    #include "bal_output_reg.def"
    {0}
    };

#else /* EN_FREECONST == 0 */

static OUTPUT_IO_T s_io_regtbl[OUTPUT_IO_MAX];

#endif /* end EN_FREECONST */

/*
*********************************************************************************
*   �ֶ���ʼ��
*********************************************************************************
*/
#if EN_FREECONST == 0
DECLARE_GPS_FUN_INIT_CONSTVAR(GPS_OUTPUT_REG_STATICDAT_ID)
{
    /* IOע��� */
#ifdef BEGIN_OUTPUT_DEF
#undef BEGIN_OUTPUT_DEF
#endif

#ifdef OUTPUT_DEF
#undef OUTPUT_DEF
#endif

#ifdef END_OUTPUT_DEF
#undef END_OUTPUT_DEF
#endif

#define BEGIN_OUTPUT_DEF(_TYPE_)

#define OUTPUT_DEF(_TYPE_, _PORT_ID_, _LEVEL_, _INIT_, _PULLUP_, _PULLDOWN_)  \
                   s_io_regtbl[_PORT_ID_].type     = _TYPE_;                  \
                   s_io_regtbl[_PORT_ID_].port     = _PORT_ID_;               \
                   s_io_regtbl[_PORT_ID_].level    = _LEVEL_;                 \
                   s_io_regtbl[_PORT_ID_].initport = _INIT_;                  \
                   s_io_regtbl[_PORT_ID_].pullup   = _PULLUP_;                \
                   s_io_regtbl[_PORT_ID_].pulldown = _PULLDOWN_;
                   
#define END_OUTPUT_DEF(_TYPE_)

#include "bal_output_reg.def"
}
#endif /* end EN_FREECONST == 0 */

/********************************************************************************
** ������:     bal_output_GetRegInfo
** ��������:   ��ȡ��ӦI/O��ע����Ϣ
** ����:       [in] port:ͳһ��ŵ�I/O
** ����:       �ɹ�����ע���ָ�룬ʧ�ܷ���0
********************************************************************************/
OUTPUT_IO_T const *bal_output_GetRegInfo(INT8U port)
{
    if (port >= OUTPUT_IO_MAX) {
        return 0;
    }

    return (OUTPUT_IO_T const *)(&s_io_regtbl[port]);
}

/********************************************************************************
*   ������:    bal_output_GetIOMax
*   ��������:  ��ȡI/O�ڸ���
*�� ����:      ��
*   ����ֵ:    I/O�ڸ���
********************************************************************************/
INT8U bal_output_GetIOMax(void)
{
    return OUTPUT_IO_MAX;
}

//------------------------------------------------------------------------------
/* End of File */
