/**************************************************************************************************
**                                                                                               **
**  �ļ�����:  configurepg.c                                                                           **
**  ��Ȩ����:  CopyRight �� Xiamen Yaxon NetWork CO.LTD. 2010                                    **
**  ������Ϣ:  jump -- 2011��1��20��                                                             **
**  �ļ�����:  ϵͳ����ҳ��                                                                      **
**  ===========================================================================================  **
**  �޸���Ϣ:  �����˴�����....                                                                  **
**************************************************************************************************/

#define  CONFIGURE_GLOBALS

#include "yx_includes.h"
#include "yx_com_send.h"
#include "bal_tools.h"
#include "tools.h"
#include "bal_stream.h"
#include "yx_structs.h"
#include "yx_configure.h"
#include "yx_lock.h"
#include "appmain.h"
#include "bal_gpio_cfg.h"
#include "bal_output_drv.h"
#include "yx_com_man.h"
#include "yx_encrypt_man.h"
#include "bal_pp_drv.h"
#include "public.h"
#include "yx_encrypt_man.h"
#include "app_update.h"

static STREAM_T       strm;
static GPS_STATE_E    GPRSstatus = GPS_NO_STATU;
static INT8U          GsmNetIntension;                                      /* �����ź�ǿ�� */
static GPS_STRUCT     GpsLocation = {
	.hbit = 0xff,
};                                     /* �յ���GPS������Ϣ */
static INT32U         AlarmStatus;
static INT32U         sensorstatus = 0;
static INT8U		  wifistatus;		//wifi״̬

static INT16U         ProvinceID, CityID;
static INT8U          ManufactureID[5], TerminalType[20], TerminalID[7];
static INT8U          ManufactureIDLen, TerminalTypeLen, TerminalIDLen;
static INT8U          TerminalTypeLenMax = 20;
static INT8U          platecolor;
static INT8U          CarID[12], CarIDLen;

//static BOOLEAN        speedflag = false;
//static INT32U         gps_speed, pulse_speed;
//static INT8U          reqparatype;


struct {
    INT8U setparatype;
    INT8U paralen;
    INT8U para[50];
}GprsPara;

/**************************************************************************************************
**  ��������:  SetGPRSStatus
**  ��������:  ����GPRS״̬
**  �������:
**  ���ز���:
**************************************************************************************************/
void SetGPRSStatus(GPS_STATE_E status)
{
    GPRSstatus = status;
}

/**************************************************************************************************
**  ��������:  SetGsmNetIntension
**  ��������:  �����ź�ǿ��
**  �������:
**  ���ز���:
**************************************************************************************************/
void SetGsmNetIntension(INT8U intension)
{
    GsmNetIntension = intension & 0x07;
}

/**************************************************************************************************
**  ��������:  IsGpsValid
**  ��������:  ��ȡGpsλ����Ϣ�Ƿ�λ
**  �������:
**  ���ز���:
**************************************************************************************************/
INT8U GetGPSStatus(void)
{
    return GpsLocation.hbit;
}

/**************************************************************************************************
**  ��������:  SetGpsLocation
**  ��������:  ����GPSλ����Ϣ
**  �������:
**  ���ز���:
**************************************************************************************************/
void SetGpsLocation(INT8U *locationdata)
{
    memcpy((INT8U*)&GpsLocation, locationdata, sizeof(GPS_STRUCT));
}

/**************************************************************************************************
**  ��������:  Setsensorstatus
**  ��������:  ���ô�����״̬
**  �������:
**  ���ز���:
**************************************************************************************************/
void Setsensorstatus(INT32U status)
{
    sensorstatus = status;
}

/**************************************************************************************************
**  ��������:  Getwifistatus
**  ��������:  ��ȡWIFI״̬
**  �������:
**  ���ز���:	wifi״̬
**************************************************************************************************/
INT8U Getwifistatus(void)
{
    return wifistatus;
}


/**************************************************************************************************
**  ��������:  EquipmentStatusReq
**  ��������:  ���ճ�̨״̬��������
**  �������:
**  ���ز���:
**************************************************************************************************/
void EquipmentStatusReq(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    INT8U signal, time[6], temp[4],type,mileage_show;
    INT8U level,type_num,count;
    INT32U sensor;
	//Debug_PrintHex(TRUE, data, datalen);
    if (datalen < 28) return;
    bal_InitStrm(&strm, data, datalen);
    ParaStatus.olstatus = bal_ReadBYTE_Strm(&strm);     /* �Ƿ������� */
    signal = bal_ReadBYTE_Strm(&strm);
    if ((level = (signal + 5) / 6) >= 6) {
        level = 5;
    }
    SetGsmNetIntension(level);
    ParaStatus.gprstatus = bal_ReadBYTE_Strm(&strm);

    if ((ParaStatus.gprstatus & 0x18) && (ParaStatus.gprstatus & 0x03)) {
        SetGPRSStatus(GPS_12_STATU);
    } else if (ParaStatus.gprstatus & 0x18){
        SetGPRSStatus(GPS_2_STATU);
    } else if (ParaStatus.gprstatus & 0x03){
        SetGPRSStatus(GPS_1_STATU);
    } else {
       SetGPRSStatus(GPS_NO_STATU);
    }

    bal_ReadDATA_Strm(&strm, time, 6);
	PORT_SetSysTime((SYSTIME_T *)time);
	
    SetGpsLocation(bal_GetStrmPtr(&strm));
    ParaStatus.situate = GetGPSStatus();
    #if EN_DEBUG > 1
    debug_printf("��λ״̬:%02X\r\n", ParaStatus.situate);
    #endif

    bal_MovStrmPtr(&strm, 11);
    ParaStatus.almstatus[0] = bal_ReadBYTE_Strm(&strm);
    ParaStatus.almstatus[1] = bal_ReadBYTE_Strm(&strm);
    ParaStatus.almstatus[2] = bal_ReadBYTE_Strm(&strm);
    ParaStatus.almstatus[3] = bal_ReadBYTE_Strm(&strm);
    AlarmStatus = ((INT32U)ParaStatus.almstatus[0] << 24) | ((INT32U)ParaStatus.almstatus[1] << 16)
                | ((INT32U)ParaStatus.almstatus[2] << 8) | ParaStatus.almstatus[3];

    temp[0] = bal_ReadBYTE_Strm(&strm);
    temp[1] = bal_ReadBYTE_Strm(&strm);
    temp[2] = bal_ReadBYTE_Strm(&strm);
    temp[3] = bal_ReadBYTE_Strm(&strm);
    sensor = ((INT32U)temp[0] << 24) | ((INT32U)temp[1] << 16) | ((INT32U)temp[2] << 8) | temp[3];

    Setsensorstatus(sensor);

	mileage_show = bal_ReadBYTE_Strm(&strm);
   	bal_MovStrmPtr(&strm, 21);//��̺ͼ�ʻʱ���Թ�
	
	type_num = bal_ReadBYTE_Strm(&strm);
	for(count = 0; count < type_num; count++){
		type = bal_ReadBYTE_Strm(&strm);
		if(type == 0x23){
			wifistatus = bal_ReadBYTE_Strm(&strm);//wifi״̬
			//debug_printf("wifistatus:%d\r\n",wifistatus);
			return ;
		}else{
			bal_MovStrmPtr(&strm, bal_ReadBYTE_Strm(&strm)+1);
		}
	}
	
    #if 0
    if (bal_GetStrmLeftLen(&strm) > 0) {
        type = bal_ReadBYTE_Strm(&strm);
        if (type == 0) {
            Change_time_Mileage(0, 0, type);
        } else {
            if (type == 0x01) {
                bal_ReadDATA_Strm(&strm, time, 6);
                bal_ReadDATA_Strm(&strm, temp, 4);
                bal_MovStrmPtr(&strm, 10);
            } else if (type == 0x02) {
                bal_MovStrmPtr(&strm, 10);
                bal_ReadDATA_Strm(&strm, time, 6);
                bal_ReadDATA_Strm(&strm, temp, 4);
            } else {
                return;
            }
            Change_time_Mileage(time, temp, type);
        }
    }
    #endif
}
#if 0
/**************************************************************************************************
**  ��������:  CutRedundantLen
**  ��������:  ȡ�϶̵ĳ���
**  �������:
**  ���ز���:
**************************************************************************************************/
INT8U  CutRedundantLen(INT8U len,INT8U standardlen)
{
      if (len < standardlen) {
         return len;
      } else {
         return standardlen;
      }
}
#endif
/**************************************************************************************************
**  ��������:  GprsQueAns
**  ��������:  GPRS��������Ӧ��
**  �������:
**  ���ز���:
**************************************************************************************************/
void GprsQueAns(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    INT8U count, type, typelen;


    YX_ConfirmSend(EQUIPMENT_PARA_REQ);
    bal_InitStrm(&strm, data, datalen);
    count = bal_ReadBYTE_Strm(&strm);
    if (count == 0) {

        return;
    }
    while (count-- > 0)
    {
        type = bal_ReadBYTE_Strm(&strm);
        typelen = bal_ReadBYTE_Strm(&strm);
        switch(type)
        {

            case 0x03:
                GprsPara.paralen = CutRedundantLen(typelen, MAXMYTELLEN);
                memset(GprsPara.para, '0', sizeof(GprsPara.para));
                bal_ReadDATA_Strm(&strm, GprsPara.para, GprsPara.paralen);
                break;
            case 0x61:
                if (typelen != 7) {
                    bal_MovStrmPtr(&strm, typelen);

                } else {
                }
                break;
            case 0x62:

                break;
            case 0x63:

                break;
            case 0x64:
                break;
            case 0x65:
                break;

            default:
                bal_MovStrmPtr(&strm, typelen);
                break;
        }
    }
}

/**************************************************************************************************
**  ��������:  GprsSetAns
**  ��������:  GPRS�������õ�Ӧ��
**  �������:
**  ���ز���:
**************************************************************************************************/
void GprsSetAns(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{

    YX_ConfirmSend(EQUIPMENT_PARA_SET);
}

/**********************************************************************************
**  ��������:  Client_FuntionUpAck_Hdl
**  ��������:  �ͻ����⹦����������Ӧ��
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**********************************************************************************/

void Client_FuntionUpAck_Hdl(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    INT8U cmdtye;
    INT16U cno;


    #if EN_DEBUG > 1
        debug_printf("FCָ��Ӧ������ len:%d  data: ", datalen);
        printf_hex( data, datalen);
    #endif

    bal_InitStrm(&strm, data, datalen);
    cno = bal_ReadHWORD_Strm(&strm);
    if (cno != CLIENT_CODE) return;

    cmdtye = bal_ReadBYTE_Strm(&strm);
    if ((cmdtye == 0x0f) && (bal_ReadBYTE_Strm(&strm) == 0x01) && (bal_ReadBYTE_Strm(&strm) == 0x02)) {
        ProvinceID = bal_ReadHWORD_Strm(&strm);
        CityID = bal_ReadHWORD_Strm(&strm);
        ManufactureIDLen = bal_ReadBYTE_Strm(&strm);
        if (ManufactureIDLen != 5) {
            bal_MovStrmPtr(&strm, ManufactureIDLen);
            ManufactureIDLen = 0;
            memset(ManufactureID, 0, 5);
        } else {
            bal_ReadDATA_Strm(&strm, ManufactureID, 5);
            ManufactureIDLen = bal_CutFromRight(ManufactureID, 0x00, 5);
            if (ManufactureIDLen == 0xff) {
                ManufactureIDLen = 0;
            }
            ManufactureIDLen = bal_CutFromRight(ManufactureID, 0x20, ManufactureIDLen);
            if (ManufactureIDLen == 0xff) {
                ManufactureIDLen = 0;
            }
        }
        TerminalTypeLen = bal_ReadBYTE_Strm(&strm);
        if (TerminalTypeLen == 8) {
            bal_ReadDATA_Strm(&strm, TerminalType, 8);
            TerminalTypeLenMax = 8;
            TerminalTypeLen = bal_CutFromRight(TerminalType, 0x00, 8);
            if (TerminalTypeLen == 0xff) {
                TerminalTypeLen = 0;
            }
            TerminalTypeLen = bal_CutFromRight(TerminalType, 0x20, TerminalTypeLen);
            if (TerminalTypeLen == 0xff) {
                TerminalTypeLen = 0;
            }
        } else if (TerminalTypeLen == 20) {
            bal_ReadDATA_Strm(&strm, TerminalType, 20);
            TerminalTypeLenMax = 20;
            TerminalTypeLen = bal_CutFromRight(TerminalType, 0x00, 20);
            if (TerminalTypeLen == 0xff) {
                TerminalTypeLen = 0;
            }
            TerminalTypeLen = bal_CutFromRight(TerminalType, 0x20, TerminalTypeLen);
            if (TerminalTypeLen == 0xff) {
                TerminalTypeLen = 0;
            }
        } else {
            bal_MovStrmPtr(&strm, TerminalTypeLen);
            TerminalTypeLen = 0;
            memset(TerminalType, 0, 20);
        }
        TerminalIDLen = bal_ReadBYTE_Strm(&strm);
        if (TerminalIDLen != 7) {
            bal_MovStrmPtr(&strm, TerminalIDLen);
            TerminalIDLen = 0;
            memset(TerminalID, 0, 7);
        } else {
            bal_ReadDATA_Strm(&strm, TerminalID, 7);
            TerminalIDLen = bal_CutFromRight(TerminalID, 0x00, 7);
            if (TerminalIDLen == 0xff) {
                TerminalIDLen = 0;
            }
            TerminalIDLen = bal_CutFromRight(TerminalID, 0x20, TerminalIDLen);
            if (TerminalIDLen == 0xff) {
                TerminalIDLen = 0;
            }
        }
        platecolor = bal_ReadBYTE_Strm(&strm);
        CarIDLen = bal_ReadBYTE_Strm(&strm);
        if (CarIDLen > 12) {
            bal_MovStrmPtr(&strm, CarIDLen);
            CarIDLen = 0;
        } else {
            memset(CarID, 0, sizeof(CarID));
            bal_ReadDATA_Strm(&strm, CarID, CarIDLen);
        }
        //InputProvinceID();
    }
}

/**********************************************************************************
**  ��������:  exio_output
**  ��������:  ��չIO�������
**  �������:  type  IO����
            :  value IO��ƽ
**  ���ز���:  None
**********************************************************************************/
static void exio_output(INT8U type, INT8U value)
{
    switch (type) {
        case 0x00:
            if (value) {
                bal_Pullup_232CON();
                #if DEBUG_EXIO > 0
                debug_printf("EC20���Դ���ͨ���л������Ӳ������2\r\n");
                #endif
            } else {
                bal_Pulldown_232CON();
                #if DEBUG_EXIO > 0
                debug_printf("EC20���Դ���ͨ���л�������оƬUARTB\r\n");
                #endif
            }
            break;
        case 0x01:
            if (value) {
                bal_Pullup_VBUSCTL();
                #if DEBUG_EXIO > 0
                debug_printf("EC20 USB�������-��\r\n");
                #endif
            } else {
                bal_Pulldown_VBUSCTL();
                #if DEBUG_EXIO > 0
                debug_printf("EC20 USB�������-��\r\n");
                #endif
            }
            break;
        case 0x02:
            if (value) {
                bal_Pullup_HSMPWR();
                #if DEBUG_EXIO > 0
                debug_printf("����оƬ��Դ����-��\r\n");
                #endif
            } else {
                bal_Pulldown_HSMPWR();
                #if DEBUG_EXIO > 0
                debug_printf("����оƬ��Դ����-��\r\n");
                #endif
            }
            break;
        case 0x03:
            if (value) {
                bal_Pullup_HSMWK();
                #if DEBUG_EXIO > 0
                debug_printf("����оƬ����-��\r\n");
                #endif
            } else {
                bal_Pulldown_HSMWK();
                #if DEBUG_EXIO > 0
                debug_printf("����оƬ����-��\r\n");
                #endif
            }
            break;
        case 0x04:
            if (value) {
                bal_Pulldown_BTWLEN();
                #if DEBUG_EXIO > 0
                debug_printf("wifi��Դ����-��\r\n");
                #endif
            } else {
                bal_Pulldown_BTWLEN();
                #if DEBUG_EXIO > 0
                debug_printf("wifi��Դ����-��\r\n");
                #endif
            }
            break;
        case 0x05:
            if (value) {
                bal_Pullup_GPSPWR();
                #if DEBUG_EXIO > 0
                debug_printf("gps��Դ����-��\r\n");
                #endif
            } else {
                bal_Pulldown_GPSPWR();
                #if DEBUG_EXIO > 0
                debug_printf("gps��Դ����-��\r\n");
                #endif
            }
            break;
        case 0x06:
            if (value) {
                bal_Pullup_PHYPWR();
                #if DEBUG_EXIO > 0
                debug_printf("phy��Դ����-��\r\n");
                #endif
            } else {
                bal_Pulldown_PHYPWR();
                #if DEBUG_EXIO > 0
                debug_printf("phy��Դ����-��\r\n");
                #endif
            }
            break;
        case 0x07:
            if (value) {
                //bal_Pullup_GPSBAT();
                #if DEBUG_EXIO > 0
                debug_printf("�߾��ȶ�λģ������������-��\r\n");
                #endif
            } else {
                //bal_Pulldown_GPSBAT();
                #if DEBUG_EXIO > 0
                debug_printf("�߾��ȶ�λģ������������-��\r\n");
                #endif
            }
            break;
        case 0x08:
            if (value) {
                bal_Pullup_5VEXT();
                #if DEBUG_EXIO > 0
                debug_printf("��ΧоƬ5V��Դʹ�ܿ���-��\r\n");
                #endif
            } else {
                bal_Pulldown_5VEXT();
                #if DEBUG_EXIO > 0
                debug_printf("��ΧоƬ5V��Դʹ�ܿ���-��\r\n");
                #endif
            }
            break;
        default:
            break;
    }
}

/**********************************************************************************
**  ��������:  Client_FuntionDown_Hdl
**  ��������:  �ͻ����⹦����������
**  �������:  version
            :  command
            :  userdata
            :  userdatalen
**  ���ز���:  None
**********************************************************************************/
void Client_FuntionDown_Hdl(INT8U mancode, INT8U command, INT8U *data, INT16U datalen)
{
    INT8U i;
    INT16U code;
    INT8U cmdtye;
    INT8U ionum, iotype, iovalue;
    STREAM_T rstrm;
    INT8U ack[32];

    ack[0] = data[0];
    ack[1] = data[1];
    ack[2] = data[2];
	
    bal_InitStrm(&rstrm, data, datalen);
    code = bal_ReadHWORD_Strm(&rstrm);
    if ((code != CLIENT_CODE) || (datalen < 3)) {
        return;
    }

    cmdtye = bal_ReadBYTE_Strm(&rstrm);
	//debug_printf("Client_FuntionDown_Hdl cmdtye:%X\r\n",cmdtye);
    switch (cmdtye) {
         case 0x01:
            LockParaStore(&data[3], datalen-3);
            break;
        case 0x02:
            Lock_RecordReqHdl();
            break;
        case 0x05:
            if (LockParaBak(&data[3], datalen-3)) {
               ack[2] = 0x05;
               ack[3] = 0x01;
            } else {
               ack[2] = 0x05;
               ack[3] = 0x02;
            }
            YX_COM_DirSend(CLIENT_FUNCTION_DOWN_REQ_ACK, ack, 4);
            #if EN_DEBUG > 0
            debug_printf("ָ��FD-05Ӧ��%2x: ", data[2]);
            printf_hex(ack, 4);
            #endif
            break;  		
        case 0x20:
            ionum = bal_ReadBYTE_Strm(&rstrm);
            for (i = 0; i < ionum; i++) {
                iotype = bal_ReadBYTE_Strm(&rstrm);
                iovalue = bal_ReadBYTE_Strm(&rstrm);
                exio_output(iotype, iovalue);
            }
            ack[3] = 0x00;
            YX_COM_DirSend( CLIENT_FUNCTION_DOWN_REQ_ACK, ack, 4);
            break;
        case 0x21:
            break;
        case 0x24:
            YX_COM_SetOTA();
            ack[3] = 0x00;
            YX_COM_DirSend( CLIENT_FUNCTION_DOWN_REQ_ACK, ack, 4);
            break;
        case 0x26: /* �����㷨 */
            YX_Encrypt_Func(&data[3], datalen - 3);
			ack[3] = 0x00;
            break;
        case 0x2e:  /* ��������˹��������ָ�� */
            #if EN_KMS_LOCK > 0
            Lock_KmsG5Cmd(&data[3], datalen - 3);
            #endif
            break;
        default:
            break;
      }

}
/**************************************************************************************************
**  ��������:  ClearDataRequest
**  ��������:  ����������յ�������������
**  �������:  
**  ���ز���:  
**************************************************************************************************/
void ClearDataRequest(INT8U mancode, INT8U command, INT8U *data, INT16U userdatalen)
{
    INT8U   temp[2];
    //INT16U  i;
    
    mancode = mancode;
    command = command;
    userdatalen = userdatalen;
    
    temp[0] = data[0];
    temp[1] = 0x01;
    switch (data[0]) {
        case 0x01:    
            #if 1
            #if EN_DEBUG > 1
            debug_printf("�������˹����pp����\r\n");
            printf_hex((INT8U*)GetDefaulValue(KMS_LOCK_PARA_), sizeof(KMS_LOCK_OBJ_T));
            #endif
            ResumeAllPubPara();
            #else
            if (bal_pp_StoreParaByID(AXISCALPARA_, (INT8U*)GetDefaulValue(AXISCALPARA_), sizeof(AXISPARA_T)) == FALSE) {
                temp[1] = 0x02;
            }
            if (bal_pp_StoreParaByID(SCLOCKPARA_, (INT8U*)GetDefaulValue(SCLOCKPARA_), sizeof(SCLOCKPARA_T)) == FALSE) {
                temp[1] = 0x02;
            }				
            if (bal_pp_StoreParaByID(LOCKRECORD_, (INT8U*)GetDefaulValue(LOCKRECORD_), sizeof(LOCK_RECORD)) == FALSE) {
                temp[1] = 0x02;
            }					
            if (bal_pp_StoreParaByID(SCLOCKPARABAK_, (INT8U*)GetDefaulValue(SCLOCKPARABAK_), sizeof(SCLOCKPARABAK_T)) == FALSE) {
                temp[1] = 0x02;
            }
            #if EN_KMS_LOCK > 0
            #if EN_DEBUG > 1
            debug_printf("�������˹����pp����\r\n");
            printf_hex((INT8U*)GetDefaulValue(KMS_LOCK_PARA_), sizeof(KMS_LOCK_OBJ_T));
            #endif
            if (bal_pp_StoreParaByID(KMS_LOCK_PARA_, (INT8U*)GetDefaulValue(KMS_LOCK_PARA_), sizeof(KMS_LOCK_OBJ_T)) == FALSE) {
                temp[1] = 0x02;
            }
            #endif
            #endif
            break;
        default:
            temp[1] = 0x02;
            break;
    }
	
    YX_COM_DirSend(CLEAR_DATA_REQ_ACK, temp, 2);
    ResetMcuDelay(5);
}

